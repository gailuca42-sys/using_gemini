
import { sr } from '../utils/seedrandom';
import { BabelPosition, BookStats, PageContent } from '../types';

// Alphabet complet (101 caractères)
export const ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ,.?!;:-()[]{}àâéèêëîïôûùçÀÂÉÈÊËÎÏÔÛÙÇ";

// Constantes pour la mécanique de l'univers
const OCCURRENCE_MULTIPLIER = 1000000000000n; 
// Un "Masque de Babel" : une constante large pour brouiller l'ordre linéaire des HEX
const BABEL_MASK = 0x5F3759DF5F3759DF5F3759DF5F3759DFn;

/**
 * Encode un texte en une valeur BigInt (Base 101)
 */
function encodeText(text: string): bigint {
  const base = BigInt(ALPHABET.length);
  let res = BigInt(0);
  for (let i = 0; i < text.length; i++) {
    const charIdx = ALPHABET.indexOf(text[i]);
    if (charIdx === -1) continue;
    res = res * base + BigInt(charIdx);
  }
  return res;
}

/**
 * Décode une valeur BigInt en texte (Base 101)
 */
function decodeText(value: bigint): string {
  if (value === 0n) return "";
  const base = BigInt(ALPHABET.length);
  let res = "";
  let temp = value;
  while (temp > 0n) {
    const charIdx = Number(temp % base);
    res = ALPHABET[charIdx] + res;
    temp = temp / base;
  }
  return res;
}

/**
 * Transforme un ID d'hexagone pour le rendre non-linéaire (Scrambling)
 */
function scrambleHex(val: bigint): bigint {
  return val ^ BABEL_MASK;
}

/**
 * Inverse la transformation de l'ID d'hexagone
 */
function unscrambleHex(hex: string): { root: bigint, occurrence: number } {
  try {
    const val = BigInt(hex) ^ BABEL_MASK;
    return {
      root: val / OCCURRENCE_MULTIPLIER,
      occurrence: Number(val % OCCURRENCE_MULTIPLIER)
    };
  } catch {
    return { root: 0n, occurrence: 0 };
  }
}

export function getPositionSeed(pos: BabelPosition, extra: string = ''): string {
  // La seed dépend de l'HEX réel (scrambled) pour que chaque adresse soit unique
  return `babel-v5-${pos.hexagon}-w${pos.wall}-s${pos.shelf}-v${pos.volume}${extra}`;
}

export function getBookStats(pos: BabelPosition): BookStats {
  const seed = getPositionSeed(pos, '-stats');
  const rng = sr(seed);
  return { numPages: Math.floor(rng() * 2000) + 1 };
}

export function generatePage(pos: BabelPosition): PageContent {
  const seed = getPositionSeed(pos, `-p${pos.page}`);
  const rng = sr(seed);
  
  const charCount = Math.floor(rng() * 2501) + 500;
  let text = '';
  
  // Extraction des données de l'hexagone
  const { root } = unscrambleHex(pos.hexagon);
  
  try {
    const rootVal = root;
    // Détermination de l'adresse cible gravée dans cet HEX
    const targetWall = Number((rootVal % 4n) + 1n);
    const targetShelf = Number(((rootVal / 4n) % 5n) + 1n);
    const targetVolume = Number(((rootVal / 20n) % 32n) + 1n);
    const targetPage = Number(((rootVal / 640n) % 500n) + 1n);

    if (pos.wall === targetWall && 
        pos.shelf === targetShelf && 
        pos.volume === targetVolume &&
        pos.page === targetPage) {
      
      const decoded = decodeText(rootVal);
      if (decoded.length > 0) {
        text = decoded;
      }
    }
  } catch (e) {}

  // Remplissage aléatoire déterministe
  while (text.length < charCount) {
    const charIndex = Math.floor(rng() * ALPHABET.length);
    text += ALPHABET[charIndex];
  }
  
  if (text.length > charCount) text = text.substring(0, charCount);

  return { text, charCount };
}

export function findTextLocation(searchQuery: string, mode: 'start' | 'depth' = 'start', occurrence: number = 0): BabelPosition {
  const query = searchQuery.split('').filter(c => ALPHABET.includes(c)).join('');
  
  if (query.length === 0) {
    return { hexagon: scrambleHex(0n).toString(), wall: 1, shelf: 1, volume: 1, page: 1 };
  }

  // 1. Pour les textes très courts, on pourrait simuler une recherche brute, 
  // mais pour rester performant et fidèle à l'interface, on utilise l'encodage.
  const rootValue = encodeText(query);
  
  // 2. Calcul des coordonnées cibles (déterministes à partir du texte)
  const wall = Number((rootValue % 4n) + 1n);
  const shelf = Number(((rootValue / 4n) % 5n) + 1n);
  const volume = Number(((rootValue / 20n) % 32n) + 1n);
  
  let page = 1;
  if (mode === 'depth') {
    page = Number(((rootValue / 640n) % 500n) + 1n);
  }

  // 3. Génération de l'ID d'hexagone final (avec mélange non-linéaire)
  const rawId = (rootValue * OCCURRENCE_MULTIPLIER) + BigInt(occurrence);
  const scrambledId = scrambleHex(rawId);
  
  return { 
    hexagon: scrambledId.toString(), 
    wall, 
    shelf, 
    volume, 
    page 
  };
}
