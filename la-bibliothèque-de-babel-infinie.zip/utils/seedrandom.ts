
/**
 * Alea PRNG implementation (deterministic, self-contained).
 * Based on Johannes Baagøe's Alea algorithm, which is the standard
 * fast deterministic PRNG used in many libraries including seedrandom.
 * This version avoids any manipulation of the global 'window' object,
 * fixing the 'Failed to set an indexed property [0] on Window' error.
 */

function Mash() {
  let n = 0xefc8249d;
  const mash = function(data: string | number) {
    const s = data.toString();
    for (let i = 0; i < s.length; i++) {
      n += s.charCodeAt(i);
      let h = 0.02519603282416938 * n;
      n = h >>> 0;
      h -= n;
      h *= n;
      n = h >>> 0;
      h -= n;
      n += h * 0x100000000; // 2^32
    }
    return (n >>> 0) * 2.3283064365386963e-10; // 2^-32
  };
  return mash;
}

class AleaPRNG {
  private s0: number;
  private s1: number;
  private s2: number;
  private c: number;

  constructor(seed: string) {
    let mash = Mash();
    this.c = 1;
    this.s0 = mash(' ');
    this.s1 = mash(' ');
    this.s2 = mash(' ');

    this.s0 -= mash(seed);
    if (this.s0 < 0) this.s0 += 1;
    this.s1 -= mash(seed);
    if (this.s1 < 0) this.s1 += 1;
    this.s2 -= mash(seed);
    if (this.s2 < 0) this.s2 += 1;
    mash = null as any;
  }

  next(): number {
    const t = 2091639 * this.s0 + this.c * 2.3283064365386963e-10; // 2^-32
    this.s0 = this.s1;
    this.s1 = this.s2;
    return this.s2 = t - (this.c = t | 0);
  }
}

interface SeedRandomOptions {
  state?: boolean;
}

/**
 * The 'sr' function acts as a factory for the deterministic PRNG.
 * It returns a function that produces the next pseudo-random number in the sequence.
 */
export function sr(seed?: string, options?: SeedRandomOptions): () => number {
  // Use provided seed or a default fallback
  const finalSeed = seed !== undefined ? seed : Math.random().toString();
  const prng = new AleaPRNG(finalSeed);
  
  const nextFunction = () => prng.next();
  
  // Minimal property exposure to match expected seedrandom behavior
  (nextFunction as any).quick = nextFunction;
  (nextFunction as any).double = nextFunction;
  
  return nextFunction;
}
