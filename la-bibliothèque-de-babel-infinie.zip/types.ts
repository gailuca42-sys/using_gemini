
export interface BabelPosition {
  hexagon: string;  // BigInt string
  wall: number;     // 1-4
  shelf: number;    // 1-5
  volume: number;   // 1-32
  page: number;     // 1-N (dynamic per book)
}

export interface BookStats {
  numPages: number;
}

export interface PageContent {
  text: string;
  charCount: number;
}

export enum ViewMode {
  READ = 'READ',
  SEARCH = 'SEARCH',
  BROWSE = 'BROWSE'
}
