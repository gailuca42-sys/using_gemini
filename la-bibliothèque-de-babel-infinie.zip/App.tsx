
import React, { useState, useMemo } from 'react';
import { BabelPosition, ViewMode } from './types';
import { getBookStats, generatePage, findTextLocation, ALPHABET } from './services/babelLogic';
import { BookOpen, Search, Map as MapIcon, ArrowLeft, ArrowRight, RefreshCw, Info, Layers, Copy } from 'lucide-react';

const App: React.FC = () => {
  const [pos, setPos] = useState<BabelPosition>({
    hexagon: '6453829104726354718293041',
    wall: 1,
    shelf: 1,
    volume: 1,
    page: 1
  });

  const [viewMode, setViewMode] = useState<ViewMode>(ViewMode.READ);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchMode, setSearchMode] = useState<'start' | 'depth'>('start');
  const [lastSearch, setLastSearch] = useState('');
  const [occurrenceIndex, setOccurrenceIndex] = useState(0);
  const [isSearching, setIsSearching] = useState(false);
  
  const stats = useMemo(() => getBookStats(pos), [pos]);
  const pageData = useMemo(() => generatePage(pos), [pos]);

  const goToPage = (p: number) => {
    const safePage = Math.max(1, Math.min(p, stats.numPages));
    setPos(prev => ({ ...prev, page: safePage }));
  };

  const findAnotherCopy = () => {
    if (!lastSearch) return;
    const nextIdx = occurrenceIndex + 1;
    setOccurrenceIndex(nextIdx);
    const nextPos = findTextLocation(lastSearch, searchMode, nextIdx);
    setPos(nextPos);
  };

  const randomLocation = () => {
    let randomHex = "";
    for(let i=0; i<30; i++) randomHex += Math.floor(Math.random() * 10).toString();
    
    setPos({
      hexagon: randomHex,
      wall: Math.floor(Math.random() * 4) + 1,
      shelf: Math.floor(Math.random() * 5) + 1,
      volume: Math.floor(Math.random() * 32) + 1,
      page: 1
    });
    setLastSearch('');
    setOccurrenceIndex(0);
    setViewMode(ViewMode.READ);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setTimeout(() => {
      const sanitized = searchQuery.split('').filter(c => ALPHABET.includes(c)).join('');
      setLastSearch(sanitized);
      setOccurrenceIndex(0);
      const foundPos = findTextLocation(sanitized, searchMode, 0);
      setPos(foundPos);
      setViewMode(ViewMode.READ);
      setIsSearching(false);
    }, 800);
  };

  const renderHighlightedText = (text: string, highlight: string) => {
    if (!highlight || !text.includes(highlight)) return text;
    const parts = text.split(new RegExp(`(${highlight.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'g'));
    return (
      <>
        {parts.map((part, i) => 
          part === highlight ? 
            <mark key={i} className="bg-amber-300 text-stone-900 rounded-sm px-0.5 border-b-2 border-amber-500 shadow-sm">{part}</mark> : 
            part
        )}
      </>
    );
  };

  return (
    <div className="flex flex-col min-h-screen selection:bg-amber-200">
      <header className="bg-stone-800 text-stone-100 p-4 shadow-xl sticky top-0 z-50">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setViewMode(ViewMode.READ)}>
            <BookOpen className="w-8 h-8 text-amber-400" />
            <h1 className="text-2xl font-serif font-bold tracking-tight">Babel <span className="text-amber-500 italic font-normal text-xl opacity-80">Infinie</span></h1>
          </div>
          <nav className="flex gap-1 bg-stone-900/50 p-1 rounded-lg">
            <button onClick={() => setViewMode(ViewMode.READ)} className={`px-4 py-2 rounded-md transition flex items-center gap-2 text-sm ${viewMode === ViewMode.READ ? 'bg-amber-600 text-white shadow-lg' : 'hover:bg-stone-700 text-stone-400'}`}><BookOpen className="w-4 h-4" /> Lire</button>
            <button onClick={() => setViewMode(ViewMode.SEARCH)} className={`px-4 py-2 rounded-md transition flex items-center gap-2 text-sm ${viewMode === ViewMode.SEARCH ? 'bg-amber-600 text-white shadow-lg' : 'hover:bg-stone-700 text-stone-400'}`}><Search className="w-4 h-4" /> Chercher</button>
            <button onClick={() => setViewMode(ViewMode.BROWSE)} className={`px-4 py-2 rounded-md transition flex items-center gap-2 text-sm ${viewMode === ViewMode.BROWSE ? 'bg-amber-600 text-white shadow-lg' : 'hover:bg-stone-700 text-stone-400'}`}><MapIcon className="w-4 h-4" /> Naviguer</button>
            <button onClick={randomLocation} className="px-4 py-2 rounded-md hover:bg-stone-700 transition text-stone-400"><RefreshCw className="w-4 h-4" /></button>
          </nav>
        </div>
      </header>

      <main className="flex-grow max-w-5xl mx-auto w-full p-4 md:p-8">
        {viewMode === ViewMode.READ && (
          <div className="flex flex-col gap-6">
            <div className="bg-stone-200/50 border-l-4 border-amber-600 p-4 rounded-r-lg shadow-inner font-mono text-xs overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex flex-col gap-1">
                <span className="text-stone-400 font-bold uppercase tracking-widest text-[9px]">Emplacement Spatial</span>
                <span className="text-amber-900 break-all leading-relaxed">HEX: {pos.hexagon}</span>
                {lastSearch && (
                  <button onClick={findAnotherCopy} className="flex items-center gap-2 text-amber-700 hover:text-amber-900 font-bold mt-1 transition-colors">
                    <Copy className="w-3 h-3" /> Téléportation vers une autre occurrence 
                    <span className="text-[10px] bg-amber-200 px-2 py-0.5 rounded-full ml-1">Exemplaire n°{occurrenceIndex + 1}</span>
                  </button>
                )}
              </div>
              <div className="flex gap-4 shrink-0 text-stone-500 font-bold border-l border-stone-300 pl-4">
                <div className="flex flex-col"><span className="text-[9px] uppercase tracking-tighter">Mur</span><span className="text-amber-700">{pos.wall}</span></div>
                <div className="flex flex-col"><span className="text-[9px] uppercase tracking-tighter">Rayon</span><span className="text-amber-700">{pos.shelf}</span></div>
                <div className="flex flex-col"><span className="text-[9px] uppercase tracking-tighter">Vol</span><span className="text-amber-700">{pos.volume}</span></div>
              </div>
            </div>

            <div className="parchment p-6 md:p-12 lg:p-20 rounded-sm shadow-2xl relative min-h-[700px] border border-stone-300">
              <div className="absolute top-6 left-6 text-[10px] uppercase tracking-widest text-stone-300 font-bold">Bibliotheca Universalis</div>
              <div className="w-full typewriter leading-relaxed text-lg sm:text-xl text-stone-900 break-words text-justify select-text whitespace-pre-wrap">
                {renderHighlightedText(pageData.text, lastSearch)}
              </div>
              <div className="mt-16 pt-8 flex justify-between items-center w-full border-t border-stone-300/50">
                <button disabled={pos.page <= 1} onClick={() => goToPage(pos.page - 1)} className="p-3 rounded-full hover:bg-stone-200 disabled:opacity-10 transition-all active:scale-90"><ArrowLeft className="w-6 h-6 text-stone-700" /></button>
                <div className="flex flex-col items-center gap-1">
                  <div className="text-stone-400 font-serif italic text-sm">Page {pos.page} sur {stats.numPages}</div>
                  <div className="w-32 h-1 bg-stone-200 rounded-full overflow-hidden">
                    <div className="h-full bg-amber-400 transition-all duration-300" style={{ width: `${(pos.page / stats.numPages) * 100}%` }} />
                  </div>
                </div>
                <button disabled={pos.page >= stats.numPages} onClick={() => goToPage(pos.page + 1)} className="p-3 rounded-full hover:bg-stone-200 disabled:opacity-10 transition-all active:scale-90"><ArrowRight className="w-6 h-6 text-stone-700" /></button>
              </div>
            </div>
          </div>
        )}

        {viewMode === ViewMode.SEARCH && (
          <div className="max-w-2xl mx-auto py-8 text-center">
            <h2 className="text-4xl font-serif text-stone-800 mb-2">Recherche de Babel</h2>
            <p className="text-stone-500 italic mb-10">Trouvez le lieu exact où vos paroles ont été gravées il y a des éons.</p>
            <form onSubmit={handleSearch} className="space-y-8">
              <div className="bg-white p-2 rounded-xl shadow-lg border-2 border-stone-200 focus-within:border-amber-500 transition-all">
                <textarea value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Écrivez votre texte..." className="w-full p-4 text-stone-900 bg-white min-h-[180px] text-xl font-serif outline-none resize-none" style={{ color: '#1c1917' }} />
              </div>
              <div className="space-y-3">
                <label className="block text-xs font-bold text-stone-400 uppercase tracking-widest">Type de localisation</label>
                <div className="flex p-1 bg-stone-200 rounded-xl gap-1">
                  <button type="button" onClick={() => setSearchMode('start')} className={`flex-1 py-3 rounded-lg text-sm font-bold transition-all ${searchMode === 'start' ? 'bg-white text-amber-700 shadow-sm' : 'text-stone-500 hover:text-stone-700'}`}>Début du volume</button>
                  <button type="button" onClick={() => setSearchMode('depth')} className={`flex-1 py-3 rounded-lg text-sm font-bold transition-all ${searchMode === 'depth' ? 'bg-white text-amber-700 shadow-sm' : 'text-stone-500 hover:text-stone-700'}`}>Profondeur variable</button>
                </div>
              </div>
              <button disabled={isSearching || !searchQuery.trim()} className="w-full bg-stone-800 text-amber-50 py-5 rounded-xl text-lg font-bold hover:bg-stone-900 transition-all shadow-xl disabled:opacity-50 flex items-center justify-center gap-3">
                {isSearching ? <RefreshCw className="animate-spin" /> : <Search />} CALCULER L'ADRESSE NON-LINÉAIRE
              </button>
            </form>
          </div>
        )}

        {viewMode === ViewMode.BROWSE && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 py-4">
            <div className="space-y-4">
               <h2 className="text-2xl font-serif font-bold text-stone-800">Saisie Spatiale</h2>
               <div className="bg-white p-6 rounded-xl shadow-md border border-stone-200 space-y-4">
                  <div>
                    <label className="block text-[10px] font-black text-stone-400 uppercase mb-1">ID Hexagone (Non-Séquentiel)</label>
                    <input type="text" value={pos.hexagon} onChange={(e) => setPos(prev => ({ ...prev, hexagon: e.target.value.replace(/[^0-9]/g, '') }))} className="w-full p-3 border-2 border-stone-100 rounded font-mono text-stone-900 bg-stone-50 outline-none focus:border-amber-500" style={{ color: '#1c1917' }} />
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div><label className="block text-[9px] font-black text-stone-400 uppercase mb-1">Mur (1-4)</label><input type="number" min="1" max="4" value={pos.wall} onChange={(e) => setPos(prev => ({ ...prev, wall: parseInt(e.target.value) || 1 }))} className="w-full p-2 border-2 border-stone-100 rounded text-stone-900 outline-none focus:border-amber-500" style={{ color: '#1c1917' }} /></div>
                    <div><label className="block text-[9px] font-black text-stone-400 uppercase mb-1">Rayon (1-5)</label><input type="number" min="1" max="5" value={pos.shelf} onChange={(e) => setPos(prev => ({ ...prev, shelf: parseInt(e.target.value) || 1 }))} className="w-full p-2 border-2 border-stone-100 rounded text-stone-900 outline-none focus:border-amber-500" style={{ color: '#1c1917' }} /></div>
                    <div><label className="block text-[9px] font-black text-stone-400 uppercase mb-1">Vol (1-32)</label><input type="number" min="1" max="32" value={pos.volume} onChange={(e) => setPos(prev => ({ ...prev, volume: parseInt(e.target.value) || 1 }))} className="w-full p-2 border-2 border-stone-100 rounded text-stone-900 outline-none focus:border-amber-500" style={{ color: '#1c1917' }} /></div>
                  </div>
                  <button onClick={() => { setLastSearch(''); setViewMode(ViewMode.READ); }} className="w-full bg-amber-600 text-white py-4 rounded-xl hover:bg-amber-700 transition-all font-black shadow-lg">OUVRIR CES COORDONNÉES</button>
               </div>
            </div>
            <div className="bg-stone-100 rounded-2xl p-8 flex flex-col justify-center items-center text-center space-y-4 border-2 border-stone-200">
               <Info className="w-12 h-12 text-amber-700" />
               <p className="text-stone-500 text-sm leading-relaxed px-4 italic">"Une Bibliothèque infinie n'est pas une progression, c'est une simultanéité. Chaque point de l'espace est le centre d'une vérité absolue."</p>
            </div>
          </div>
        )}
      </main>

      <footer className="mt-auto bg-stone-200/30 border-t border-stone-200 p-8 text-center">
        <p className="font-serif italic text-stone-400 text-sm max-w-xl mx-auto">La Bibliothèque est illimitée et périodique.</p>
      </footer>
    </div>
  );
};

export default App;
