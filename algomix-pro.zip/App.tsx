
import React, { useState, useEffect, useCallback, useRef } from 'react';
import Deck from './components/Deck';
import Mixer from './components/Mixer';
import AlgoravePanel, { AlgoraveRef } from './components/AlgoravePanel';
import AiAssistant from './components/AiAssistant';
import LandingPage from './components/LandingPage';
import MixtrackMapper from './components/MixtrackMapper'; // IMPORT MAPPER
import { useAudioEngine } from './hooks/useAudioEngine';
import { useMidi } from './hooks/useMidi';
import { Track, PadMode, AiAction, AnalysisResult, MidiProfile, MappableAction, MidiCalibration } from './types';
import { generateMelodyTrack, analyzeAppInterface } from './services/geminiService';

const snapToValue = (value: number, snapPoint: number, threshold: number = 0.05) => {
  return Math.abs(value - snapPoint) < threshold ? snapPoint : value;
};

interface LibraryEntry {
    name: string;
    file: File;
}

// --- DEFAULT MIDI MAPPING (Fallback) ---
const DEFAULT_MAPPING: Record<string, MappableAction> = {
    // Deck A (Channel 0 usually)
    "0-0-note": "PLAY_A", "0-1-note": "CUE_A", "0-8-note": "PLATTER_TOUCH_A",
    "0-59-note": "PAD_MODE_CUE_A", "0-60-note": "PAD_MODE_LOOP_A", "0-61-note": "PAD_MODE_CUTS_A", "0-62-note": "PAD_MODE_SAMPLE_A",
    "0-20-note": "PAD_1_A", "0-21-note": "PAD_2_A", "0-22-note": "PAD_3_A", "0-23-note": "PAD_4_A",
    "0-28-cc": "VOL_A", "0-22-cc": "GAIN_A", "0-23-cc": "EQ_HI_A", "0-24-cc": "EQ_MID_A", "0-25-cc": "EQ_LOW_A", "0-26-cc": "FILTER_A",
    "0-9-cc": "PITCH_A", "0-6-cc": "PLATTER_MOVE_A",
    
    // Deck B (Channel 1 usually)
    "1-0-note": "PLAY_B", "1-1-note": "CUE_B", "1-8-note": "PLATTER_TOUCH_B",
    "1-59-note": "PAD_MODE_CUE_B", "1-60-note": "PAD_MODE_LOOP_B", "1-61-note": "PAD_MODE_CUTS_B", "1-62-note": "PAD_MODE_SAMPLE_B",
    "1-20-note": "PAD_1_B", "1-21-note": "PAD_2_B", "1-22-note": "PAD_3_B", "1-23-note": "PAD_4_B",
    "1-28-cc": "VOL_B", "1-22-cc": "GAIN_B", "1-23-cc": "EQ_HI_B", "1-24-cc": "EQ_MID_B", "1-25-cc": "EQ_LOW_B", "1-26-cc": "FILTER_B",
    "1-9-cc": "PITCH_B", "1-6-cc": "PLATTER_MOVE_B",

    // Global
    "0-8-cc": "CROSSFADER", "0-48-cc": "CROSSFADER" 
};

// --- MIXTRACK PRO FX OPTIMIZED PROFILE ---
const MIXTRACK_PRO_FX_PROFILE: { midiMap: Record<string, MappableAction>, midiCalibration: Record<string, MidiCalibration> } = {
  midiMap: {
    "0-0-note": "PLAY_A",
    "0-1-note": "CUE_A",
    "0-8-note": "PLATTER_TOUCH_A",
    "0-59-note": "PAD_MODE_CUE_A",
    "0-60-note": "PAD_MODE_LOOP_A",
    "0-61-note": "PAD_MODE_CUTS_A",
    "0-62-note": "PAD_MODE_SAMPLE_A",
    "0-20-note": "PAD_1_A",
    "0-21-note": "PAD_2_A",
    "0-22-note": "PAD_3_A",
    "0-23-note": "PAD_4_A",
    "0-28-cc": "VOL_A",
    "0-22-cc": "GAIN_A",
    "0-23-cc": "EQ_HI_A",
    "0-24-cc": "EQ_MID_A",
    "0-25-cc": "EQ_LOW_A",
    "0-26-cc": "FILTER_A",
    "0-9-cc": "PITCH_A",
    // Correction: 0-6-cc is Jog Move A, not Loop In/Out (which is usually a button)
    "0-6-cc": "PLATTER_MOVE_A", 
    
    "1-0-note": "PLAY_B",
    "1-1-note": "CUE_B",
    "1-8-note": "PLATTER_TOUCH_B",
    "1-59-note": "PAD_MODE_CUE_B",
    "1-60-note": "PAD_MODE_LOOP_B",
    "1-61-note": "PAD_MODE_CUTS_B",
    "1-62-note": "PAD_MODE_SAMPLE_B",
    "1-20-note": "PAD_1_B",
    "1-21-note": "PAD_2_B",
    "1-22-note": "PAD_3_B",
    "1-23-note": "PAD_4_B",
    // Correction: Ensure Channel 1 Volume controls Deck B
    "1-28-cc": "VOL_B", 
    "1-22-cc": "GAIN_B",
    "1-23-cc": "EQ_HI_B",
    "1-24-cc": "EQ_MID_B",
    "1-25-cc": "EQ_LOW_B",
    "1-26-cc": "FILTER_B",
    "1-9-cc": "PITCH_B",
    "1-6-cc": "PLATTER_MOVE_B",
    
    "0-8-cc": "CROSSFADER",
    "0-48-cc": "CROSSFADER",
    "0-2-note": "SYNC_A",
    "0-6-note": "PLATTER_TOUCH_A",
    "0-41-cc": "PITCH_A",
    "4-20-note": "PAD_1_A",
    "4-21-note": "PAD_2_A",
    "4-22-note": "PAD_3_A",
    "4-23-note": "PAD_4_A",
    "4-52-note": "LOOP_HALF_A",
    "4-53-note": "LOOP_DOUBLE_A",
    "4-64-note": "LOOP_IN_OUT_A",
    "15-8-cc": "CROSSFADER",
    "15-7-note": "BROWSE_PUSH",
    "15-0-cc": "BROWSE_SCROLL",
    "8-0-note": "FX_HPF",
    "8-4-cc": "FX_PADDLE_A",
    "9-4-cc": "FX_PADDLE_A",
    "8-5-cc": "FX_PADDLE_B",
    "9-5-cc": "FX_PADDLE_B",
    "8-1-note": "FX_LPF",
    "8-2-note": "FX_FLANGER",
    "9-3-note": "FX_ECHO",
    "9-4-note": "FX_REVERB",
    "9-5-note": "FX_PHASER",
    "1-2-note": "SYNC_B",
    "1-6-note": "PLATTER_TOUCH_B",
    "1-41-cc": "PITCH_B",
    "5-20-note": "PAD_1_B",
    "5-21-note": "PAD_2_B",
    "5-22-note": "PAD_3_B",
    "5-23-note": "PAD_4_B",
    "5-52-note": "LOOP_HALF_B",
    "5-53-note": "LOOP_DOUBLE_B",
    "5-64-note": "LOOP_IN_OUT_B"
  },
  midiCalibration: {
    "0-6-cc": { "min": 1, "max": 127 },
    "0-41-cc": { "min": 21, "max": 21 },
    "15-8-cc": { "min": 0, "max": 127 },
    "1-28-cc": { "min": 0, "max": 127 },
    "0-24-cc": { "min": 0, "max": 127 },
    "1-22-cc": { "min": 0, "max": 127 },
    "1-23-cc": { "min": 0, "max": 127 },
    "1-24-cc": { "min": 0, "max": 127 },
    "1-25-cc": { "min": 0, "max": 127 },
    "1-6-cc": { "min": 127, "max": 127 },
    "1-41-cc": { "min": 0, "max": 0 }
  }
};

// THEME GENERATOR ENGINE
const generateThemeFromHue = (hue: number) => {
    const root = document.documentElement;
    root.style.setProperty('--bg-main', `hsl(${hue}, 40%, 8%)`);
    root.style.setProperty('--bg-panel', `hsl(${hue}, 30%, 12%)`);
    root.style.setProperty('--bg-surface', `hsl(${hue}, 25%, 16%)`);
    root.style.setProperty('--accent', `hsl(${hue}, 70%, 60%)`);
    root.style.setProperty('--text-primary', `hsl(${hue}, 20%, 90%)`);
    root.style.setProperty('--text-secondary', `hsl(${hue}, 15%, 60%)`);
    root.style.setProperty('--border', `hsla(${hue}, 20%, 80%, 0.1)`);
    root.style.setProperty('--knob-body', `hsl(${hue}, 20%, 20%)`);
    
    const lightCss = `
        html.light {
            --bg-main: hsl(${hue}, 30%, 92%) !important;
            --bg-panel: hsl(${hue}, 25%, 86%) !important;
            --bg-surface: hsl(${hue}, 20%, 80%) !important;
            --text-primary: hsl(${hue}, 40%, 15%) !important;
            --text-secondary: hsl(${hue}, 30%, 40%) !important;
            --border: hsla(${hue}, 30%, 20%, 0.15) !important;
            --accent: hsl(${hue}, 80%, 45%) !important;
            --knob-body: hsl(${hue}, 20%, 90%) !important;
        }
    `;
    
    let styleTag = document.getElementById('dynamic-light-theme');
    if (!styleTag) {
        styleTag = document.createElement('style');
        styleTag.id = 'dynamic-light-theme';
        document.head.appendChild(styleTag);
    }
    styleTag.textContent = lightCss;
};

function App() {
  const [hasLaunched, setHasLaunched] = useState(false); 
  const [isAnimating, setIsAnimating] = useState(false); 

  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [customStyle, setCustomStyle] = useState<string>("Défaut");
  
  const [showSettings, setShowSettings] = useState(false);
  const [showAssistant, setShowAssistant] = useState(false); 
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  // NEW: State for Visual Mapper Modal
  const [showVisualMapper, setShowVisualMapper] = useState(false);

  const [visualsEnabled, setVisualsEnabled] = useState(true);
  const [userLanguage, setUserLanguage] = useState("Français (France)");

  // ANALYSIS STATE
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [showAnalysis, setShowAnalysis] = useState(false);

  // MIDI MAPPING STATE
  const [isMappingMode, setIsMappingMode] = useState(false);
  const [waitingForMidi, setWaitingForMidi] = useState<MappableAction | null>(null);
  const [lastMappedInfo, setLastMappedInfo] = useState<{ action: string, key: string } | null>(null);
  const [midiMap, setMidiMap] = useState<Record<string, MappableAction>>(DEFAULT_MAPPING);
  const [midiCalibration, setMidiCalibration] = useState<Record<string, MidiCalibration>>({});
  const [currentDeviceName, setCurrentDeviceName] = useState("Generic MIDI");
  
  // NEW: PENDING MAPPING STATE WITH CALIBRATION
  const [pendingMapping, setPendingMapping] = useState<{ key: string, val: number, min?: number, max?: number } | null>(null);
  
  // NEW: ACTIVE ACTION FEEDBACK
  const [lastActiveAction, setLastActiveAction] = useState<MappableAction | null>(null);

  const mappingFileRef = useRef<HTMLInputElement>(null);
  const importConfigRef = useRef<HTMLInputElement>(null);
  const customCssRef = useRef<HTMLStyleElement | null>(null);

  // LIBRARY STATE
  const [libraryFiles, setLibraryFiles] = useState<LibraryEntry[]>([]);
  const [activeLibraryDeck, setActiveLibraryDeck] = useState<'A' | 'B' | null>(null);
  const dirInputRef = useRef<HTMLInputElement>(null);

  const algoraveRef = useRef<AlgoraveRef>(null);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'light') root.classList.add('light');
    else root.classList.remove('light');
  }, [theme]);

  useEffect(() => {
      if (!customCssRef.current) {
          const style = document.createElement('style');
          style.id = "ai-custom-css";
          document.head.appendChild(style);
          customCssRef.current = style;
      }
  }, []);

  const { 
    initAudio, loadTrack, loadTrackFromBuffer, renderAudioFromMelody, playPause, 
    setVolume, setGain, setFilter, setPlaybackRate, 
    touchPlatter, movePlatter, toggleScratchMode,
    playAlgoraveSound,
    loadSample, triggerSample, samples,
    waveformDataA, waveformDataB, progressA, progressB,
    seek,
    setHotCue, triggerHotCue, toggleLoop, toggleFaderCut, toggleCue,
    // Hardware specific
    resizeLoop, toggleFx,
    // Output
    availableDevices, setCueOutputDevice, selectedCueDeviceId
  } = useAudioEngine();

  const [trackA, setTrackA] = useState<Track | null>(null);
  const [trackB, setTrackB] = useState<Track | null>(null);
  
  const [faderA, setFaderA] = useState(1);
  const [faderB, setFaderB] = useState(1);
  const [crossfader, setCrossfaderVal] = useState(0.5);
  
  const [pitchA, setPitchA] = useState(1.0);
  const [pitchB, setPitchB] = useState(1.0);

  const [eqHighA, setEqHighA] = useState(0); const [eqMidA, setEqMidA] = useState(0); const [eqLowA, setEqLowA] = useState(0); const [gainA, setGainStateA] = useState(0.5); const [filterKnobA, setFilterKnobA] = useState(0.5);
  const [eqHighB, setEqHighB] = useState(0); const [eqMidB, setEqMidB] = useState(0); const [eqLowB, setEqLowB] = useState(0); const [gainB, setGainStateB] = useState(0.5); const [filterKnobB, setFilterKnobB] = useState(0.5);

  const [isPlayingA, setIsPlayingA] = useState(false);
  const [isPlayingB, setIsPlayingB] = useState(false);
  const [lastMidi, setLastMidi] = useState<string>("-");
  const [midiActivity, setMidiActivity] = useState(false);
  const [selectedMidiId, setSelectedMidiId] = useState<string | null>(null);

  const [padModeA, setPadModeA] = useState<PadMode>('cue');
  const [padModeB, setPadModeB] = useState<PadMode>('cue');
  
  const togglePlayA = () => { if (trackA) { playPause('A'); setIsPlayingA(prev => !prev); } };
  const togglePlayB = () => { if (trackB) { playPause('B'); setIsPlayingB(prev => !prev); } };

  const handleSync = (deck: 'A' | 'B') => {
      const targetDeck = deck;
      const masterDeck = deck === 'A' ? 'B' : 'A';
      const targetTrack = deck === 'A' ? trackA : trackB;
      const masterTrack = deck === 'A' ? trackB : trackA;
      
      if (targetTrack && masterTrack && masterTrack.bpm && targetTrack.bpm) {
          const masterPitch = deck === 'A' ? pitchB : pitchA;
          const masterBpm = masterTrack.bpm * masterPitch;
          const newPitch = masterBpm / targetTrack.bpm;
          if (deck === 'A') { setPitchA(newPitch); setPlaybackRate('A', newPitch); } 
          else { setPitchB(newPitch); setPlaybackRate('B', newPitch); }
      }
  };

  useEffect(() => {
    setVolume('A', faderA * (crossfader > 0.5 ? 2 * (1 - crossfader) : 1));
    setVolume('B', faderB * (crossfader < 0.5 ? 2 * crossfader : 1));
  }, [faderA, faderB, crossfader, setVolume]);

  const handleLaunch = () => {
    setIsAnimating(true);
    initAudio();
    setTimeout(() => { setHasLaunched(true); }, 100); 
  };
  
  const handleQuit = () => {
      if (isPlayingA) togglePlayA();
      if (isPlayingB) togglePlayB();
      if (document.fullscreenElement) {
          document.exitFullscreen().catch(e => console.error(e));
          setIsFullscreen(false);
      }
      setHasLaunched(false);
      setIsAnimating(false);
  };

  const toggleFullScreen = () => {
      if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().catch(e => console.log(e)).then(() => setIsFullscreen(true));
      } else {
          if (document.exitFullscreen) {
              document.exitFullscreen().then(() => setIsFullscreen(false));
          }
      }
  };

  const handleMidiLearn = (action: MappableAction) => { 
      setWaitingForMidi(action); 
      setPendingMapping(null);
      // Ensure mapping mode is active if we click on the image
      if (!isMappingMode) setIsMappingMode(true);
  };

  const confirmMapping = () => {
      if (waitingForMidi && pendingMapping) {
          setMidiMap(prev => ({ ...prev, [pendingMapping.key]: waitingForMidi }));
          
          if (pendingMapping.min !== undefined && pendingMapping.max !== undefined) {
             setMidiCalibration(prev => ({ ...prev, [pendingMapping.key]: { min: pendingMapping.min!, max: pendingMapping.max! } }));
          }
          
          setLastMappedInfo({ action: waitingForMidi, key: pendingMapping.key });
          setWaitingForMidi(null);
          setPendingMapping(null);
      }
  };

  const handleExportConfig = () => {
      const config = {
          theme: theme,
          midiMap: midiMap,
          midiCalibration: midiCalibration,
          userLanguage: userLanguage,
          customStyle: customStyle
      };
      const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `algomix_mixtrack_profile_${new Date().toISOString().slice(0,10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
  };

  const handleImportConfig = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
          try {
              const config = JSON.parse(ev.target?.result as string);
              if (config.midiMap) setMidiMap(config.midiMap);
              if (config.midiCalibration) setMidiCalibration(config.midiCalibration);
              if (config.theme) setTheme(config.theme);
              if (config.userLanguage) setUserLanguage(config.userLanguage);
              if (config.customStyle) setCustomStyle(config.customStyle);
              alert("Configuration chargée avec succès !");
          } catch(err) {
              alert("Erreur lors du chargement de la configuration.");
          }
      };
      reader.readAsText(file);
  };

  const onMidiMessage = useCallback((msg: { command: number, note: number, velocity: number }) => {
    const channel = msg.command & 0x0F;
    const status = msg.command & 0xF0;
    const type = status === 0xB0 ? 'cc' : 'note'; 
    const key = `${channel}-${msg.note}-${type}`;
    
    // Activity Indicator
    setLastMidi(`${key} Val:${msg.velocity}`);
    setMidiActivity(true);
    setTimeout(() => setMidiActivity(false), 100);

    // MAPPING WIZARD LOGIC
    if (isMappingMode && waitingForMidi) {
        // --- 1. Auto-Map Buttons Logic ---
        const isAnalog = waitingForMidi.includes('VOL') || waitingForMidi.includes('GAIN') || waitingForMidi.includes('EQ') || waitingForMidi.includes('CROSS') || waitingForMidi.includes('PITCH');
        const isButton = !isAnalog && !waitingForMidi.includes('MOVE');

        if (isButton) {
            // For buttons, map instantly on Press (velocity > 0 or 64)
            if ((type === 'note' && msg.velocity > 0) || (type === 'cc' && msg.velocity > 64)) {
                // Auto Confirm
                setMidiMap(prev => ({ ...prev, [key]: waitingForMidi }));
                setWaitingForMidi(null);
                return;
            }
        } else {
            // --- 2. Calibration Logic for Analog ---
            // Allows reading 0 if type is cc
            setPendingMapping(prev => {
                if (prev && prev.key === key) {
                    // Update min/max if same key
                    return { 
                        key, 
                        val: msg.velocity, 
                        min: Math.min(prev.min ?? 127, msg.velocity), 
                        max: Math.max(prev.max ?? 0, msg.velocity) 
                    };
                } else {
                    // New key detected
                    return { key, val: msg.velocity, min: msg.velocity, max: msg.velocity };
                }
            });
        }
        return; 
    }

    const action = midiMap[key];
    if (!action) return;
    
    // --- FLASH FEEDBACK IN MAPPER ---
    if (isMappingMode) {
        setLastActiveAction(action);
        // Clear flash after short delay
        setTimeout(() => setLastActiveAction(null), 300);
    }
    
    // --- 3. APPLY CALIBRATION ---
    let normalizedValue = msg.velocity / 127;
    const calibration = midiCalibration[key];
    if (calibration) {
        // Clamp to calibrated range
        const raw = Math.max(calibration.min, Math.min(calibration.max, msg.velocity));
        // Normalize 0-1 based on range
        if (calibration.max !== calibration.min) {
            normalizedValue = (raw - calibration.min) / (calibration.max - calibration.min);
        }
    }

    const valNorm = normalizedValue;
    const isNoteOn = (status === 0x90 && msg.velocity > 0);
    const isTrigger = isNoteOn || (type === 'cc' && msg.velocity > 64);
    const targetDeck = action.endsWith('_A') ? 'A' : (action.endsWith('_B') ? 'B' : null);

    switch(action) {
        case 'PLAY_A': if(isTrigger) { togglePlayA(); } break;
        case 'PLAY_B': if(isTrigger) { togglePlayB(); } break;
        case 'CUE_A': if(isTrigger) seek('A', 0); break;
        case 'CUE_B': if(isTrigger) seek('B', 0); break;
        case 'SYNC_A': if(isTrigger) handleSync('A'); break;
        case 'SYNC_B': if(isTrigger) handleSync('B'); break;
        case 'LOAD_A': if(isTrigger) setActiveLibraryDeck('A'); break;
        case 'LOAD_B': if(isTrigger) setActiveLibraryDeck('B'); break;
        case 'VOL_A': setFaderA(valNorm); break;
        case 'VOL_B': setFaderB(valNorm); break;
        case 'CROSSFADER': setCrossfaderVal(snapToValue(valNorm, 0.5, 0.02)); break;
        case 'GAIN_A': setGain('A', valNorm); setGainStateA(valNorm); break;
        case 'GAIN_B': setGain('B', valNorm); setGainStateB(valNorm); break;
        case 'EQ_HI_A': { const db = snapToValue((valNorm * 50) - 40, 0, 2); setFilter('A', 'high', db); setEqHighA(db); break; }
        case 'EQ_MID_A': { const db = snapToValue((valNorm * 50) - 40, 0, 2); setFilter('A', 'mid', db); setEqMidA(db); break; }
        case 'EQ_LOW_A': { const db = snapToValue((valNorm * 50) - 40, 0, 2); setFilter('A', 'low', db); setEqLowA(db); break; }
        case 'FILTER_A': { const f = snapToValue(valNorm, 0.5, 0.05); setFilter('A', 'sweep', f); setFilterKnobA(f); break; }
        case 'EQ_HI_B': { const db = snapToValue((valNorm * 50) - 40, 0, 2); setFilter('B', 'high', db); setEqHighB(db); break; }
        case 'EQ_MID_B': { const db = snapToValue((valNorm * 50) - 40, 0, 2); setFilter('B', 'mid', db); setEqMidB(db); break; }
        case 'EQ_LOW_B': { const db = snapToValue((valNorm * 50) - 40, 0, 2); setFilter('B', 'low', db); setEqLowB(db); break; }
        case 'FILTER_B': { const f = snapToValue(valNorm, 0.5, 0.05); setFilter('B', 'sweep', f); setFilterKnobB(f); break; }
        case 'PITCH_A': { const pitchVal = 0.92 + (valNorm * 0.16); const snapped = snapToValue(pitchVal, 1.0, 0.003); setPitchA(snapped); setPlaybackRate('A', snapped); break; }
        case 'PITCH_B': { const pitchVal = 0.92 + (valNorm * 0.16); const snapped = snapToValue(pitchVal, 1.0, 0.003); setPitchB(snapped); setPlaybackRate('B', snapped); break; }
        
        case 'PITCH_BEND_UP_A': if(isTrigger) setPlaybackRate('A', pitchA + 0.02); else setPlaybackRate('A', pitchA); break;
        case 'PITCH_BEND_DOWN_A': if(isTrigger) setPlaybackRate('A', pitchA - 0.02); else setPlaybackRate('A', pitchA); break;
        case 'PITCH_BEND_UP_B': if(isTrigger) setPlaybackRate('B', pitchB + 0.02); else setPlaybackRate('B', pitchB); break;
        case 'PITCH_BEND_DOWN_B': if(isTrigger) setPlaybackRate('B', pitchB - 0.02); else setPlaybackRate('B', pitchB); break;

        // JOGWHEEL
        case 'PLATTER_TOUCH_A': touchPlatter('A', 'vinyl', isNoteOn); break;
        case 'PLATTER_TOUCH_B': touchPlatter('B', 'vinyl', isNoteOn); break;
        case 'PLATTER_MOVE_A': { const delta = msg.velocity > 64 ? msg.velocity - 128 : msg.velocity; movePlatter('A', delta * 3); break; }
        case 'PLATTER_MOVE_B': { const delta = msg.velocity > 64 ? msg.velocity - 128 : msg.velocity; movePlatter('B', delta * 3); break; }
        
        case 'SCRATCH_MODE_A': if(isTrigger) toggleScratchMode('A'); break;
        case 'SCRATCH_MODE_B': if(isTrigger) toggleScratchMode('B'); break;

        case 'PAD_MODE_CUE_A': if(isTrigger) setPadModeA('cue'); break;
        case 'PAD_MODE_LOOP_A': if(isTrigger) setPadModeA('loop'); break;
        case 'PAD_MODE_CUTS_A': if(isTrigger) setPadModeA('cuts'); break;
        case 'PAD_MODE_SAMPLE_A': if(isTrigger) setPadModeA('sample'); break;
        case 'PAD_MODE_CUE_B': if(isTrigger) setPadModeB('cue'); break;
        case 'PAD_MODE_LOOP_B': if(isTrigger) setPadModeB('loop'); break;
        case 'PAD_MODE_CUTS_B': if(isTrigger) setPadModeB('cuts'); break;
        case 'PAD_MODE_SAMPLE_B': if(isTrigger) setPadModeB('sample'); break;
        
        // --- NEW HARDWARE ACTIONS ---
        case 'LOOP_HALF_A': if(isTrigger) resizeLoop('A', 0.5); break;
        case 'LOOP_DOUBLE_A': if(isTrigger) resizeLoop('A', 2.0); break;
        case 'LOOP_IN_OUT_A': if(isTrigger) toggleLoop('A', 4, -1); break; // Basic 4-beat loop on press

        case 'LOOP_HALF_B': if(isTrigger) resizeLoop('B', 0.5); break;
        case 'LOOP_DOUBLE_B': if(isTrigger) resizeLoop('B', 2.0); break;
        case 'LOOP_IN_OUT_B': if(isTrigger) toggleLoop('B', 4, -1); break;

        case 'FX_FLANGER': if(isTrigger) { toggleFx('A', 'flanger'); toggleFx('B', 'flanger'); } break;
        case 'FX_ECHO': if(isTrigger) { toggleFx('A', 'echo'); toggleFx('B', 'echo'); } break;
        case 'FX_REVERB': if(isTrigger) { toggleFx('A', 'reverb'); toggleFx('B', 'reverb'); } break;
        case 'FX_PHASER': if(isTrigger) { toggleFx('A', 'flanger'); toggleFx('B', 'flanger'); } break; // Reusing flanger for now
        case 'FX_PADDLE_A': if(isNoteOn) toggleFx('A', 'reverb'); else toggleFx('A', 'none'); break; // Simple hold logic
        case 'FX_PADDLE_B': if(isNoteOn) toggleFx('B', 'reverb'); else toggleFx('B', 'none'); break;

        case 'BROWSE_SCROLL': 
             // Logic to scroll library could go here, for now just logging
             console.log("Browse Scroll", msg.velocity);
             break;
        case 'BROWSE_PUSH':
             if(isTrigger) setShowSettings(prev => !prev);
             break;

        default:
            if (isTrigger && targetDeck) {
                if (action.startsWith('PAD_')) {
                    const padNum = parseInt(action.split('_')[2]);
                    const padIndex = padNum - 1; 
                    const sampleId = (targetDeck === 'A' ? 0 : 4) + padIndex;
                    triggerSample(sampleId);
                }
            }
            break;
    }
  }, [isMappingMode, waitingForMidi, midiMap, midiCalibration, padModeA, padModeB, togglePlayA, togglePlayB, handleSync, seek, setFaderA, setFaderB, setCrossfaderVal, setGain, setFilter, setPlaybackRate, touchPlatter, movePlatter, setPadModeA, setPadModeB, triggerSample, pendingMapping, resizeLoop, toggleFx, pitchA, pitchB]); 

  const { inputs: midiInputs, connectInput } = useMidi(onMidiMessage);
  
  // DEVICE DETECTION & AUTO-PROFILE INJECTION
  useEffect(() => {
     if (midiInputs.length > 0 && !selectedMidiId) {
         const d = midiInputs.find(i => i.name.toLowerCase().includes('mixtrack') || i.name.toLowerCase().includes('numark'));
         if (d) { 
             connectInput(d.id); 
             setSelectedMidiId(d.id); 
             setCurrentDeviceName(d.name);
             
             // INJECT MIXTRACK PRO FX DEFAULT MAP & CALIBRATION
             console.log("Mixtrack Detected: Injecting Optimized Profile...");
             setMidiMap(prev => ({ ...prev, ...MIXTRACK_PRO_FX_PROFILE.midiMap }));
             setMidiCalibration(prev => ({ ...prev, ...MIXTRACK_PRO_FX_PROFILE.midiCalibration }));
         }
     }
  }, [midiInputs, selectedMidiId, connectInput]);

  const handleRenderAudio = async (prompt: string, context: string, duration: number) => {
      return await renderAudioFromMelody(await generateMelodyTrack(prompt, context, duration) || {name:'', bpm:128, notes:[]});
  };

  const handleLoadGeneratedTrack = (deck: 'A' | 'B', buffer: AudioBuffer, name: string, cover?: string) => {
      const t = loadTrackFromBuffer(deck, buffer, name, cover);
      if (deck === 'A') setTrackA(t); else setTrackB(t);
  };

  const connectLibrary = async () => {
      try {
          if ('showDirectoryPicker' in window) {
              // @ts-ignore
              const handle = await window.showDirectoryPicker();
              const files: LibraryEntry[] = [];
              for await (const entry of handle.values()) {
                  if (entry.kind === 'file') {
                      const name = entry.name.toLowerCase();
                      if (name.endsWith('.mp3') || name.endsWith('.wav') || name.endsWith('.ogg') || name.endsWith('.m4a')) {
                          files.push({ name: entry.name, file: await entry.getFile() });
                      }
                  }
              }
              setLibraryFiles(files);
          } else { throw new Error("API not supported"); }
      } catch (err) { dirInputRef.current?.click(); }
  };
  
  const handleDirectorySelect = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files) {
          const files: LibraryEntry[] = [];
          Array.from(e.target.files).forEach(file => {
              const name = file.name.toLowerCase();
              if (name.endsWith('.mp3') || name.endsWith('.wav') || name.endsWith('.ogg')) files.push({ name: file.name, file: file });
          });
          setLibraryFiles(files);
      }
  };
  
  const loadTrackFromLibrary = async (deck: 'A' | 'B', fileName: string) => {
      const fileEntry = libraryFiles.find(f => f.name === fileName);
      if (fileEntry && fileEntry.file) {
          try {
            const t = await loadTrack(deck, fileEntry.file, undefined);
            if (t) { if (deck === 'A') setTrackA(t); else setTrackB(t); }
          } catch(e) { console.error("Failed to load file", e); }
      }
  };
  
  const getContextString = () => {
      const libraryContext = libraryFiles.length > 0 
        ? `\n[BIBLIOTHÈQUE LOCALE (${libraryFiles.length})]: ${libraryFiles.map(f => f.name).slice(0, 100).join(", ")}` : "\n[BIBLIOTHÈQUE]: Non connectée.";
      const visualState = `[ÉTAT VISUEL]\nThème Mode: ${theme}\nCustom Style Actif: ${customStyle}`;
      return `ÉTAT AUDIO:\nDeck A: ${trackA ? trackA.name : 'Vide'} (${isPlayingA ? 'Joue' : 'Pause'}), Vol: ${Math.round(faderA*100)}%\nDeck B: ${trackB ? trackB.name : 'Vide'} (${isPlayingB ? 'Joue' : 'Pause'}), Vol: ${Math.round(faderB*100)}%\nCrossfader: ${Math.round(crossfader*100)}%\n${visualState}\n${libraryContext}`;
  };

  const runAnalysis = async () => {
      setIsAnalyzing(true);
      setShowAnalysis(true);
      const rawDom = document.getElementById('layout-main')?.innerHTML || "";
      const strippedDom = rawDom.replace(/<path[^>]*>/g, '<path>').replace(/<script[\s\S]*?<\/script>/g, '');
      const context = getContextString();
      const result = await analyzeAppInterface(strippedDom.substring(0, 20000), context, userLanguage);
      setAnalysisResult(result);
      setIsAnalyzing(false);
  };

  const copyPrompt = () => {
      if (analysisResult?.actionPrompt) {
          navigator.clipboard.writeText(analysisResult.actionPrompt);
      }
  };

  const executeAiAction = async (action: AiAction) => {
      if (action.type === 'WAIT') { await new Promise(r => setTimeout(r, action.value || 1000)); return; }
      switch(action.type) {
          case 'PLAY_A': if(!isPlayingA) togglePlayA(); break;
          case 'STOP_A': if(isPlayingA) togglePlayA(); break;
          case 'PLAY_B': if(!isPlayingB) togglePlayB(); break;
          case 'STOP_B': if(isPlayingB) togglePlayB(); break;
          case 'SYNC_A': handleSync('A'); break;
          case 'SYNC_B': handleSync('B'); break;
          case 'VOL_A': if(action.value !== undefined) setFaderA(action.value); break;
          case 'VOL_B': if(action.value !== undefined) setFaderB(action.value); break;
          case 'CROSSFADER': if(action.value !== undefined) setCrossfaderVal(action.value); break;
          case 'EQ_HIGH_A': if(action.value !== undefined) { setEqHighA(action.value); setFilter('A', 'high', action.value); } break;
          case 'EQ_MID_A': if(action.value !== undefined) { setEqMidA(action.value); setFilter('A', 'mid', action.value); } break;
          case 'EQ_LOW_A': if(action.value !== undefined) { setEqLowA(action.value); setFilter('A', 'low', action.value); } break;
          case 'FILTER_A': if(action.value !== undefined) { setFilterKnobA(action.value); setFilter('A', 'sweep', action.value); } break;
          case 'GAIN_A': if(action.value !== undefined) { setGainStateA(action.value); setGain('A', action.value); } break;
          case 'EQ_HIGH_B': if(action.value !== undefined) { setEqHighB(action.value); setFilter('B', 'high', action.value); } break;
          case 'EQ_MID_B': if(action.value !== undefined) { setEqMidB(action.value); setFilter('B', 'mid', action.value); } break;
          case 'EQ_LOW_B': if(action.value !== undefined) { setEqLowB(action.value); setFilter('B', 'low', action.value); } break;
          case 'FILTER_B': if(action.value !== undefined) { setFilterKnobB(action.value); setFilter('B', 'sweep', action.value); } break;
          case 'GAIN_B': if(action.value !== undefined) { setGainStateB(action.value); setGain('B', action.value); } break;
          case 'PITCH_A': if(action.value !== undefined) { setPitchA(action.value); setPlaybackRate('A', action.value); } break;
          case 'PITCH_B': if(action.value !== undefined) { setPitchB(action.value); setPlaybackRate('B', action.value); } break;
          case 'LOAD_TRACK_A': if(action.text) loadTrackFromLibrary('A', action.text); break;
          case 'LOAD_TRACK_B': if(action.text) loadTrackFromLibrary('B', action.text); break;
          case 'MAESTRO_TYPE': if(action.text && algoraveRef.current) algoraveRef.current.simulateTyping(action.text); break;
          case 'TOGGLE_FULLSCREEN': toggleFullScreen(); break;
          case 'SET_THEME_MODE': if(action.text === 'light' || action.text === 'dark') setTheme(action.text); break;
          case 'SET_UI_STYLE':
              if (action.text) {
                  try {
                      const styles = JSON.parse(action.text);
                      if (styles.hue !== undefined) { generateThemeFromHue(styles.hue); setCustomStyle(`Hue: ${styles.hue}`); return; }
                  } catch(e) { console.error(e); }
              }
              break;
          case 'SET_DOM_CONTENT':
              if (action.text) {
                  try {
                      const data = JSON.parse(action.text);
                      if (data.selector && data.content) {
                          const element = document.querySelector(data.selector);
                          if (element) element.innerHTML = data.content;
                      }
                  } catch(e) { console.error("Failed to parse DOM content JSON", e); }
              }
              break;
      }
  };

  if (!hasLaunched) {
    return <LandingPage onLaunch={handleLaunch} onToggleTheme={() => setTheme(theme === 'dark' ? 'light' : 'dark')} onToggleFullscreen={toggleFullScreen} isDark={theme === 'dark'} />;
  }

  return (
    <div className="h-screen w-screen bg-[#0f1715] perspective-1000 overflow-hidden flex flex-col text-[var(--text-primary)] relative">
        <input type="file" ref={dirInputRef} {...({ webkitdirectory: "true", directory: "true" } as any)} multiple className="hidden" onChange={handleDirectorySelect} />
        
        {/* LIBRARY BROWSER MODAL (Prevents exiting Fullscreen) */}
        {activeLibraryDeck && (
            <div className="absolute inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-8 animate-[fadeIn_0.2s]">
                <div className="bg-[var(--bg-panel)] border border-[var(--accent)] w-full max-w-2xl max-h-[80vh] flex flex-col rounded-xl shadow-[0_0_50px_rgba(0,0,0,0.5)] modal-anim overflow-hidden">
                     {/* Header */}
                     <div className="p-4 border-b border-[var(--border)] flex justify-between items-center bg-[var(--bg-surface)]">
                         <div className="flex items-center gap-3">
                            <span className="text-2xl">📂</span>
                            <div>
                                <h3 className="font-serif italic text-xl text-[var(--text-primary)]">Library Browser</h3>
                                <p className="text-[10px] text-[var(--text-secondary)] font-mono uppercase tracking-widest">Select track for Deck {activeLibraryDeck}</p>
                            </div>
                         </div>
                         <button onClick={() => setActiveLibraryDeck(null)} className="w-8 h-8 rounded-full border border-[var(--border)] hover:bg-[var(--accent)] hover:text-black transition-colors flex items-center justify-center">✕</button>
                     </div>
                     
                     {/* List */}
                     <div className="overflow-y-auto p-2 flex-1 space-y-1">
                         {libraryFiles.length === 0 ? (
                             <div className="flex flex-col items-center justify-center h-full text-[var(--text-secondary)] opacity-60 gap-4">
                                 <p>No files connected.</p>
                                 <button onClick={connectLibrary} className="px-4 py-2 border border-[var(--accent)] text-[var(--accent)] rounded hover:bg-[var(--accent)] hover:text-black transition-colors">Connect Local Folder</button>
                             </div>
                         ) : (
                             libraryFiles.map((f, idx) => (
                                 <div 
                                    key={idx} 
                                    onClick={() => { loadTrackFromLibrary(activeLibraryDeck, f.name); setActiveLibraryDeck(null); }}
                                    className="p-3 hover:bg-[var(--bg-surface)] border border-transparent hover:border-[var(--border)] rounded cursor-pointer flex justify-between items-center group transition-all"
                                 >
                                    <span className="font-mono text-xs text-[var(--text-primary)] group-hover:text-[var(--accent)]">{f.name}</span>
                                    <span className="text-[10px] opacity-0 group-hover:opacity-100 transition-opacity text-[var(--text-secondary)]">LOAD ➜</span>
                                 </div>
                             ))
                         )}
                     </div>
                     <div className="p-2 border-t border-[var(--border)] bg-[var(--bg-surface)] text-center text-[10px] text-[var(--text-secondary)]">
                         PRO TIP: You can also Drag & Drop files directly onto the decks.
                     </div>
                </div>
            </div>
        )}

        {/* FULLSCREEN VISUAL MAPPER MODAL */}
        {showVisualMapper && (
            <div className="absolute inset-0 z-[70] bg-black/95 flex flex-col animate-[fadeIn_0.3s]">
                <div className="flex justify-between items-center p-6 border-b border-[var(--border)] bg-[var(--bg-panel)]">
                    <div className="flex items-center gap-4">
                        <div className="text-3xl">🎛</div>
                        <div>
                            <h2 className="text-xl font-serif italic text-[var(--accent)]">Visual Mapper: Mixtrack Pro FX</h2>
                            <p className="text-[10px] text-[var(--text-secondary)] font-mono">Select a row, then move the control on your hardware.</p>
                        </div>
                    </div>
                    <button 
                        onClick={() => setShowVisualMapper(false)}
                        className="px-6 py-2 border border-[var(--border)] rounded-full hover:bg-white hover:text-black transition-colors uppercase text-xs font-bold tracking-widest"
                    >
                        CLOSE MAPPER
                    </button>
                </div>
                <div className="flex-1 overflow-auto p-8 flex items-center justify-center bg-[var(--bg-main)]">
                    <MixtrackMapper 
                        onMapClick={handleMidiLearn} 
                        waitingForAction={waitingForMidi} 
                        pendingMapping={pendingMapping}
                        lastActiveAction={lastActiveAction} // Pass active action for flash feedback
                        onConfirm={confirmMapping}
                        onCancel={() => { setWaitingForMidi(null); setPendingMapping(null); }}
                        onExport={handleExportConfig}
                    />
                </div>
            </div>
        )}

        {/* SETTINGS MODAL */}
        {showSettings && !showVisualMapper && (
            <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={(e) => { if(e.target === e.currentTarget) setShowSettings(false) }}>
                <div className="bg-[var(--bg-panel)] border border-[var(--border)] p-8 rounded-lg shadow-2xl max-w-4xl w-full modal-anim max-h-[90vh] overflow-y-auto flex flex-col">
                    <div className="flex justify-between items-center mb-6"><h2 className="font-serif text-3xl italic">Settings</h2><button onClick={() => setShowSettings(false)} className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] anim-pop">✕</button></div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                         {/* LEFT COL */}
                         <div className="space-y-6">
                            {/* MIDI SETTINGS */}
                            <div className="space-y-2">
                                <label className="text-xs uppercase tracking-widest opacity-60 block">MIDI Configuration</label>
                                <div className="text-xs font-mono text-[var(--text-secondary)] p-2 bg-[var(--bg-surface)] rounded border border-[var(--border)] mb-2">LAST IN: {lastMidi}</div>
                                <select className="w-full bg-[var(--bg-surface)] border border-[var(--border)] p-3 rounded text-sm outline-none" onChange={(e) => { connectInput(e.target.value); setSelectedMidiId(e.target.value); setCurrentDeviceName(midiInputs.find(i => i.id === e.target.value)?.name || "Generic"); }} value={selectedMidiId || ""}><option value="" disabled>Select MIDI Device...</option>{midiInputs.map(input => (<option key={input.id} value={input.id}>{input.name}</option>))}</select>
                            </div>
                            
                            {/* AUDIO OUTPUT SETTINGS (BLUETOOTH) */}
                            <div className="space-y-2 pt-4 border-t border-[var(--border)]">
                                <label className="text-xs uppercase tracking-widest opacity-60 block flex items-center gap-2">
                                    <span>🎧</span> Cue Output (Bluetooth)
                                </label>
                                <p className="text-[10px] text-[var(--text-secondary)] mb-2">Select a specific device for pre-listening (Cue). Requires Bluetooth headphones paired to OS.</p>
                                <select 
                                    className="w-full bg-[var(--bg-surface)] border border-[var(--border)] p-3 rounded text-sm outline-none" 
                                    onChange={(e) => setCueOutputDevice(e.target.value)} 
                                    value={selectedCueDeviceId || ""}
                                >
                                    <option value="">Default System Output</option>
                                    {availableDevices.map((device, idx) => (
                                        <option key={device.deviceId || idx} value={device.deviceId}>
                                            {device.label || `Audio Device ${idx + 1}`}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            <div className="space-y-2">
                                <label className="text-xs uppercase tracking-widest opacity-60 block">AI Language Context</label>
                                <input 
                                    type="text" 
                                    value={userLanguage} 
                                    onChange={(e) => setUserLanguage(e.target.value)}
                                    className="w-full bg-[var(--bg-surface)] border border-[var(--border)] p-3 rounded text-sm outline-none focus:border-[var(--accent)]"
                                    placeholder="e.g. Français (Québec), Deutsch, English (UK)"
                                />
                            </div>
                         </div>

                         {/* RIGHT COL */}
                         <div className="space-y-6">
                            <button onClick={connectLibrary} className="w-full bg-[var(--bg-surface)] border border-[var(--border)] p-3 rounded text-sm hover:border-[var(--accent)] transition-colors text-left">{libraryFiles.length > 0 ? `📂 ${libraryFiles.length} files` : 'Link Music Folder...'}</button>
                            
                            <div className="p-3 bg-[var(--bg-surface)] rounded border border-[var(--border)]">
                                <label className="text-xs uppercase tracking-widest opacity-60 block mb-2">Sauvegarde / Restauration</label>
                                <div className="flex gap-2">
                                    <button onClick={handleExportConfig} className="flex-1 bg-[var(--bg-main)] border border-[var(--border)] py-2 text-xs rounded hover:border-[var(--accent)] transition-colors">EXPORTER</button>
                                    <button onClick={() => importConfigRef.current?.click()} className="flex-1 bg-[var(--bg-main)] border border-[var(--border)] py-2 text-xs rounded hover:border-[var(--accent)] transition-colors">IMPORTER</button>
                                    <input type="file" ref={importConfigRef} className="hidden" accept=".json" onChange={handleImportConfig} />
                                </div>
                            </div>
                         </div>
                    </div>
                    
                    {/* HARDWARE MAPPER BUTTON */}
                    {(currentDeviceName.toLowerCase().includes('mixtrack') || currentDeviceName.toLowerCase().includes('numark') || true) && (
                        <div className="border-t border-[var(--border)] pt-6">
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="font-bold text-sm text-[var(--accent)] uppercase tracking-wider">Visual Mapping</h3>
                                <div className="text-[10px] text-[var(--text-secondary)]">Interact with a virtual controller to map functions.</div>
                            </div>
                            <button 
                                onClick={() => setShowVisualMapper(true)}
                                className="w-full py-4 bg-[var(--bg-surface)] border border-[var(--accent)] text-[var(--accent)] rounded-lg font-bold hover:bg-[var(--accent)] hover:text-black transition-all flex items-center justify-center gap-2"
                            >
                                <span className="text-xl">🎛</span> OUVRIR LE MAPPER VISUEL
                            </button>
                        </div>
                    )}

                </div>
            </div>
        )}

        <AiAssistant isOpen={showAssistant} onClose={() => setShowAssistant(false)} contextInfo={getContextString()} onExecuteAction={executeAiAction} />
        
        {/* HEADER */}
        <div id="header" className={`h-12 flex-shrink-0 px-6 flex justify-between items-center z-30 select-none bg-[#0f1715] ${isAnimating ? 'anim-header' : ''}`}>
            <h1 id="app-logo" className="font-serif text-xl italic tracking-wide text-[var(--accent)]">AlgoMix<span className="text-[var(--text-secondary)] font-sans text-xs opacity-70 ml-1 uppercase tracking-widest font-bold">PRO</span></h1>
            {/* MIDI ACTIVITY LED */}
            <div className={`w-2 h-2 rounded-full transition-all duration-75 ${midiActivity ? 'bg-green-500 shadow-[0_0_8px_#4ade80]' : 'bg-[var(--border)]'}`} title="MIDI Activity"></div>

            <div className="flex items-center gap-4">
                <button onClick={runAnalysis} className="text-[var(--text-secondary)] hover:text-[var(--accent)] text-[10px] uppercase tracking-widest transition-colors">ANALYZE</button>
                <button onClick={() => setShowSettings(true)} className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] text-[10px] uppercase tracking-widest transition-colors">CONFIG</button>
                <button onClick={handleQuit} className="w-6 h-6 flex items-center justify-center rounded-full border border-[var(--border)] text-[var(--text-secondary)] hover:border-red-400 hover:text-red-400 transition-all text-[10px]">✕</button>
            </div>
        </div>

        {/* MAIN STUDIO LAYOUT - DASHBOARD */}
        <div id="layout-main" className="flex-1 min-h-0 flex flex-row p-2 gap-2 overflow-hidden perspective-1000 w-full">
            
            {/* DECK A */}
            <div id="deck-a" className={`flex-1 min-w-0 flex flex-col ${isAnimating ? 'anim-deck-a' : ''}`}>
                <Deck 
                    id="A" 
                    track={trackA} isPlaying={isPlayingA} isLibraryConnected={libraryFiles.length > 0} pitchValue={pitchA} progress={progressA} 
                    activePadMode={padModeA} onPadModeChange={setPadModeA} onPlayPause={togglePlayA} waveformData={visualsEnabled ? waveformDataA : new Uint8Array(0)} 
                    onLoadTrack={async (f) => setTrackA(await loadTrack('A', f, undefined))} onPitchChange={(v) => { setPitchA(v); setPlaybackRate('A', v); }} onSync={() => handleSync('A')} onSeek={(p) => seek('A', p)} 
                    touchPlatter={(t, touched) => touchPlatter('A', t, touched)} movePlatter={(v) => movePlatter('A', v)} toggleScratchMode={() => toggleScratchMode('A')} 
                    pads={samples.slice(0, 8)} onTriggerPad={(i) => triggerSample(i)} onLoadSample={loadSample} 
                    onSetHotCue={(i) => setHotCue('A', i)} onTriggerHotCue={(i) => triggerHotCue('A', i)} onToggleLoop={(b, idx) => toggleLoop('A', b, idx)} onToggleFaderCut={(a, idx) => toggleFaderCut('A', idx, a)}
                    isMapping={isMappingMode} onMapClick={handleMidiLearn}
                    onRequestLibrary={() => setActiveLibraryDeck('A')}
                />
            </div>
            
            {/* CENTER MIXER + ALGORAVE */}
            <div id="mixer-container" className={`w-[320px] flex-shrink-0 flex flex-col gap-2 z-20 ${isAnimating ? 'anim-mixer' : ''}`}>
                <div className="flex-1 flex flex-col min-h-0">
                    <Mixer 
                        volA={faderA} volB={faderB} crossfader={crossfader} 
                        filterKnobA={filterKnobA} filterKnobB={filterKnobB} eqHighA={eqHighA} eqMidA={eqMidA} eqLowA={eqLowA} gainA={gainA} eqHighB={eqHighB} eqMidB={eqMidB} eqLowB={eqLowB} gainB={gainB} 
                        isPlayingA={isPlayingA} isPlayingB={isPlayingB}
                        setVolA={setFaderA} setVolB={setFaderB} setCrossfader={setCrossfaderVal} 
                        setFilterA={(t, v) => { setFilter('A', t, v); if(t==='sweep') setFilterKnobA(v); else if(t==='high') setEqHighA(v); else if(t==='mid') setEqMidA(v); else if(t==='low') setEqLowA(v); }} 
                        setFilterB={(t, v) => { setFilter('B', t, v); if(t==='sweep') setFilterKnobB(v); else if(t==='high') setEqHighB(v); else if(t==='mid') setEqMidB(v); else if(t==='low') setEqLowB(v); }} 
                        setGainA={(v) => { setGain('A', v); setGainStateA(v); }} setGainB={(v) => { setGain('B', v); setGainStateB(v); }}
                        isMapping={isMappingMode} onMapClick={handleMidiLearn}
                    />
                </div>
                
                {/* AI PANEL INTEGRATED BELOW MIXER */}
                <div className="h-[280px] rounded-xl overflow-hidden border border-[var(--border)] shadow-xl bg-[var(--bg-panel)]">
                     <AlgoravePanel ref={algoraveRef} onPlaySound={playAlgoraveSound} isPlaying={isPlayingA || isPlayingB} contextA={trackA?.name} contextB={trackB?.name} onRenderAudio={handleRenderAudio} onLoadToDeck={handleLoadGeneratedTrack} />
                </div>
            </div>

            {/* DECK B */}
            <div id="deck-b" className={`flex-1 min-w-0 flex flex-col ${isAnimating ? 'anim-deck-b' : ''}`}>
                <Deck 
                    id="B" 
                    track={trackB} isPlaying={isPlayingB} isLibraryConnected={libraryFiles.length > 0} pitchValue={pitchB} progress={progressB} 
                    activePadMode={padModeB} onPadModeChange={setPadModeB} onPlayPause={togglePlayB} waveformData={visualsEnabled ? waveformDataB : new Uint8Array(0)} 
                    onLoadTrack={async (f) => setTrackB(await loadTrack('B', f, undefined))} onPitchChange={(v) => { setPitchB(v); setPlaybackRate('B', v); }} onSync={() => handleSync('B')} onSeek={(p) => seek('B', p)} 
                    touchPlatter={(t, touched) => touchPlatter('B', t, touched)} movePlatter={(v) => movePlatter('B', v)} toggleScratchMode={() => toggleScratchMode('B')} 
                    pads={samples.slice(0, 8)} onTriggerPad={(i) => triggerSample(i)} onLoadSample={loadSample} 
                    onSetHotCue={(i) => setHotCue('B', i)} onTriggerHotCue={(i) => triggerHotCue('B', i)} onToggleLoop={(b, idx) => toggleLoop('B', b, idx)} onToggleFaderCut={(a, idx) => toggleFaderCut('B', idx, a)} 
                    isMapping={isMappingMode} onMapClick={handleMidiLearn}
                    onRequestLibrary={() => setActiveLibraryDeck('B')}
                />
            </div>
        </div>
    </div>
  );
}

export default App;
