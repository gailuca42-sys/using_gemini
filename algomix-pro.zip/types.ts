
export interface Track {
  id: string;
  name: string;
  url: string; // Blob URL or File URL
  buffer: AudioBuffer | null;
  duration: number;
  bpm: number; // Added BPM
  timeSignature: string; // e.g., "4/4", "3/4"
  waveform: number[]; // Pre-calculated waveform peaks for static display
  coverArt?: string; // CSS Gradient string for album art
}

export interface SamplerSlot {
  id: number;
  name: string;
  buffer: AudioBuffer | null;
  color: string;
  isTriggered: boolean; // Visual feedback
}

export type PadMode = 'cue' | 'loop' | 'cuts' | 'sample';

export interface DeckState {
  playing: boolean;
  playbackRate: number; // Pitch
  volume: number;
  filterHigh: number;
  filterMid: number;
  filterLow: number;
  currentTime: number;
  loop: boolean;
}

export interface AlgoravePattern {
  bpm: number;
  steps: number; // usually 16 or 32
  tracks: {
    instrument: 'kick' | 'snare' | 'hihat' | 'bass' | 'synth';
    pattern: number[]; // Array of 0s and 1s, or note numbers
    note?: string; // For bass/synth
  }[];
}

export interface AiMelody {
  name: string;
  bpm: number;
  durationSeconds?: number; // Added duration request
  notes: {
    note: string; // e.g., "C4", "A#3"
    startTime: number; // in seconds
    duration: number; // in seconds
    velocity: number; // 0-1
    type?: 'bass' | 'chord' | 'lead'; // Layer type
  }[];
}

// SUNO INTERFACE
export interface SunoTrack {
    id: string;
    title: string;
    style: string;
    duration: number;
    coverGradient: string;
    audioBuffer: AudioBuffer | null;
    status: 'generating' | 'ready' | 'error';
    createdAt: Date;
}

// UI ANALYSIS RESULT
export interface AnalysisResult {
    designSuggestions: string[];
    uxImprovements: string[];
    potentialBugs: string[];
    actionPrompt: string;
}

// AI Agent Action Type
export type AiActionType = 
  | 'PLAY_A' | 'PLAY_B' | 'STOP_A' | 'STOP_B' 
  | 'SYNC_A' | 'SYNC_B'
  | 'VOL_A' | 'VOL_B' // value: 0.0 - 1.0
  | 'CROSSFADER'      // value: 0.0 - 1.0
  | 'PITCH_A' | 'PITCH_B' // value: 0.92 - 1.08
  | 'GAIN_A' | 'GAIN_B'   // value: 0.0 - 1.0
  | 'FILTER_A' | 'FILTER_B' // value: 0.0 - 1.0 (Sweep)
  | 'EQ_HIGH_A' | 'EQ_MID_A' | 'EQ_LOW_A' // value: -40 to 10
  | 'EQ_HIGH_B' | 'EQ_MID_B' | 'EQ_LOW_B' // value: -40 to 10
  | 'LOAD_TRACK_A' | 'LOAD_TRACK_B' // text: precise filename from library
  | 'MAESTRO_TYPE' // text: prompt to type
  | 'WAIT' // requires duration ms
  // UI CONTROL ACTIONS
  | 'SET_THEME_MODE' // text: 'light' | 'dark'
  | 'SET_UI_STYLE' // text: JSON string containing color palette { main, panel, accent, text }
  | 'SET_DOM_CONTENT' // text: JSON string { selector: string, content: string }
  | 'TOGGLE_FULLSCREEN'; 

export interface AiAction {
  type: AiActionType;
  value?: number;
  text?: string;
}

export interface MidiDevice {
  id: string;
  name: string;
  manufacturer: string;
  state: string;
}

// DYNAMIC MIDI MAPPING
export type MappableAction = 
  // TRANSPORT & DECK
  | 'PLAY_A' | 'PLAY_B' 
  | 'CUE_A' | 'CUE_B' 
  | 'SYNC_A' | 'SYNC_B'
  | 'SCRATCH_MODE_A' | 'SCRATCH_MODE_B' // Vinyl Mode Toggle
  | 'LOAD_A' | 'LOAD_B' // Load Selected Track
  | 'PITCH_BEND_UP_A' | 'PITCH_BEND_DOWN_A'
  | 'PITCH_BEND_UP_B' | 'PITCH_BEND_DOWN_B'
  | 'SHIFT' // General Shift Modifier
  
  // MIXER
  | 'VOL_A' | 'VOL_B' | 'CROSSFADER'
  | 'GAIN_A' | 'GAIN_B'
  | 'EQ_HI_A' | 'EQ_MID_A' | 'EQ_LOW_A' | 'FILTER_A'
  | 'EQ_HI_B' | 'EQ_MID_B' | 'EQ_LOW_B' | 'FILTER_B'
  | 'PITCH_A' | 'PITCH_B'
  
  // JOG
  | 'PLATTER_TOUCH_A' | 'PLATTER_TOUCH_B' 
  | 'PLATTER_MOVE_A' | 'PLATTER_MOVE_B'
  
  // PADS
  | 'PAD_1_A' | 'PAD_2_A' | 'PAD_3_A' | 'PAD_4_A' | 'PAD_5_A' | 'PAD_6_A' | 'PAD_7_A' | 'PAD_8_A'
  | 'PAD_1_B' | 'PAD_2_B' | 'PAD_3_B' | 'PAD_4_B' | 'PAD_5_B' | 'PAD_6_B' | 'PAD_7_B' | 'PAD_8_B'
  | 'PAD_MODE_CUE_A' | 'PAD_MODE_LOOP_A' | 'PAD_MODE_CUTS_A' | 'PAD_MODE_SAMPLE_A'
  | 'PAD_MODE_CUE_B' | 'PAD_MODE_LOOP_B' | 'PAD_MODE_CUTS_B' | 'PAD_MODE_SAMPLE_B'
  
  // HARDWARE SPECIFIC ACTIONS (MIXTRACK PRO FX)
  | 'BROWSE_SCROLL' | 'BROWSE_PUSH'
  | 'FX_HPF' | 'FX_LPF' | 'FX_FLANGER' | 'FX_ECHO' | 'FX_REVERB' | 'FX_PHASER'
  | 'FX_PADDLE_A' | 'FX_PADDLE_B'
  | 'LOOP_HALF_A' | 'LOOP_DOUBLE_A' | 'LOOP_IN_OUT_A'
  | 'LOOP_HALF_B' | 'LOOP_DOUBLE_B' | 'LOOP_IN_OUT_B';

export interface MidiCommand {
    channel: number;
    note: number; // or CC number
    type: 'note' | 'cc';
}

export interface MidiCalibration {
    min: number;
    max: number;
}

// The Profile Object to Export/Import
export interface MidiProfile {
    deviceName: string;
    mappings: Record<string, MappableAction>; // Key is "channel-note-type", Value is Action
    calibrations?: Record<string, MidiCalibration>; // Key is "channel-note-type", Value is {min, max}
}
