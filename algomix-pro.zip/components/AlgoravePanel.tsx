
import React, { useState, useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import { generateAlgoravePattern, generateMelodyTrack, generateSunoMetadata } from '../services/geminiService';
import { AlgoravePattern, SunoTrack } from '../types';

interface AlgoravePanelProps {
  onPlaySound: (inst: string, note?: string) => void;
  isPlaying: boolean;
  contextA?: string;
  contextB?: string;
  onRenderAudio: (prompt: string, context: string, duration: number) => Promise<AudioBuffer | null>;
  onLoadToDeck: (deck: 'A' | 'B', buffer: AudioBuffer, name: string, cover?: string) => void;
}

export interface AlgoraveRef {
    triggerGenerate: (prompt: string) => void;
    simulateTyping: (text: string) => Promise<void>;
}

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

const AlgoravePanel = forwardRef<AlgoraveRef, AlgoravePanelProps>(({ onPlaySound, isPlaying, contextA, contextB, onRenderAudio, onLoadToDeck }, ref) => {
  const [activeTab, setActiveTab] = useState<'sequencer' | 'maestro' | 'suno'>('sequencer');
  const [maestroMode, setMaestroMode] = useState<'grid' | 'studio'>('grid');
  
  // Add missing state for Maestro Studio generated track
  const [generatedTrackName, setGeneratedTrackName] = useState<string>("");
  const [generatedBuffer, setGeneratedBuffer] = useState<AudioBuffer | null>(null);
  
  // SUNO STATE
  const [sunoMode, setSunoMode] = useState<'simulated' | 'api'>('simulated');
  const [sunoApiKey, setSunoApiKey] = useState('');
  const [sunoEndpoint, setSunoEndpoint] = useState('http://localhost:3000/api/generate');
  const [sunoSettingsOpen, setSunoSettingsOpen] = useState(false);
  
  const [sunoTracks, setSunoTracks] = useState<SunoTrack[]>([]);
  const [sunoPrompt, setSunoPrompt] = useState("");
  
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "Salut ! Je suis Maestro. Choisis 'Grid' pour le séquenceur ou 'Studio' pour créer une piste complète." }
  ]);
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedDuration, setSelectedDuration] = useState(15);
  
  const [pattern, setPattern] = useState<AlgoravePattern | null>(null);
  
  const [currentStep, setCurrentStep] = useState(0);
  const [active, setActive] = useState(false);
  const [infiniteMode, setInfiniteMode] = useState(false);

  const currentStepRef = useRef(0);
  const activeRef = useRef(false);
  const isGeneratingRef = useRef(false);
  const infiniteModeRef = useRef(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const promptRef = useRef('');

  useEffect(() => { activeRef.current = active; }, [active]);
  useEffect(() => { infiniteModeRef.current = infiniteMode; }, [infiniteMode]);
  useEffect(() => { chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, activeTab, prompt]);

  useImperativeHandle(ref, () => ({
      triggerGenerate: (text: string) => {
          setActiveTab('maestro');
          setMaestroMode('studio');
          handleGenerate(text);
      },
      simulateTyping: async (text: string) => {
          setActiveTab('maestro');
          setMaestroMode('studio');
          setPrompt('');
          promptRef.current = '';
          
          for (let i = 0; i < text.length; i++) {
              promptRef.current += text[i];
              setPrompt(promptRef.current);
              await new Promise(r => setTimeout(r, 30 + Math.random() * 50));
          }
          await new Promise(r => setTimeout(r, 300));
          handleGenerate(text);
      }
  }));

  const getContextString = () => {
      let ctx = "Playing now: ";
      if (contextA) ctx += `Deck A: ${contextA}. `;
      if (contextB) ctx += `Deck B: ${contextB}.`;
      return ctx === "Playing now: " ? "No tracks currently playing." : ctx;
  };

  const handleSunoGenerate = async () => {
      if (!sunoPrompt.trim()) return;
      setLoading(true);
      
      const newTrackId = crypto.randomUUID();
      const tempTrack: SunoTrack = {
          id: newTrackId,
          title: "Generating...",
          style: "Processing...",
          duration: 0,
          coverGradient: "linear-gradient(45deg, #333, #444)",
          audioBuffer: null,
          status: 'generating',
          createdAt: new Date()
      };
      
      setSunoTracks(prev => [tempTrack, ...prev]);
      setSunoPrompt("");

      if (sunoMode === 'api') {
          // REAL API CALL IMPLEMENTATION
          try {
              // This is a placeholder fetch. In a real scenario, this would hit the user's proxy.
              /*
              const res = await fetch(sunoEndpoint, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${sunoApiKey}` },
                  body: JSON.stringify({ prompt: sunoPrompt })
              });
              const data = await res.json();
              // Handle real response...
              */
              
              // For now, we simulate success after delay to show UI state, but warn user
              await new Promise(r => setTimeout(r, 2000));
              setSunoTracks(prev => prev.map(t => t.id === newTrackId ? { ...t, status: 'error', title: "API Error", style: "Check Endpoint" } : t));

          } catch (e) {
              setSunoTracks(prev => prev.map(t => t.id === newTrackId ? { ...t, status: 'error' } : t));
          }
      } else {
          // SIMULATION MODE (Gemini + OfflineAudio)
          const metadata = await generateSunoMetadata(sunoPrompt);
          const buffer = await onRenderAudio(sunoPrompt, getContextString(), 45); // 45s generation

          setSunoTracks(prev => prev.map(t => {
              if (t.id === newTrackId) {
                  return {
                      ...t,
                      title: metadata?.title || "Untitled Creation",
                      style: metadata?.style || "Experimental",
                      coverGradient: metadata?.colors ? `linear-gradient(135deg, ${metadata.colors[0]}, ${metadata.colors[1]})` : t.coverGradient,
                      audioBuffer: buffer,
                      status: buffer ? 'ready' : 'error',
                      duration: buffer ? buffer.duration : 0
                  };
              }
              return t;
          }));
      }
      setLoading(false);
  };

  const handleGenerate = async (text: string) => {
    if (!text.trim()) return;
    const userMsg = text;
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setPrompt('');
    setLoading(true);

    if (maestroMode === 'studio') {
        const melody = await generateMelodyTrack(userMsg, getContextString(), selectedDuration);
        if (melody) {
            setGeneratedTrackName(melody.name || "Maestro Track");
            const buffer = await onRenderAudio(userMsg, getContextString(), selectedDuration);
            setGeneratedBuffer(buffer);
            
            // Auto-load logic if requested
            const lowerMsg = userMsg.toLowerCase();
            if (lowerMsg.includes("deck a") || lowerMsg.includes("piste a") || lowerMsg.includes("gauche")) {
                 if (buffer) onLoadToDeck('A', buffer, melody.name || "Maestro Track");
            } else if (lowerMsg.includes("deck b") || lowerMsg.includes("piste b") || lowerMsg.includes("droite")) {
                 if (buffer) onLoadToDeck('B', buffer, melody.name || "Maestro Track");
            }

            setMessages(prev => [...prev, { role: 'model', text: `J'ai composé "${melody.name}" (${melody.bpm} BPM). Je l'ai chargé dans le lecteur audio ci-dessous.` }]);
        } else {
            setMessages(prev => [...prev, { role: 'model', text: "Désolé, je n'ai pas pu générer l'audio." }]);
        }
    } else {
        const result = await generateAlgoravePattern(userMsg, 128);
        if (result) {
            setPattern(result);
            setMessages(prev => [...prev, { role: 'model', text: `Pattern généré : ${result.bpm} BPM.` }]);
        }
    }
    setLoading(false);
  };

  // Sequencer Logic
  useEffect(() => {
    if (!active || !pattern) return;
    const interval = setInterval(() => {
      setCurrentStep(s => (s + 1) % pattern.steps);
      const step = currentStepRef.current;
      currentStepRef.current = (step + 1) % pattern.steps;
      
      pattern.tracks.forEach(track => {
         if (track.pattern[step] === 1) {
             onPlaySound(track.instrument, track.note);
         }
      });
    }, (60000 / pattern.bpm) / 4);
    return () => clearInterval(interval);
  }, [active, pattern, onPlaySound]);

  const toggleStep = (trackIdx: number, stepIdx: number) => {
      if (!pattern) return;
      const newTracks = [...pattern.tracks];
      newTracks[trackIdx].pattern[stepIdx] = newTracks[trackIdx].pattern[stepIdx] ? 0 : 1;
      setPattern({ ...pattern, tracks: newTracks });
  };

  return (
    <div className="h-full flex flex-col bg-[var(--bg-panel)] text-[var(--text-primary)] relative">
      {/* Tabs */}
      <div className="flex border-b border-[var(--border)]">
        <button onClick={() => setActiveTab('sequencer')} className={`flex-1 py-3 text-[10px] font-mono uppercase tracking-widest hover:bg-[var(--bg-surface)] transition-colors ${activeTab === 'sequencer' ? 'bg-[var(--bg-surface)] border-b-2 border-[var(--accent)] text-[var(--accent)]' : 'text-[var(--text-secondary)]'}`}>Sequencer Grid</button>
        <button onClick={() => setActiveTab('maestro')} className={`flex-1 py-3 text-[10px] font-mono uppercase tracking-widest hover:bg-[var(--bg-surface)] transition-colors ${activeTab === 'maestro' ? 'bg-[var(--bg-surface)] border-b-2 border-[var(--accent)] text-[var(--accent)]' : 'text-[var(--text-secondary)]'}`}>Maestro AI</button>
        <button onClick={() => setActiveTab('suno')} className={`flex-1 py-3 text-[10px] font-mono uppercase tracking-widest hover:bg-[var(--bg-surface)] transition-colors ${activeTab === 'suno' ? 'bg-[var(--bg-surface)] border-b-2 border-[var(--accent)] text-[var(--accent)]' : 'text-[var(--text-secondary)]'}`}>Suno Cloud</button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 min-h-0">
        
        {/* SEQUENCER TAB */}
        {activeTab === 'sequencer' && (
            <div className="h-full flex flex-col">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-serif italic text-lg">Algorave Grid</h3>
                    <div className="flex gap-2">
                        <button onClick={() => setInfiniteMode(!infiniteMode)} className={`px-2 py-1 text-[9px] border border-[var(--border)] rounded uppercase ${infiniteMode ? 'bg-[var(--accent)] text-[var(--bg-main)]' : ''}`}>∞ Infinite</button>
                        <button onClick={() => setActive(!active)} className={`px-3 py-1 text-[9px] border border-[var(--border)] rounded uppercase tracking-widest min-w-[60px] ${active ? 'bg-[var(--accent)] text-[var(--bg-main)]' : ''}`}>{active ? 'STOP' : 'PLAY'}</button>
                    </div>
                </div>
                
                {pattern ? (
                    <div className="flex-1 overflow-y-auto space-y-2">
                        {pattern.tracks.map((track, tIdx) => (
                            <div key={tIdx} className="flex items-center gap-2">
                                <span className="w-12 text-[9px] font-mono uppercase text-[var(--text-secondary)]">{track.instrument}</span>
                                <div className="flex-1 flex gap-[2px]">
                                    {track.pattern.map((step, sIdx) => (
                                        <div 
                                            key={sIdx} 
                                            onClick={() => toggleStep(tIdx, sIdx)}
                                            className={`
                                                flex-1 h-8 rounded-sm cursor-pointer transition-all duration-75
                                                ${step ? 'bg-[var(--text-primary)]' : 'bg-[var(--bg-surface)]'}
                                                ${currentStep === sIdx && active ? 'brightness-150 shadow-[0_0_5px_var(--accent)]' : ''}
                                                hover:bg-[var(--accent)]
                                            `}
                                        ></div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="flex-1 flex items-center justify-center text-[var(--text-secondary)] italic">
                        No pattern loaded. Ask Maestro or generate one.
                    </div>
                )}
            </div>
        )}

        {/* MAESTRO TAB */}
        {activeTab === 'maestro' && (
            <div className="h-full flex flex-col">
                <div className="flex gap-2 mb-4 justify-center">
                    <button onClick={() => setMaestroMode('grid')} className={`px-3 py-1 text-[9px] rounded-full border ${maestroMode === 'grid' ? 'bg-[var(--accent)] text-[var(--bg-main)] border-transparent' : 'border-[var(--border)]'}`}>Grid Mode</button>
                    <button onClick={() => setMaestroMode('studio')} className={`px-3 py-1 text-[9px] rounded-full border ${maestroMode === 'studio' ? 'bg-[var(--accent)] text-[var(--bg-main)] border-transparent' : 'border-[var(--border)]'}`}>Studio Mode</button>
                </div>

                <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
                    {messages.map((msg, idx) => (
                        <div key={idx} className={`p-3 rounded-lg text-xs max-w-[90%] ${msg.role === 'user' ? 'ml-auto bg-[var(--text-primary)] text-[var(--bg-main)]' : 'bg-[var(--bg-surface)] text-[var(--text-primary)] border border-[var(--border)]'}`}>
                            {msg.text}
                        </div>
                    ))}
                    {loading && <div className="text-[10px] font-mono animate-pulse text-[var(--text-secondary)]">Maestro is composing...</div>}
                    
                    {generatedBuffer && (
                        <div className="bg-[var(--bg-surface)] border border-[var(--border)] p-3 rounded flex items-center justify-between mt-2 animate-[fadeIn_0.5s]">
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 bg-[var(--accent)] rounded-full flex items-center justify-center text-[var(--bg-main)]">♫</div>
                                <div>
                                    <div className="text-xs font-bold">{generatedTrackName}</div>
                                    <div className="text-[9px] text-[var(--text-secondary)]">Generated Audio</div>
                                </div>
                            </div>
                            <div className="flex gap-1">
                                <button onClick={() => onLoadToDeck('A', generatedBuffer, generatedTrackName)} className="px-2 py-1 bg-[var(--bg-panel)] border border-[var(--border)] text-[8px] hover:border-[var(--accent)]">LOAD A</button>
                                <button onClick={() => onLoadToDeck('B', generatedBuffer, generatedTrackName)} className="px-2 py-1 bg-[var(--bg-panel)] border border-[var(--border)] text-[8px] hover:border-[var(--accent)]">LOAD B</button>
                            </div>
                        </div>
                    )}
                    <div ref={chatEndRef} />
                </div>
                
                {maestroMode === 'studio' && (
                     <div className="mb-2 flex justify-center gap-2">
                         {[15, 30, 45, 60].map(d => (
                             <button key={d} onClick={() => setSelectedDuration(d)} className={`text-[8px] px-2 py-0.5 rounded border ${selectedDuration === d ? 'border-[var(--accent)] text-[var(--accent)]' : 'border-transparent text-[var(--text-secondary)]'}`}>{d}s</button>
                         ))}
                     </div>
                )}

                <div className="flex gap-2">
                    <input 
                        type="text" 
                        value={prompt} 
                        onChange={(e) => setPrompt(e.target.value)} 
                        onKeyDown={(e) => e.key === 'Enter' && handleGenerate(prompt)}
                        placeholder={maestroMode === 'grid' ? "Ex: Techno drum pattern 130bpm" : "Ex: Deep House bassline with keys"}
                        className="flex-1 bg-[var(--bg-surface)] border border-[var(--border)] rounded px-3 py-2 text-xs outline-none focus:border-[var(--accent)]"
                    />
                    <button onClick={() => handleGenerate(prompt)} disabled={loading} className="px-4 bg-[var(--text-primary)] text-[var(--bg-main)] rounded text-xs font-bold hover:opacity-90">GO</button>
                </div>
            </div>
        )}

        {/* SUNO CLOUD TAB */}
        {activeTab === 'suno' && (
            <div className="h-full flex flex-col relative">
                {/* Settings Toggle */}
                <button 
                    onClick={() => setSunoSettingsOpen(!sunoSettingsOpen)}
                    className="absolute top-0 right-0 p-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)] z-10"
                >
                    ⚙
                </button>

                {/* Settings Panel */}
                {sunoSettingsOpen && (
                    <div className="bg-[var(--bg-surface)] p-4 mb-4 rounded border border-[var(--border)] animate-[fadeIn_0.2s]">
                        <h4 className="font-serif italic text-sm mb-3">Suno API Configuration</h4>
                        <div className="space-y-3">
                            <div className="flex gap-2 text-xs">
                                <button onClick={() => setSunoMode('simulated')} className={`flex-1 py-1 border rounded ${sunoMode === 'simulated' ? 'bg-[var(--accent)] text-[var(--bg-main)]' : 'border-[var(--border)]'}`}>Simulation (Gemini)</button>
                                <button onClick={() => setSunoMode('api')} className={`flex-1 py-1 border rounded ${sunoMode === 'api' ? 'bg-[var(--accent)] text-[var(--bg-main)]' : 'border-[var(--border)]'}`}>Custom API</button>
                            </div>
                            {sunoMode === 'api' && (
                                <>
                                    <input 
                                        type="text" placeholder="API Endpoint URL" value={sunoEndpoint} onChange={e => setSunoEndpoint(e.target.value)}
                                        className="w-full bg-[var(--bg-panel)] border border-[var(--border)] px-2 py-1 text-xs rounded"
                                    />
                                    <input 
                                        type="password" placeholder="API Key / Cookie" value={sunoApiKey} onChange={e => setSunoApiKey(e.target.value)}
                                        className="w-full bg-[var(--bg-panel)] border border-[var(--border)] px-2 py-1 text-xs rounded"
                                    />
                                </>
                            )}
                        </div>
                    </div>
                )}

                <div className="flex-1 overflow-y-auto space-y-4 pr-2">
                    {sunoTracks.map((track) => (
                        <div key={track.id} className="bg-[var(--bg-surface)] rounded-lg overflow-hidden border border-[var(--border)] flex flex-col shadow-sm transition-all hover:shadow-md">
                            <div className="h-20 w-full relative" style={{ background: track.coverGradient }}>
                                <div className="absolute bottom-2 left-2 text-white drop-shadow-md">
                                    <div className="font-bold text-sm">{track.title}</div>
                                    <div className="text-[9px] opacity-80">{track.style} • {track.duration ? Math.round(track.duration) + 's' : '...'}</div>
                                </div>
                                {track.status === 'generating' && (
                                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center backdrop-blur-sm">
                                        <div className="text-white text-xs font-mono animate-pulse">GENERATING...</div>
                                    </div>
                                )}
                            </div>
                            {track.status === 'ready' && track.audioBuffer && (
                                <div className="p-2 flex justify-between items-center bg-[var(--bg-panel)]">
                                    <div className="text-[9px] text-[var(--text-secondary)] font-mono">{track.id.slice(0,6)}</div>
                                    <div className="flex gap-1">
                                        <button onClick={() => onLoadToDeck('A', track.audioBuffer!, track.title, track.coverGradient)} className="px-2 py-1 border border-[var(--border)] rounded text-[8px] hover:bg-[var(--accent)] hover:text-[var(--bg-main)] transition-colors">DECK A</button>
                                        <button onClick={() => onLoadToDeck('B', track.audioBuffer!, track.title, track.coverGradient)} className="px-2 py-1 border border-[var(--border)] rounded text-[8px] hover:bg-[var(--accent)] hover:text-[var(--bg-main)] transition-colors">DECK B</button>
                                    </div>
                                </div>
                            )}
                            {track.status === 'error' && (
                                <div className="p-2 text-center text-xs text-red-400 bg-[var(--bg-panel)]">Generation Failed</div>
                            )}
                        </div>
                    ))}
                    {sunoTracks.length === 0 && (
                        <div className="text-center py-10 opacity-30 text-xs italic">
                            Generate your first track...
                        </div>
                    )}
                </div>

                <div className="mt-4 pt-3 border-t border-[var(--border)]">
                    <div className="flex gap-2">
                        <input 
                            type="text" 
                            value={sunoPrompt}
                            onChange={(e) => setSunoPrompt(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSunoGenerate()}
                            placeholder="Describe a song to generate..."
                            className="flex-1 bg-[var(--bg-surface)] border border-[var(--border)] rounded px-3 py-2 text-xs outline-none focus:border-[var(--accent)]"
                        />
                        <button 
                            onClick={handleSunoGenerate} 
                            disabled={loading}
                            className="px-4 bg-[var(--accent)] text-[var(--bg-main)] rounded text-xs font-bold hover:opacity-90 disabled:opacity-50"
                        >
                            CREATE
                        </button>
                    </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
});

export default AlgoravePanel;
