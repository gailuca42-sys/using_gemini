import React, { useRef } from 'react';
import { SamplerSlot } from '../types';

interface SamplerPadProps {
    slot: SamplerSlot;
    onTrigger: (id: number) => void;
    onLoad: (id: number, file: File) => void;
}

const SamplerPad: React.FC<SamplerPadProps> = ({ slot, onTrigger, onLoad }) => {
    const fileRef = useRef<HTMLInputElement>(null);

    const handleClick = (e: React.MouseEvent) => {
        if (e.shiftKey || !slot.buffer) {
            fileRef.current?.click();
        } else {
            onTrigger(slot.id);
        }
    };

    return (
        <button 
            className={`
                relative w-full h-full border rounded-sm transition-all duration-75 flex items-center justify-center overflow-hidden group
                ${slot.isTriggered 
                    ? 'bg-[var(--accent)] border-[var(--accent)]' 
                    : 'bg-[var(--bg-surface)] border-[var(--border)] hover:border-[var(--text-secondary)]'}
            `}
            onClick={handleClick}
            onContextMenu={(e) => { e.preventDefault(); fileRef.current?.click(); }}
        >
            <input 
                type="file" ref={fileRef} className="hidden" accept="audio/*" 
                onChange={(e) => e.target.files?.[0] && onLoad(slot.id, e.target.files[0])}
            />
            
            <div className={`text-[8px] font-mono uppercase tracking-widest transition-colors ${slot.isTriggered ? 'text-[var(--bg-main)] font-bold' : 'text-[var(--text-secondary)] group-hover:text-[var(--text-primary)]'}`}>
                {slot.buffer ? slot.name.substring(0,6) : 'EMPTY'}
            </div>
            
            {/* Status light */}
            {slot.buffer && (
                <div className={`absolute top-1 right-1 w-1 h-1 rounded-full ${slot.isTriggered ? 'bg-[var(--bg-main)]' : 'bg-[var(--text-secondary)]'}`}></div>
            )}
        </button>
    );
};

export default SamplerPad;