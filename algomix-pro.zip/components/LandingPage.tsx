
import React from 'react';
import ThreeScene from './ThreeScene';

interface LandingPageProps {
    onLaunch: () => void;
    onToggleFullscreen: () => void;
    onToggleTheme: () => void;
    isDark?: boolean;
}

const LandingPage: React.FC<LandingPageProps> = ({ onLaunch, onToggleFullscreen, onToggleTheme, isDark }) => {
    
    return (
        <div className="relative w-full bg-transparent text-[#e8e6d9] overflow-x-hidden selection:bg-[#cfab48] selection:text-black">
            {/* Custom Scrollbar Hide */}
            <style>{`
                ::-webkit-scrollbar { display: none; }
                body { -ms-overflow-style: none; scrollbar-width: none; }
            `}</style>
            
            <ThreeScene />
            
            {/* NAVIGATION BAR */}
            <nav className="fixed top-0 left-0 right-0 p-4 md:p-6 flex justify-between items-center z-50 mix-blend-difference text-white">
                <div id="landing-logo" className="font-serif text-xl italic font-bold tracking-wide">
                    AlgoMix<span className="font-sans text-xs opacity-70 ml-1">PRO</span>
                </div>
                <div className="flex gap-2 md:gap-4">
                    <button onClick={onToggleTheme} className="hover:text-[#cfab48] transition-colors p-2" title="Toggle Theme">
                         {isDark ? '☀' : '☾'}
                    </button>
                    <button onClick={onToggleFullscreen} className="hover:text-[#cfab48] transition-colors p-2" title="Full Screen">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"></path></svg>
                    </button>
                    <button id="btn-enter" onClick={onLaunch} className="border border-white/30 px-4 py-1 md:px-6 md:py-2 rounded-full text-[10px] md:text-xs hover:bg-white hover:text-black transition-all uppercase tracking-widest font-bold backdrop-blur-md">
                        Enter Studio
                    </button>
                </div>
            </nav>

            {/* 1. HERO (Wave) */}
            <section className="h-screen flex flex-col items-center justify-center relative z-10 px-4 pointer-events-none">
                <h1 id="landing-title" className="text-[12vw] md:text-[10vw] font-serif italic leading-none text-center bg-clip-text text-transparent bg-gradient-to-b from-white to-white/60 drop-shadow-2xl">
                    AlgoMix Pro
                </h1>
                <p id="landing-subtitle" className="mt-8 font-mono text-xs md:text-sm uppercase tracking-[0.4em] text-[#cfab48] text-center max-w-lg animate-pulse">
                    The Future of Algorithmic DJing
                </p>
            </section>

            {/* 2. TEXT ZONE A (City Drop) */}
            <section className="h-[80vh] flex flex-col items-center justify-center relative z-10">
                 <div className="max-w-2xl text-center space-y-6 pointer-events-auto group transition-all duration-500 ease-out hover:scale-105 p-8 rounded-3xl cursor-default hover:bg-white/5 hover:backdrop-blur-xl hover:shadow-[0_0_50px_rgba(207,171,72,0.2)] border border-transparent hover:border-[#cfab48]/30">
                     <h2 id="feature-1-title" className="text-5xl md:text-7xl font-serif italic text-white drop-shadow-lg group-hover:text-[#cfab48] transition-colors duration-300">
                         Neural Synthesis
                     </h2>
                     <p className="font-mono text-sm md:text-base text-gray-300 leading-relaxed max-w-lg mx-auto opacity-80 backdrop-blur-sm p-4 rounded-lg bg-black/20 border border-white/5 group-hover:bg-transparent group-hover:border-transparent transition-all">
                         Powered by Gemini 3.0 Pro. Compose tracks, generate patterns, and command your mix with natural language.
                     </p>
                 </div>
            </section>

            {/* 3. TEXT ZONE B (Deep City) */}
            <section className="h-[80vh] flex flex-col items-center justify-center relative z-10">
                <div className="max-w-2xl text-center space-y-6 pointer-events-auto group transition-all duration-500 ease-out hover:scale-105 p-8 rounded-3xl cursor-default hover:bg-white/5 hover:backdrop-blur-xl hover:shadow-[0_0_50px_rgba(207,171,72,0.2)] border border-transparent hover:border-[#cfab48]/30">
                     <h2 id="feature-2-title" className="text-5xl md:text-7xl font-serif italic text-[#cfab48] drop-shadow-lg group-hover:text-white transition-colors duration-300">
                         Tactile Precision
                     </h2>
                     <p className="font-mono text-sm md:text-base text-gray-300 leading-relaxed max-w-lg mx-auto opacity-80 backdrop-blur-sm p-4 rounded-lg bg-black/20 border border-white/5 group-hover:bg-transparent group-hover:border-transparent transition-all">
                         Seamless integration with Numark Mixtrack Pro FX. Low latency WebAudio engine. Professional grade filters.
                     </p>
                 </div>
            </section>

            {/* 4. CLUB (Visuals only) */}
            <section className="h-screen flex flex-col items-center justify-center relative z-10 pointer-events-none">
                {/* Just let the crowd and screen shine */}
            </section>

            {/* 5. CTA */}
            <section className="h-[60vh] flex flex-col items-center justify-end pb-24 relative z-10">
                <div className="w-full max-w-xl text-center space-y-8 bg-[#0a0f0e]/90 p-12 backdrop-blur-2xl rounded-3xl border border-white/10 shadow-[0_0_100px_rgba(0,0,0,0.8)] pointer-events-auto hover:border-[#cfab48]/30 transition-colors group">
                    <h2 id="cta-title" className="text-3xl md:text-4xl font-serif italic text-[#cfab48]">Ready to Perform?</h2>
                    <p className="text-sm opacity-70 font-mono leading-7 text-gray-300">
                        Join the algorithmic revolution.<br/>
                        Your stage awaits.
                    </p>
                    <button 
                        onClick={onLaunch}
                        className="px-12 py-4 bg-[#cfab48] text-black font-bold text-sm tracking-widest rounded-full hover:bg-white hover:scale-105 transition-all duration-300 shadow-[0_0_30px_rgba(207,171,72,0.4)]"
                    >
                        LAUNCH APP
                    </button>
                </div>
            </section>
        </div>
    );
};

export default LandingPage;
