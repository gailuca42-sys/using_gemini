
import React, { useState, useEffect, useRef } from 'react';
import { generateAssistantResponse } from '../services/geminiService';
import { AiAction } from '../types';

interface AiAssistantProps {
    isOpen: boolean;
    onClose: () => void;
    contextInfo: string;
    onExecuteAction: (action: AiAction) => void;
}

const AiAssistant: React.FC<AiAssistantProps> = ({ isOpen, onClose, contextInfo, onExecuteAction }) => {
    const [messages, setMessages] = useState<{role: string, text: string}[]>([
        {role: 'bot', text: "Je suis prêt. Ordonne, et j'exécute instantanément."}
    ]);
    const [listening, setListening] = useState(false);
    const [thinking, setThinking] = useState(false);
    const [speaking, setSpeaking] = useState(false);
    const [voiceEnabled, setVoiceEnabled] = useState(true);
    
    const recognitionRef = useRef<any>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, thinking]);

    useEffect(() => {
        if ('webkitSpeechRecognition' in window) {
            const SpeechRecognition = (window as any).webkitSpeechRecognition;
            recognitionRef.current = new SpeechRecognition();
            recognitionRef.current.continuous = false;
            recognitionRef.current.lang = 'fr-FR';
            
            recognitionRef.current.onresult = (event: any) => {
                const transcript = event.results[0][0].transcript;
                setListening(false);
                handleUserMessage(transcript);
            };
            recognitionRef.current.onerror = () => setListening(false);
            recognitionRef.current.onend = () => setListening(false);
        }
    }, [contextInfo]);

    const speak = (text: string) => {
        if (!voiceEnabled) return;
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'fr-FR';
        
        const voices = window.speechSynthesis.getVoices();
        const bestVoice = voices.find(v => v.lang.includes('fr') && v.name.includes('Google')) || voices.find(v => v.lang.includes('fr'));
        if (bestVoice) utterance.voice = bestVoice;

        utterance.rate = 1.2; 
        utterance.pitch = 1.0;
        
        utterance.onstart = () => setSpeaking(true);
        utterance.onend = () => setSpeaking(false);
        
        window.speechSynthesis.speak(utterance);
    };

    const stopSpeaking = () => {
        window.speechSynthesis.cancel();
        setSpeaking(false);
    };

    const processActions = async (actions: AiAction[]) => {
        if (!actions || actions.length === 0) return;
        
        for (const action of actions) {
            console.log("Processing AI Action:", action);
            onExecuteAction(action);
            await new Promise(r => setTimeout(r, 50));
        }
    };

    const cleanJson = (input: string): string => {
        // Regex pour trouver le JSON valide le plus large, même encadré de texte
        const jsonMatch = input.match(/```json\s*([\s\S]*?)\s*```/) || input.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
            return jsonMatch[1] || jsonMatch[0];
        }
        return input;
    };

    const handleUserMessage = async (text: string) => {
        if (!text.trim()) return;
        setMessages(prev => [...prev, { role: 'user', text }]);
        setThinking(true);

        const rawResponse = await generateAssistantResponse(text, contextInfo);
        
        let parsed = { response: "Erreur technique.", actions: [] as AiAction[] };
        try {
            const jsonString = cleanJson(rawResponse);
            parsed = JSON.parse(jsonString);
        } catch(e) {
            console.error("JSON Parse Error", e, rawResponse);
            // Si le parsing échoue, on affiche la réponse brute si elle est lisible, sinon erreur
            if (!rawResponse.includes("{")) {
                 parsed = { response: rawResponse, actions: [] };
            } else {
                 parsed = { response: "J'ai compris, mais je n'ai pas réussi à formater la réponse technique.", actions: [] };
            }
        }

        setThinking(false);
        setMessages(prev => [...prev, { role: 'bot', text: parsed.response }]);
        
        processActions(parsed.actions);
        speak(parsed.response);
    };

    const toggleMic = () => {
        if (speaking) stopSpeaking();
        if (listening) {
            recognitionRef.current?.stop();
            setListening(false);
        } else {
            recognitionRef.current?.start();
            setListening(true);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="absolute bottom-20 right-4 w-80 h-96 bg-[var(--bg-panel)] border border-[var(--border)] rounded-xl shadow-2xl flex flex-col z-50 overflow-hidden animate-[fadeIn_0.3s]">
            {/* Header */}
            <div className="p-4 border-b border-[var(--border)] flex justify-between items-center bg-[var(--bg-surface)]">
                <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-[var(--accent)] animate-pulse shadow-[0_0_10px_var(--accent)]"></div>
                    <span className="font-serif italic text-sm font-bold text-[var(--text-primary)]">Copilot Agent v2.0</span>
                </div>
                <div className="flex gap-2">
                     <button onClick={() => setVoiceEnabled(!voiceEnabled)} className="text-xs hover:text-[var(--text-primary)] transition-colors" title={voiceEnabled ? "Mute Voice" : "Enable Voice"}>
                         {voiceEnabled ? "🔊" : "🔇"}
                     </button>
                    <button onClick={onClose} className="text-xs opacity-50 hover:opacity-100 hover:text-red-400 transition-colors">✕</button>
                </div>
            </div>
            
            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth">
                {messages.map((m, i) => (
                    <div key={i} className={`text-xs p-3 rounded-xl max-w-[90%] leading-relaxed shadow-sm ${
                        m.role === 'user' 
                        ? 'ml-auto bg-[var(--text-primary)] text-[var(--bg-main)] rounded-tr-none font-medium' 
                        : 'bg-[var(--bg-surface)] text-[var(--text-primary)] rounded-tl-none border border-[var(--border)]'
                    }`}>
                        {m.text}
                    </div>
                ))}
                {thinking && (
                     <div className="bg-[var(--bg-surface)] text-[var(--text-secondary)] text-xs p-3 rounded-xl rounded-tl-none border border-[var(--border)] w-fit flex gap-1 items-center animate-pulse">
                        <span className="font-mono text-[9px] uppercase tracking-widest">Processing...</span>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-3 border-t border-[var(--border)] flex gap-2 items-center bg-[var(--bg-surface)]">
                <button 
                    onClick={toggleMic}
                    className={`p-3 rounded-full transition-all duration-200 active:scale-95 ${
                        listening 
                        ? 'bg-red-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.5)]' 
                        : 'bg-[var(--bg-panel)] border border-[var(--border)] text-[var(--text-primary)] hover:border-[var(--accent)]'
                    }`}
                >
                    {speaking ? (
                        <span onClick={(e) => { e.stopPropagation(); stopSpeaking(); }}>⬛</span>
                    ) : (
                        listening ? '⬤' : '🎤'
                    )}
                </button>
                <input 
                    type="text" 
                    placeholder="Commande rapide..."
                    className="flex-1 bg-[var(--bg-panel)] border border-[var(--border)] rounded-full px-4 py-2 text-xs outline-none focus:border-[var(--accent)] transition-colors font-mono"
                    onKeyDown={(e) => {
                        if(e.key === 'Enter') {
                            handleUserMessage((e.target as HTMLInputElement).value);
                            (e.target as HTMLInputElement).value = '';
                        }
                    }}
                />
            </div>
        </div>
    );
};

export default AiAssistant;
