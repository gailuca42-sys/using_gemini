
import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const ThreeScene: React.FC = React.memo(() => {
    const mountRef = useRef<HTMLDivElement>(null);
    const mouseRef = useRef({ x: 0, y: 0 });
    
    useEffect(() => {
        if (!mountRef.current) return;

        // Mouse Listener
        const handleMouseMove = (e: MouseEvent) => {
            mouseRef.current.x = (e.clientX / window.innerWidth) * 2 - 1;
            mouseRef.current.y = -(e.clientY / window.innerHeight) * 2 + 1;
        };
        window.addEventListener('mousemove', handleMouseMove);

        // --- 1. SETUP ENGINE ---
        const scene = new THREE.Scene();
        scene.fog = new THREE.FogExp2(0x050505, 0.025);

        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 1, 5);

        const renderer = new THREE.WebGLRenderer({ 
            alpha: true, 
            antialias: true,
            powerPreference: "high-performance" 
        });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(window.devicePixelRatio);
        mountRef.current.appendChild(renderer.domElement);

        // --- SHARED MATERIALS ---
        const wireframeMat = new THREE.LineBasicMaterial({ color: 0x333333, transparent: true, opacity: 0.2 });
        
        // --- 2. SCENE 0: QUANTUM WAVE (Top Y=0) ---
        const waveGroup = new THREE.Group();
        const waveGeometry = new THREE.BufferGeometry();
        // High count for best visual quality
        const count = 4000; 
        const positions = new Float32Array(count * 3);
        
        for(let i=0; i<count; i++) {
            positions[i*3] = (Math.random() - 0.5) * 60;
            positions[i*3+1] = (Math.random() - 0.5) * 10 + 5; 
            positions[i*3+2] = (Math.random() - 0.5) * 30;
        }
        waveGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        
        const particles = new THREE.Points(waveGeometry, new THREE.PointsMaterial({
            color: 0xcfab48, size: 0.06, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending
        }));
        waveGroup.add(particles);
        scene.add(waveGroup);

        // --- DATA CITY BACKGROUND ---
        const cityGroup = new THREE.Group();
        const buildingGeo = new THREE.BoxGeometry(1, 1, 1);
        const buildingEdges = new THREE.EdgesGeometry(buildingGeo);
        
        const cityCount = 400;
        const cityInst = new THREE.InstancedMesh(buildingGeo, new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.95 }), cityCount);
        const cityLines = new THREE.InstancedMesh(buildingEdges as any, wireframeMat as any, cityCount);
        
        const dummy = new THREE.Object3D();
        for(let i=0; i<cityCount; i++) {
            const h = Math.random() * 40 + 10;
            const ang = Math.random() * Math.PI * 2;
            const rad = 15 + Math.random() * 30; 
            const y = -10 - Math.random() * 100;
            
            dummy.position.set(Math.cos(ang)*rad, y, Math.sin(ang)*rad);
            dummy.scale.set(2 + Math.random()*3, h, 2 + Math.random()*3);
            dummy.updateMatrix();
            cityInst.setMatrixAt(i, dummy.matrix);
            cityLines.setMatrixAt(i, dummy.matrix);
        }
        cityGroup.add(cityInst);
        cityGroup.add(cityLines);
        scene.add(cityGroup);

        // --- ATMOSPHERE ---
        let dustParticles: THREE.Points | undefined;
        const dustGeo = new THREE.BufferGeometry();
        const dustCount = 1000;
        const dustPos = new Float32Array(dustCount * 3);
        for(let i=0; i<dustCount; i++) {
            dustPos[i*3] = (Math.random() - 0.5) * 80;
            dustPos[i*3+1] = (Math.random() - 0.5) * 150 - 50;
            dustPos[i*3+2] = (Math.random() - 0.5) * 80;
        }
        dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
        dustParticles = new THREE.Points(dustGeo, new THREE.PointsMaterial({
            color: 0xffffff, size: 0.08, transparent: true, opacity: 0.15
        }));
        scene.add(dustParticles);

        // --- 5. SCENE 3: THE CLUB (Y=-120) ---
        const clubGroup = new THREE.Group();
        clubGroup.position.set(0, -120, 0);

        // Crowd
        const crowdCount = 2500;
        const dummyCrowd = new THREE.Object3D();
        const crowd = new THREE.InstancedMesh(new THREE.BoxGeometry(0.2, 0.8, 0.2), new THREE.MeshStandardMaterial({ roughness: 0.4, metalness: 0.6 }), crowdCount);
        const crowdData: any[] = [];
        const colors = [new THREE.Color(0xcfab48), new THREE.Color(0x222222), new THREE.Color(0xffffff)];

        for(let i=0; i<crowdCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const r = 8 + Math.pow(Math.random(), 1.5) * 50; 
            const x = Math.cos(angle) * r;
            const z = Math.sin(angle) * r;
            
            if (z > -10 || Math.abs(x) > 5) {
                dummyCrowd.position.set(x, -5, z);
                dummyCrowd.rotation.y = Math.atan2(-x, -z);
                dummyCrowd.scale.set(1, 0.8 + Math.random(), 1);
                dummyCrowd.updateMatrix();
                crowd.setMatrixAt(i, dummyCrowd.matrix);
                crowd.setColorAt(i, colors[Math.floor(Math.random() * colors.length)]);
                crowdData.push({ x, baseY: -5, z, speed: 2 + Math.random()*4, offset: Math.random()*100 });
            }
        }
        crowd.instanceColor!.needsUpdate = true;
        clubGroup.add(crowd);

        // Screen & UI
        const uiCanvas = document.createElement('canvas');
        uiCanvas.width = 1024; uiCanvas.height = 512;
        const ctx = uiCanvas.getContext('2d');
        if(ctx) {
            ctx.fillStyle = '#050505'; ctx.fillRect(0,0,1024,512);
            ctx.lineWidth = 6;
            ctx.strokeStyle = '#cfab48';
            ctx.beginPath(); ctx.arc(256, 256, 140, 0, Math.PI*2); ctx.stroke();
            ctx.beginPath(); ctx.arc(768, 256, 140, 0, Math.PI*2); ctx.stroke();
            ctx.strokeRect(450, 50, 124, 412);
            ctx.fillStyle = '#333';
            ctx.fillRect(470, 200, 20, 150); ctx.fillRect(530, 200, 20, 150);
            ctx.fillStyle = '#cfab48'; ctx.font = "bold 70px serif"; ctx.textAlign = "center";
            ctx.fillText("AlgoMix Pro", 512, 120);
            ctx.font = "30px monospace";
            ctx.fillText("AI AGENT: READY", 512, 450);
        }
        const screenMesh = new THREE.Mesh(new THREE.PlaneGeometry(50, 25), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(uiCanvas), side: THREE.DoubleSide }));
        screenMesh.position.set(0, 10, -30);
        clubGroup.add(screenMesh);

        // Spotlights - Full Quality
        const spotGroup = new THREE.Group();
        const numSpots = 12; const spacing = 6;
        for(let i=0; i<numSpots; i++) {
                const x = (i - (numSpots-1)/2) * spacing;
                const cone = new THREE.Mesh(new THREE.ConeGeometry(0.5, 40, 32, 1, true), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.04, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false }));
                cone.geometry.translate(0, -20, 0);
                cone.position.set(x, 25, -30);
                cone.lookAt(0, -10, 0); 
                spotGroup.add(cone);
        }
        clubGroup.add(spotGroup);
        scene.add(clubGroup);


        // --- ANIMATION LOOP ---
        let time = 0;
        const animate = () => {
            time += 0.01;
            
            particles.rotation.y = time * 0.08; 
            particles.rotation.z = mouseRef.current.x * 0.05;

            for(let i=0; i<crowdData.length; i++) {
                const d = crowdData[i];
                if (d) {
                    dummyCrowd.position.set(d.x, d.baseY + Math.abs(Math.sin(time * d.speed + d.offset) * 0.3), d.z);
                    dummyCrowd.updateMatrix();
                    crowd.setMatrixAt(i, dummyCrowd.matrix);
                }
            }
            crowd.instanceMatrix.needsUpdate = true;
            dustParticles && (dustParticles.rotation.y = -time * 0.02);

            renderer.render(scene, camera);
            requestAnimationFrame(animate);
        };
        animate();

        // --- GSAP DRONE PATH ---
        const tl = gsap.timeline({
            scrollTrigger: {
                trigger: document.body,
                start: "top top",
                end: "bottom bottom",
                scrub: 0 
            }
        });

        tl.to(camera.position, { y: -40, z: 10, duration: 2, ease: "none" })
          .to(camera.rotation, { x: -0.2, duration: 2 }, "<");
        tl.to(camera.position, { y: -80, z: 10, duration: 2, ease: "none" })
          .to(camera.rotation, { x: 0, z: 0.05, duration: 2 }, "<");
        tl.to(camera.position, { y: -115, z: 10, x: 0, duration: 2, ease: "power2.out" })
          .to(camera.rotation, { z: 0, x: 0.1, y: 0, duration: 2 }, "<");
        tl.to(camera.position, { z: -5, duration: 1, ease: "power1.out" });


        const handleResize = () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        };
        window.addEventListener('resize', handleResize);

        return () => {
            ScrollTrigger.getAll().forEach(t => t.kill());
            window.removeEventListener('resize', handleResize);
            window.removeEventListener('mousemove', handleMouseMove);
            if(mountRef.current && renderer.domElement) mountRef.current.removeChild(renderer.domElement);
            renderer.dispose();
        };
    }, []);

    return <div ref={mountRef} className="fixed inset-0 z-0 pointer-events-none" />;
});

export default ThreeScene;
