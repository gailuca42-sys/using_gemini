
import React from 'react';
import { MappableAction } from '../types';

interface MixerProps {
  volA: number; volB: number; crossfader: number;
  filterKnobA: number; filterKnobB: number;
  eqHighA: number; eqMidA: number; eqLowA: number; gainA: number;
  eqHighB: number; eqMidB: number; eqLowB: number; gainB: number;
  isPlayingA: boolean; isPlayingB: boolean;
  
  setVolA: (v: number) => void; setVolB: (v: number) => void; setCrossfader: (v: number) => void;
  setFilterA: (type: 'low'|'mid'|'high'|'sweep', v: number) => void;
  setFilterB: (type: 'low'|'mid'|'high'|'sweep', v: number) => void;
  setGainA: (v: number) => void; setGainB: (v: number) => void;
  
  isMapping?: boolean;
  onMapClick?: (action: MappableAction) => void;
}

const snap = (val: number, center: number, rangeSpan: number) => {
    const threshold = rangeSpan * 0.04; // 4% snap zone
    if (Math.abs(val - center) < threshold) return center;
    return val;
};

const Knob = ({ label, value, min, max, onChange, center = false, size = 'medium', snapPoint, mappingId, isMapping, onMapClick }: { label: string, value: number, min: number, max: number, onChange: (v: number) => void, center?: boolean, size?: 'small' | 'medium' | 'large', snapPoint?: number, mappingId?: MappableAction, isMapping?: boolean, onMapClick?: (a: MappableAction) => void }) => {
    let rotation = -135;
    
    if (center && min < 0 && max > 0) {
        if (value <= 0) {
            rotation = -135 + ((value - min) / (0 - min)) * 135;
        } else {
            rotation = 0 + ((value - 0) / (max - 0)) * 135;
        }
    } else {
        const percent = (value - min) / (max - min);
        rotation = -135 + (percent * 270);
    }
    
    const handleReset = () => {
        onChange(snapPoint !== undefined ? snapPoint : (center ? 0 : min));
    };

    const handleChange = (v: number) => {
        if (snapPoint !== undefined) {
            onChange(snap(v, snapPoint, max - min));
        } else {
            onChange(v);
        }
    };

    const handleClick = (e: React.MouseEvent) => {
        if (isMapping && mappingId && onMapClick) {
            e.stopPropagation();
            onMapClick(mappingId);
        }
    }

    const sizeClass = size === 'small' ? 'w-8 h-8' : size === 'large' ? 'w-14 h-14' : 'w-10 h-10';
    
    return (
        <div className="flex flex-col items-center gap-1 group relative">
            <div 
                className={`
                    relative ${sizeClass} flex items-center justify-center cursor-pointer transition-transform hover:scale-105 active:scale-95
                    ${isMapping ? 'ring-2 ring-[var(--accent)] ring-offset-2 ring-offset-[var(--bg-panel)] animate-pulse z-50' : ''}
                `}
                onDoubleClick={handleReset}
                onClick={handleClick}
            >
                {/* Background Ring */}
                <svg className="absolute w-full h-full transform -rotate-90 pointer-events-none opacity-30 text-[var(--text-secondary)]" viewBox="0 0 36 36">
                     <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="75, 100"/>
                </svg>
                
                {/* Knob Body */}
                <div 
                    className="w-[80%] h-[80%] rounded-full border border-[var(--border)] relative shadow-xl bg-metal-gradient transition-transform will-change-transform"
                    style={{ transform: `rotate(${rotation}deg)` }}
                >
                    <div className="absolute top-1 left-1/2 w-[2px] h-[30%] bg-[var(--text-primary)] -translate-x-1/2 rounded-full z-10 shadow-[0_0_2px_rgba(0,0,0,0.5)]"></div>
                </div>

                {/* Input Overlay */}
                {!isMapping && (
                    <input 
                        type="range" min={min} max={max} step={(max-min)/100} value={value}
                        onChange={(e) => handleChange(parseFloat(e.target.value))}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-ns-resize z-20"
                        onDoubleClick={handleReset}
                    />
                )}
            </div>
            <span className={`font-mono text-[var(--text-secondary)] tracking-widest group-hover:text-[var(--text-primary)] transition-colors uppercase text-center ${size === 'small' ? 'text-[8px]' : 'text-[9px] font-bold'}`}>{label}</span>
        </div>
    );
};

const Mixer: React.FC<MixerProps> = ({ 
    volA, volB, crossfader, 
    filterKnobA, filterKnobB,
    eqHighA, eqMidA, eqLowA, gainA,
    eqHighB, eqMidB, eqLowB, gainB,
    isPlayingA, isPlayingB,
    setVolA, setVolB, setCrossfader,
    setFilterA, setFilterB, setGainA, setGainB,
    isMapping, onMapClick
}) => {
  
  const handleFaderClick = (action: MappableAction, e: React.MouseEvent) => {
      if(isMapping && onMapClick) {
          e.stopPropagation();
          e.preventDefault();
          onMapClick(action);
      }
  }

  return (
    <div className="h-full flex flex-col bg-[var(--bg-panel)] shadow-inner w-full border-x border-[var(--border)] select-none">
        
        {/* EQ / GAIN / FILTER Section */}
        <div className="flex-1 min-h-0 py-6 px-2 flex justify-center gap-12 bg-gradient-to-b from-[var(--bg-surface)] to-[var(--bg-panel)]">
            
            {/* Channel A Strip */}
            <div className="flex flex-col items-center justify-between h-full w-20 relative">
                <div className="absolute inset-y-0 -left-6 w-px bg-gradient-to-b from-transparent via-[var(--border)] to-transparent opacity-20"></div>
                
                <Knob label="GAIN" value={gainA} min={0} max={1} onChange={setGainA} snapPoint={0.5} mappingId="GAIN_A" isMapping={isMapping} onMapClick={onMapClick} />
                
                <div className="flex flex-col gap-3 my-2 p-3 rounded-2xl bg-[var(--bg-main)]/30 border border-[var(--border)]/20 shadow-inner">
                    <Knob label="HI" value={eqHighA} min={-40} max={10} onChange={(v) => setFilterA('high', v)} center size="small" snapPoint={0} mappingId="EQ_HI_A" isMapping={isMapping} onMapClick={onMapClick} />
                    <Knob label="MID" value={eqMidA} min={-40} max={10} onChange={(v) => setFilterA('mid', v)} center size="small" snapPoint={0} mappingId="EQ_MID_A" isMapping={isMapping} onMapClick={onMapClick} />
                    <Knob label="LOW" value={eqLowA} min={-40} max={10} onChange={(v) => setFilterA('low', v)} center size="small" snapPoint={0} mappingId="EQ_LOW_A" isMapping={isMapping} onMapClick={onMapClick} />
                </div>

                <Knob label="FILTER" value={filterKnobA} min={0} max={1} onChange={(v) => setFilterA('sweep', v)} center size="large" snapPoint={0.5} mappingId="FILTER_A" isMapping={isMapping} onMapClick={onMapClick} />
            </div>

            {/* Channel B Strip */}
            <div className="flex flex-col items-center justify-between h-full w-20 relative">
                 <div className="absolute inset-y-0 -right-6 w-px bg-gradient-to-b from-transparent via-[var(--border)] to-transparent opacity-20"></div>

                <Knob label="GAIN" value={gainB} min={0} max={1} onChange={setGainB} snapPoint={0.5} mappingId="GAIN_B" isMapping={isMapping} onMapClick={onMapClick} />
                
                <div className="flex flex-col gap-3 my-2 p-3 rounded-2xl bg-[var(--bg-main)]/30 border border-[var(--border)]/20 shadow-inner">
                    <Knob label="HI" value={eqHighB} min={-40} max={10} onChange={(v) => setFilterB('high', v)} center size="small" snapPoint={0} mappingId="EQ_HI_B" isMapping={isMapping} onMapClick={onMapClick} />
                    <Knob label="MID" value={eqMidB} min={-40} max={10} onChange={(v) => setFilterB('mid', v)} center size="small" snapPoint={0} mappingId="EQ_MID_B" isMapping={isMapping} onMapClick={onMapClick} />
                    <Knob label="LOW" value={eqLowB} min={-40} max={10} onChange={(v) => setFilterB('low', v)} center size="small" snapPoint={0} mappingId="EQ_LOW_B" isMapping={isMapping} onMapClick={onMapClick} />
                </div>

                <Knob label="FILTER" value={filterKnobB} min={0} max={1} onChange={(v) => setFilterB('sweep', v)} center size="large" snapPoint={0.5} mappingId="FILTER_B" isMapping={isMapping} onMapClick={onMapClick} />
            </div>

        </div>

        {/* Fader Section */}
        <div className="h-[220px] border-t border-[var(--border)] flex justify-between px-8 py-6 shrink-0 relative bg-[var(--bg-panel)] z-10 shadow-[0_-5px_15px_rgba(0,0,0,0.2)]">
             
             {/* FADER A */}
             <div className="h-full w-12 flex justify-center group relative">
                 <div className="absolute h-[160px] w-1 bg-[var(--knob-track)] rounded-full top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"></div>
                 
                 <div className="h-full flex items-center justify-center">
                    <div 
                        onClick={(e) => handleFaderClick('VOL_A', e)}
                        className={`relative w-[160px] h-[40px] flex items-center justify-center ${isMapping ? 'ring-2 ring-[var(--accent)] ring-offset-2 ring-offset-[var(--bg-panel)] z-50 animate-pulse cursor-pointer' : ''}`} 
                        style={{ transform: 'rotate(-90deg)' }}
                    >
                        <input 
                            type="range" min="0" max="1" step="0.005"
                            value={volA}
                            onChange={(e) => setVolA(parseFloat(e.target.value))}
                            className={`fader-clean-vertical z-20 w-[160px] ${isMapping ? 'pointer-events-none' : ''}`}
                        />
                    </div>
                 </div>
             </div>

             {/* VU Meters - Centralized */}
             <div className="flex gap-3 h-[160px] items-end pb-2 opacity-80 self-center bg-[var(--bg-main)]/50 px-2 py-1 rounded border border-[var(--border)]/30">
                 <div className="w-2 bg-gradient-to-t from-green-500 via-yellow-400 to-red-500 rounded-t-sm transition-all duration-75 shadow-[0_0_8px_rgba(0,255,0,0.2)]" style={{ height: `${isPlayingA ? volA * 90 + Math.random()*10 : 0}%`, opacity: isPlayingA ? 1 : 0.3 }}></div>
                 <div className="w-2 bg-gradient-to-t from-green-500 via-yellow-400 to-red-500 rounded-t-sm transition-all duration-75 shadow-[0_0_8px_rgba(0,255,0,0.2)]" style={{ height: `${isPlayingB ? volB * 90 + Math.random()*10 : 0}%`, opacity: isPlayingB ? 1 : 0.3 }}></div>
             </div>

             {/* FADER B */}
             <div className="h-full w-12 flex justify-center group relative">
                 <div className="absolute h-[160px] w-1 bg-[var(--knob-track)] rounded-full top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"></div>

                 <div className="h-full flex items-center justify-center">
                     <div 
                        onClick={(e) => handleFaderClick('VOL_B', e)}
                        className={`relative w-[160px] h-[40px] flex items-center justify-center ${isMapping ? 'ring-2 ring-[var(--accent)] ring-offset-2 ring-offset-[var(--bg-panel)] z-50 animate-pulse cursor-pointer' : ''}`} 
                        style={{ transform: 'rotate(-90deg)' }}
                     >
                         <input 
                            type="range" min="0" max="1" step="0.005"
                            value={volB}
                            onChange={(e) => setVolB(parseFloat(e.target.value))}
                            className={`fader-clean-vertical z-20 w-[160px] ${isMapping ? 'pointer-events-none' : ''}`}
                        />
                     </div>
                 </div>
             </div>
        </div>

        {/* Crossfader */}
        <div className="h-[60px] border-t border-[var(--border)] flex items-center justify-center px-10 relative shrink-0 bg-[var(--bg-main)]">
            <div className="absolute inset-x-12 h-1 bg-[var(--knob-track)] rounded-full top-1/2 -translate-y-1/2"></div>
            <span className="absolute left-3 text-[8px] font-bold text-[var(--text-secondary)] uppercase tracking-wider">Deck A</span>
            <span className="absolute right-3 text-[8px] font-bold text-[var(--text-secondary)] uppercase tracking-wider">Deck B</span>
            <div onClick={(e) => handleFaderClick('CROSSFADER', e)} className={`w-full relative z-10 ${isMapping ? 'ring-2 ring-[var(--accent)] ring-offset-2 ring-offset-[var(--bg-main)] z-50 animate-pulse cursor-pointer p-1' : ''}`}>
                <input 
                    type="range" min="0" max="1" step="0.005"
                    value={crossfader}
                    onChange={(e) => {
                        const v = parseFloat(e.target.value);
                        setCrossfader(snap(v, 0.5, 1));
                    }}
                    onDoubleClick={() => setCrossfader(0.5)}
                    className={`crossfader-range w-full ${isMapping ? 'pointer-events-none' : ''}`}
                />
            </div>
        </div>
    </div>
  );
};

export default Mixer;
