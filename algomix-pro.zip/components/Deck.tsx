
import React, { useRef, useState, useEffect } from 'react';
import { Track, SamplerSlot, PadMode, MappableAction } from '../types';

interface DeckProps {
  id: 'A' | 'B';
  track: Track | null;
  isPlaying: boolean;
  isLibraryConnected: boolean;
  pitchValue: number;
  progress: number;
  activePadMode: PadMode;
  onPadModeChange: (mode: PadMode) => void;
  onPlayPause: () => void;
  onLoadTrack: (file: File) => void;
  onPitchChange: (val: number) => void;
  onSync: () => void;
  onSeek: (p: number) => void; 
  waveformData: Uint8Array;
  
  touchPlatter: (type: 'vinyl' | 'ring', touched: boolean) => void;
  movePlatter: (deltaY: number) => void;
  toggleScratchMode: () => void;
  
  pads: SamplerSlot[];
  onTriggerPad: (id: number) => void;
  onLoadSample: (id: number, file: File) => void;
  
  onSetHotCue: (idx: number) => void;
  onTriggerHotCue: (idx: number) => void;
  onToggleLoop: (beats: number, padIndex: number) => void;
  onToggleFaderCut: (active: boolean, padIndex: number) => void;

  isMapping?: boolean;
  onMapClick?: (action: MappableAction) => void;
  onRequestLibrary?: (id: 'A'|'B') => void;
}

const snap = (val: number, center: number, rangeSpan: number) => {
    const threshold = rangeSpan * 0.04; // 4% snap zone
    if (Math.abs(val - center) < threshold) return center;
    return val;
};

const Deck: React.FC<DeckProps> = ({ 
    id, track, isPlaying, isLibraryConnected, pitchValue, progress, 
    activePadMode, onPadModeChange,
    onPlayPause, onLoadTrack, onPitchChange, onSync, onSeek, waveformData,
    touchPlatter, movePlatter, toggleScratchMode,
    pads, onTriggerPad, onLoadSample,
    onSetHotCue, onTriggerHotCue, onToggleLoop, onToggleFaderCut,
    isMapping, onMapClick, onRequestLibrary
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const overviewRef = useRef<HTMLDivElement>(null);
  const [activeZone, setActiveZone] = useState<'vinyl' | 'ring' | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const lastMouseY = useRef(0);
  const vinylRef = useRef<HTMLDivElement>(null);
  const [showRemainingTime, setShowRemainingTime] = useState(false);
  const [sampleInputRef, setSampleInputRef] = useState<HTMLInputElement | null>(null);
  const [activeSampleId, setActiveSampleId] = useState<number | null>(null);

  useEffect(() => {
      if (vinylRef.current && track) {
          const currentTime = progress * track.duration;
          const rotation = (currentTime * 360) / 1.8; 
          vinylRef.current.style.transform = `rotate(${rotation}deg)`;
      }
  }, [progress, track]);

  const handleSeekClick = (e: React.MouseEvent) => {
      if(!overviewRef.current || !track) return;
      const rect = overviewRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const p = Math.max(0, Math.min(1, x / rect.width));
      onSeek(p);
  };

  const handleLoadClick = () => {
      if (!isMapping) {
          if (isLibraryConnected && onRequestLibrary) {
              onRequestLibrary(id);
          } else {
              fileInputRef.current?.click();
          }
      }
  };

  const handleMouseDown = (e: React.MouseEvent, zone: 'vinyl' | 'ring') => {
      if (isMapping && onMapClick) {
          e.preventDefault();
          e.stopPropagation();
          // Split mapping for vinyl into Touch (Note) and Move (CC)
          const action = zone === 'vinyl' ? `PLATTER_TOUCH_${id}` : `PLATTER_MOVE_${id}`;
          onMapClick(action as MappableAction);
          return;
      }

      e.preventDefault();
      setActiveZone(zone);
      lastMouseY.current = e.clientY;
      touchPlatter(zone, true);
      const onMouseMove = (ev: MouseEvent) => {
          const deltaY = ev.clientY - lastMouseY.current;
          lastMouseY.current = ev.clientY;
          movePlatter(deltaY);
      };
      const onMouseUp = () => {
          touchPlatter(zone, false);
          setActiveZone(null);
          window.removeEventListener('mousemove', onMouseMove);
          window.removeEventListener('mouseup', onMouseUp);
      };
      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', onMouseUp);
  };

  const handlePadDown = (index: number) => {
      if (isMapping && onMapClick) {
           onMapClick(`PAD_${index+1}_${id}` as MappableAction);
           return;
      }
      if (activePadMode === 'cue') onTriggerHotCue(index);
      else if (activePadMode === 'loop') onToggleLoop(Math.pow(2, index), index);
      else if (activePadMode === 'cuts') onToggleFaderCut(true, index);
      else onTriggerPad(index);
  };

  const handlePadUp = (index: number) => {
      if (isMapping) return;
      if (activePadMode === 'cuts') onToggleFaderCut(false, index);
  };
  
  const handleSampleRightClick = (e: React.MouseEvent, index: number) => {
      e.preventDefault();
      setActiveSampleId(index);
      sampleInputRef?.click();
  }

  const handleMappingClick = (e: React.MouseEvent, action: MappableAction) => {
      if (isMapping && onMapClick) {
          e.preventDefault();
          e.stopPropagation();
          onMapClick(action);
      }
  }

  // DRAG AND DROP HANDLERS
  const onDragOver = (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(true);
  }
  const onDragLeave = (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
  }
  const onDrop = (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
          onLoadTrack(e.dataTransfer.files[0]);
      }
  }

  const renderOverviewWaveform = () => {
      if(!track || !track.waveform) return null;
      return (
          <div className="absolute inset-0 flex items-center gap-[1px] opacity-20 pointer-events-none">
              {track.waveform.map((peak, idx) => (
                  <div key={idx} className="flex-1 bg-[var(--accent)]" style={{ height: `${peak * 100}%` }}></div>
              ))}
          </div>
      );
  };

  const currentBpm = track ? (track.bpm * pitchValue).toFixed(1) : "0.0";
  const timeSignature = track ? (track.timeSignature || "4/4") : "-/-";

  const getDisplayTime = () => {
      if (!track) return "0:00";
      const total = track.duration;
      const current = total * progress;
      if (showRemainingTime) {
          const remaining = total - current;
          return `-${Math.floor(remaining / 60)}:${Math.floor(remaining % 60).toString().padStart(2, '0')}`;
      } else {
          return `${Math.floor(current / 60)}:${Math.floor(current % 60).toString().padStart(2, '0')}`;
      }
  };

  const mapStyle = isMapping ? 'ring-2 ring-[var(--accent)] ring-offset-2 ring-offset-[var(--bg-main)] cursor-pointer animate-pulse z-50' : '';

  // COMPONENTS

  const PitchFader = () => (
      <div className={`w-14 h-full bg-[var(--bg-panel)] border-x border-[var(--border)] flex items-center justify-center relative py-4 z-10`} onClick={(e) => handleMappingClick(e, `PITCH_${id}`)}>
          {/* Track Line */}
          <div className="absolute top-4 bottom-4 w-[2px] bg-[var(--border)] rounded-full"></div>
          {/* Center Mark */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-[2px] bg-[var(--text-secondary)]"></div>
          
          {/* Fader Handle wrapper */}
          <div className="h-full w-full relative">
               <input 
                 type="range" min="0.92" max="1.08" step="0.001"
                 value={pitchValue}
                 onChange={(e) => {
                     // Directly pass value, logic handled by parent
                     onPitchChange(parseFloat(e.target.value));
                 }}
                 className={`fader-clean-vertical absolute inset-0 w-full h-full opacity-0 cursor-ns-resize z-50 ${isMapping ? 'pointer-events-none' : 'pointer-events-auto'}`} 
                 style={{ transform: 'none' }} 
                 onDoubleClick={() => onPitchChange(1.0)}
              />
              {/* Visual Handle */}
              {/* 
                  Standard DJ Fader: Top is Slow (Minus), Bottom is Fast (Plus).
                  Logic: 0.92 (Slow) -> Top (0%). 1.08 (Fast) -> Bottom (100%).
               */}
              <div 
                className="absolute left-1/2 -translate-x-1/2 w-10 h-12 bg-[#e8e6d9] rounded shadow-lg border border-black/20 pointer-events-none z-40"
                style={{ 
                    top: `${((pitchValue - 0.92) / (1.08 - 0.92)) * 100}%`,
                    transform: 'translate(-50%, -50%)' 
                }}
              >
                  <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-black/50"></div>
              </div>
          </div>
      </div>
  );

  return (
    <div 
        className={`flex-1 flex flex-col bg-[var(--bg-main)] relative overflow-hidden h-full select-none border border-[var(--border)] rounded-xl transition-all ${isDragging ? 'border-[var(--accent)] bg-[var(--accent)]/10 scale-[0.99]' : ''}`}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
    >
      
      {/* 1. HEADER (Connect / Time) */}
      <div className="h-10 px-4 flex justify-between items-center border-b border-[var(--border)] bg-[var(--bg-panel)]">
          <div onClick={handleLoadClick} className="cursor-pointer hover:text-[var(--accent)] transition-colors truncate max-w-[50%]">
               <h2 className="font-serif italic text-lg text-[var(--text-primary)] truncate">{track ? track.name : (isLibraryConnected ? "LOAD TRACK" : "CONNECT")}</h2>
          </div>
          <div className="flex gap-4 items-center">
             <div className="text-right flex flex-col items-end">
                <span className="text-[9px] text-[var(--text-secondary)] tracking-widest uppercase">SIG</span>
                <span className="text-xs font-mono font-bold text-[var(--text-primary)]">{timeSignature}</span>
             </div>
             <div className="text-right flex flex-col items-end cursor-pointer" onClick={() => !isMapping && setShowRemainingTime(!showRemainingTime)}>
                <span className="text-[9px] text-[var(--text-secondary)] tracking-widest uppercase">BPM</span>
                <div className="flex items-baseline gap-1">
                    <div className="text-xs font-bold text-[var(--text-primary)]">{currentBpm}</div>
                    <div className="text-[9px] font-mono text-[var(--text-secondary)]">{getDisplayTime()}</div>
                </div>
             </div>
          </div>
          <input type="file" ref={fileInputRef} onChange={(e) => e.target.files?.[0] && onLoadTrack(e.target.files[0])} className="hidden" accept="audio/*" />
      </div>

      {/* 2. OVERVIEW WAVE (Thin strip) */}
      <div ref={overviewRef} onClick={handleSeekClick} className="h-3 w-full relative cursor-pointer bg-[var(--bg-surface)] group border-b border-[var(--border)]">
           {renderOverviewWaveform()}
           <div className="absolute top-0 bottom-0 w-[2px] bg-[var(--accent)] z-10 shadow-[0_0_5px_var(--accent)]" style={{ left: `${progress * 100}%` }}></div>
      </div>

      {/* 3. CENTER: VINYL + PITCH */}
      <div className="flex-1 flex flex-row relative min-h-0 bg-[var(--bg-main)]">
          
          {/* Deck B: Pitch on LEFT */}
          {id === 'B' && <PitchFader />}

          {/* VINYL AREA */}
          <div className="flex-1 flex items-center justify-center relative texture-noise overflow-hidden">
             {isDragging && (
                 <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
                     <div className="text-[var(--accent)] font-bold border-2 border-[var(--accent)] p-4 rounded-xl border-dashed">DROP TO LOAD</div>
                 </div>
             )}

             <div className="relative w-[60%] aspect-square max-w-[300px] max-h-[300px]">
                  {/* Platter Base */}
                  <div className={`absolute inset-0 rounded-full bg-[#0a0a0a] shadow-[0_10px_30px_rgba(0,0,0,0.8)] border border-[var(--border)] cursor-grab active:cursor-grabbing flex items-center justify-center ${activeZone === 'ring' ? 'border-[var(--accent)]' : ''} ${isMapping ? 'ring-4 ring-cyan-400' : ''}`}
                       onMouseDown={(e) => handleMouseDown(e, 'ring')}>
                      
                      {/* --- MAPPING OVERLAY FOR ROTATE --- */}
                      {isMapping && (
                          <div className="absolute inset-0 z-50 flex items-start justify-center pt-2 pointer-events-none">
                              <span className="bg-black/50 text-[8px] px-1 rounded text-cyan-300 font-bold backdrop-blur">MAP ROTATE</span>
                          </div>
                      )}

                      {/* Vinyl Record */}
                      <div ref={vinylRef} className={`w-[96%] h-[96%] rounded-full bg-[#050505] relative cursor-move shadow-inner ${isMapping ? 'ring-2 ring-[var(--accent)]' : ''}`}
                           onMouseDown={(e) => { e.stopPropagation(); handleMouseDown(e, 'vinyl'); }}>
                           
                           {/* --- MAPPING OVERLAY FOR TOUCH --- */}
                           {isMapping && (
                               <div className="absolute inset-0 z-50 flex items-center justify-center pointer-events-none bg-white/5 rounded-full">
                                    <span className="bg-black/50 text-[8px] px-1 rounded text-[var(--accent)] font-bold backdrop-blur">MAP TOUCH</span>
                               </div>
                           )}

                           {/* Grooves */}
                           <div className="absolute inset-0 rounded-full opacity-20 pointer-events-none" 
                                style={{background: 'repeating-radial-gradient(#333 0, #111 2px, #222 3px)'}}></div>
                           {/* Label */}
                           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1/3 h-1/3 rounded-full z-10 shadow-lg" 
                                style={{ background: `conic-gradient(from 0deg, #d4d4d4, #f0f0f0, #d4d4d4)` }}>
                                <div className="absolute inset-1 rounded-full bg-gradient-to-tr from-gray-300 to-gray-100 flex items-center justify-center">
                                    <div className="w-2 h-2 bg-black rounded-full"></div>
                                </div>     
                           </div>
                           {/* Marker */}
                           <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[2px] h-[50%] bg-white/80 z-20 origin-bottom pointer-events-none"></div>
                      </div>
                  </div>
              </div>
          </div>

          {/* Deck A: Pitch on RIGHT */}
          {id === 'A' && <PitchFader />}
          
      </div>

      {/* 4. BOTTOM: PADS & TRANSPORT */}
      <div className="h-[220px] bg-[var(--bg-panel)] border-t border-[var(--border)] p-4 flex flex-col gap-3 flex-shrink-0">
          
          {/* Mode Tabs */}
          <div className="flex justify-between border-b border-[var(--border)] pb-1 mb-1">
              {(['cue', 'loop', 'cuts', 'sample'] as PadMode[]).map(mode => (
                  <button 
                    key={mode} 
                    onClick={(e) => {
                        if (isMapping && onMapClick) {
                            e.stopPropagation();
                            onMapClick(`PAD_MODE_${mode.toUpperCase()}_${id}` as MappableAction);
                        } else {
                            onPadModeChange(mode);
                        }
                    }} 
                    className={`
                        text-[10px] font-bold font-mono uppercase px-2 py-1 transition-colors relative
                        ${activePadMode === mode ? 'text-[var(--text-primary)]' : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'}
                        ${isMapping ? 'ring-1 ring-[var(--accent)] animate-pulse' : ''}
                    `}
                  >
                    {mode}
                    {activePadMode === mode && <div className="absolute bottom-[-5px] left-0 right-0 h-[2px] bg-[var(--accent)]"></div>}
                  </button>
              ))}
          </div>

          {/* Pads Grid (2x4) */}
          <div className="grid grid-cols-4 grid-rows-2 gap-2 flex-1 min-h-0">
              <input type="file" ref={setSampleInputRef} className="hidden" accept="audio/*" onChange={(e) => activeSampleId !== null && e.target.files?.[0] && onLoadSample(activeSampleId, e.target.files[0])} />
              {Array.from({ length: 8 }).map((_, idx) => (
                   <button 
                      key={idx}
                      onMouseDown={() => handlePadDown(idx)}
                      onMouseUp={() => handlePadUp(idx)}
                      onMouseLeave={() => handlePadUp(idx)}
                      onContextMenu={(e) => handleSampleRightClick(e, idx)}
                      className={`
                        rounded border bg-[var(--bg-surface)] active:bg-[var(--accent)] active:text-[var(--bg-main)] transition-all relative overflow-hidden group btn-press
                        ${activePadMode === 'sample' && pads[idx]?.isTriggered ? 'border-[var(--accent)] bg-[var(--accent)]/20' : 'border-[var(--border)]'}
                        ${mapStyle}
                      `}
                   >
                       <span className="text-[10px] font-mono text-[var(--text-secondary)] group-active:text-current font-bold">
                           {activePadMode === 'sample' ? (pads[idx]?.name.slice(0,4) || `S${idx+1}`) : activePadMode === 'loop' ? Math.pow(2, idx) : activePadMode === 'cue' ? `C${idx+1}` : `X${idx+1}`}
                       </span>
                   </button>
              ))}
          </div>

          {/* Transport Controls */}
          <div className="flex justify-between items-center pt-2">
              <div className="flex items-center gap-3">
                  <button 
                    onClick={(e) => isMapping ? handleMappingClick(e, `CUE_${id}`) : onSeek(0)} 
                    className={`w-12 h-12 rounded-full border border-[var(--border)] text-[var(--text-secondary)] bg-[var(--bg-surface)] hover:text-[var(--text-primary)] hover:border-[var(--text-secondary)] flex items-center justify-center active:scale-95 transition-transform ${mapStyle}`}
                  >
                      <span className="text-[10px] font-bold tracking-widest">CUE</span>
                  </button>
                  <button 
                    onClick={(e) => isMapping ? handleMappingClick(e, `PLAY_${id}`) : onPlayPause()} 
                    className={`w-14 h-14 rounded-full border flex items-center justify-center active:scale-95 transition-all ${isPlaying ? 'border-[var(--accent)] bg-[var(--accent)]/10 text-[var(--accent)] shadow-[0_0_15px_rgba(207,171,72,0.2)]' : 'border-[var(--border)] text-[var(--text-secondary)] bg-[var(--bg-surface)]'} ${mapStyle}`}
                  >
                      <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                  </button>
              </div>
              <button 
                onClick={(e) => isMapping ? handleMappingClick(e, `SYNC_${id}`) : onSync()} 
                className={`px-4 py-2 border border-[var(--border)] text-[10px] font-bold tracking-widest rounded bg-[var(--bg-surface)] hover:bg-[var(--text-primary)] hover:text-[var(--bg-main)] active:scale-95 transition-all ${mapStyle}`}
              >
                  SYNC
              </button>
          </div>
      </div>
    </div>
  );
};

export default Deck;
