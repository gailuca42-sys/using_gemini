
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { MappableAction } from '../types';

interface MixtrackMapperProps {
    onMapClick: (action: MappableAction) => void;
    waitingForAction: MappableAction | null;
    pendingMapping: { key: string, val: number, min?: number, max?: number } | null;
    lastActiveAction: MappableAction | null; // NEW: Triggers flash
    onConfirm: () => void;
    onCancel: () => void;
    onExport: () => void;
}

type ControlType = 'button' | 'fader' | 'knob' | 'jog' | 'pad';
type Category = 'DECK A' | 'DECK B' | 'MIXER' | 'FX';

interface ControlDef {
    label: string;
    action: MappableAction;
    type: ControlType;
    category: Category;
    instruction: string;
}

const CONTROLS: ControlDef[] = [
    // --- DECK A ---
    { label: 'Play / Pause', action: 'PLAY_A', type: 'button', category: 'DECK A', instruction: 'Press the PLAY button' },
    { label: 'Cue', action: 'CUE_A', type: 'button', category: 'DECK A', instruction: 'Press the CUE button' },
    { label: 'Sync', action: 'SYNC_A', type: 'button', category: 'DECK A', instruction: 'Press the SYNC button' },
    { label: 'Scratch (Vinyl) Mode', action: 'SCRATCH_MODE_A', type: 'button', category: 'DECK A', instruction: 'Press SHIFT + Platter Top OR Scratch Button' },
    { label: 'Load Track', action: 'LOAD_A', type: 'button', category: 'DECK A', instruction: 'Press the LOAD button for Deck A' },
    
    { label: 'Jog Wheel (Touch)', action: 'PLATTER_TOUCH_A', type: 'button', category: 'DECK A', instruction: 'Touch the metal top of the Jog Wheel' },
    { label: 'Jog Wheel (Rotate)', action: 'PLATTER_MOVE_A', type: 'jog', category: 'DECK A', instruction: 'Rotate the wheel 1 full turn (360°) to calibrate resolution' },
    { label: 'Pitch Fader', action: 'PITCH_A', type: 'fader', category: 'DECK A', instruction: 'Move fader to MIN (top), then MAX (bottom)' },
    { label: 'Pitch Bend +', action: 'PITCH_BEND_UP_A', type: 'button', category: 'DECK A', instruction: 'Press Pitch Bend +' },
    { label: 'Pitch Bend -', action: 'PITCH_BEND_DOWN_A', type: 'button', category: 'DECK A', instruction: 'Press Pitch Bend -' },
    
    // Pads A
    { label: 'Pad 1', action: 'PAD_1_A', type: 'pad', category: 'DECK A', instruction: 'Press Pad 1' },
    { label: 'Pad 2', action: 'PAD_2_A', type: 'pad', category: 'DECK A', instruction: 'Press Pad 2' },
    { label: 'Pad 3', action: 'PAD_3_A', type: 'pad', category: 'DECK A', instruction: 'Press Pad 3' },
    { label: 'Pad 4', action: 'PAD_4_A', type: 'pad', category: 'DECK A', instruction: 'Press Pad 4' },
    { label: 'Pad 5', action: 'PAD_5_A', type: 'pad', category: 'DECK A', instruction: 'Press Pad 5' },
    { label: 'Pad 6', action: 'PAD_6_A', type: 'pad', category: 'DECK A', instruction: 'Press Pad 6' },
    { label: 'Pad 7', action: 'PAD_7_A', type: 'pad', category: 'DECK A', instruction: 'Press Pad 7' },
    { label: 'Pad 8', action: 'PAD_8_A', type: 'pad', category: 'DECK A', instruction: 'Press Pad 8' },

    { label: 'Mode: Hot Cue', action: 'PAD_MODE_CUE_A', type: 'button', category: 'DECK A', instruction: 'Press Cue Mode Button' },
    { label: 'Mode: Auto Loop', action: 'PAD_MODE_LOOP_A', type: 'button', category: 'DECK A', instruction: 'Press Loop Mode Button' },
    { label: 'Mode: Fader Cuts', action: 'PAD_MODE_CUTS_A', type: 'button', category: 'DECK A', instruction: 'Press Fader Cuts Mode Button' },
    { label: 'Mode: Sample', action: 'PAD_MODE_SAMPLE_A', type: 'button', category: 'DECK A', instruction: 'Press Sample Mode Button' },
    
    { label: 'Loop Half (1/2)', action: 'LOOP_HALF_A', type: 'button', category: 'DECK A', instruction: 'Press Loop 1/2 Button' },
    { label: 'Loop Double (x2)', action: 'LOOP_DOUBLE_A', type: 'button', category: 'DECK A', instruction: 'Press Loop x2 Button' },
    { label: 'Loop In/Out', action: 'LOOP_IN_OUT_A', type: 'button', category: 'DECK A', instruction: 'Press Loop In/Out' },

    // --- DECK B ---
    { label: 'Play / Pause', action: 'PLAY_B', type: 'button', category: 'DECK B', instruction: 'Press the PLAY button' },
    { label: 'Cue', action: 'CUE_B', type: 'button', category: 'DECK B', instruction: 'Press the CUE button' },
    { label: 'Sync', action: 'SYNC_B', type: 'button', category: 'DECK B', instruction: 'Press the SYNC button' },
    { label: 'Scratch (Vinyl) Mode', action: 'SCRATCH_MODE_B', type: 'button', category: 'DECK B', instruction: 'Press SHIFT + Platter Top OR Scratch Button' },
    { label: 'Load Track', action: 'LOAD_B', type: 'button', category: 'DECK B', instruction: 'Press the LOAD button for Deck B' },

    { label: 'Jog Wheel (Touch)', action: 'PLATTER_TOUCH_B', type: 'button', category: 'DECK B', instruction: 'Touch the metal top of the Jog Wheel' },
    { label: 'Jog Wheel (Rotate)', action: 'PLATTER_MOVE_B', type: 'jog', category: 'DECK B', instruction: 'Rotate the wheel 1 full turn (360°) to calibrate resolution' },
    { label: 'Pitch Fader', action: 'PITCH_B', type: 'fader', category: 'DECK B', instruction: 'Move fader to MIN (top), then MAX (bottom)' },
    { label: 'Pitch Bend +', action: 'PITCH_BEND_UP_B', type: 'button', category: 'DECK B', instruction: 'Press Pitch Bend +' },
    { label: 'Pitch Bend -', action: 'PITCH_BEND_DOWN_B', type: 'button', category: 'DECK B', instruction: 'Press Pitch Bend -' },

    // Pads B
    { label: 'Pad 1', action: 'PAD_1_B', type: 'pad', category: 'DECK B', instruction: 'Press Pad 1' },
    { label: 'Pad 2', action: 'PAD_2_B', type: 'pad', category: 'DECK B', instruction: 'Press Pad 2' },
    { label: 'Pad 3', action: 'PAD_3_B', type: 'pad', category: 'DECK B', instruction: 'Press Pad 3' },
    { label: 'Pad 4', action: 'PAD_4_B', type: 'pad', category: 'DECK B', instruction: 'Press Pad 4' },
    { label: 'Pad 5', action: 'PAD_5_B', type: 'pad', category: 'DECK B', instruction: 'Press Pad 5' },
    { label: 'Pad 6', action: 'PAD_6_B', type: 'pad', category: 'DECK B', instruction: 'Press Pad 6' },
    { label: 'Pad 7', action: 'PAD_7_B', type: 'pad', category: 'DECK B', instruction: 'Press Pad 7' },
    { label: 'Pad 8', action: 'PAD_8_B', type: 'pad', category: 'DECK B', instruction: 'Press Pad 8' },

    { label: 'Mode: Hot Cue', action: 'PAD_MODE_CUE_B', type: 'button', category: 'DECK B', instruction: 'Press Cue Mode Button' },
    { label: 'Mode: Auto Loop', action: 'PAD_MODE_LOOP_B', type: 'button', category: 'DECK B', instruction: 'Press Loop Mode Button' },
    { label: 'Mode: Fader Cuts', action: 'PAD_MODE_CUTS_B', type: 'button', category: 'DECK B', instruction: 'Press Fader Cuts Mode Button' },
    { label: 'Mode: Sample', action: 'PAD_MODE_SAMPLE_B', type: 'button', category: 'DECK B', instruction: 'Press Sample Mode Button' },

    { label: 'Loop Half (1/2)', action: 'LOOP_HALF_B', type: 'button', category: 'DECK B', instruction: 'Press Loop 1/2 Button' },
    { label: 'Loop Double (x2)', action: 'LOOP_DOUBLE_B', type: 'button', category: 'DECK B', instruction: 'Press Loop x2 Button' },
    { label: 'Loop In/Out', action: 'LOOP_IN_OUT_B', type: 'button', category: 'DECK B', instruction: 'Press Loop In/Out' },

    // --- MIXER ---
    { label: 'Crossfader', action: 'CROSSFADER', type: 'fader', category: 'MIXER', instruction: 'Slide Crossfader fully Left to Right' },
    { label: 'Volume A', action: 'VOL_A', type: 'fader', category: 'MIXER', instruction: 'Slide Volume A from Bottom to Top' },
    { label: 'Volume B', action: 'VOL_B', type: 'fader', category: 'MIXER', instruction: 'Slide Volume B from Bottom to Top' },
    
    { label: 'Gain A', action: 'GAIN_A', type: 'knob', category: 'MIXER', instruction: 'Turn Gain A from 0 to 100%' },
    { label: 'EQ High A', action: 'EQ_HI_A', type: 'knob', category: 'MIXER', instruction: 'Turn High EQ A from Left to Right' },
    { label: 'EQ Mid A', action: 'EQ_MID_A', type: 'knob', category: 'MIXER', instruction: 'Turn Mid EQ A from Left to Right' },
    { label: 'EQ Low A', action: 'EQ_LOW_A', type: 'knob', category: 'MIXER', instruction: 'Turn Low EQ A from Left to Right' },
    { label: 'Filter A', action: 'FILTER_A', type: 'knob', category: 'MIXER', instruction: 'Turn Filter A from Left to Right' },

    { label: 'Gain B', action: 'GAIN_B', type: 'knob', category: 'MIXER', instruction: 'Turn Gain B from 0 to 100%' },
    { label: 'EQ High B', action: 'EQ_HI_B', type: 'knob', category: 'MIXER', instruction: 'Turn High EQ B from Left to Right' },
    { label: 'EQ Mid B', action: 'EQ_MID_B', type: 'knob', category: 'MIXER', instruction: 'Turn Mid EQ B from Left to Right' },
    { label: 'EQ Low B', action: 'EQ_LOW_B', type: 'knob', category: 'MIXER', instruction: 'Turn Low EQ B from Left to Right' },
    { label: 'Filter B', action: 'FILTER_B', type: 'knob', category: 'MIXER', instruction: 'Turn Filter B from Left to Right' },
    
    { label: 'Browse (Push)', action: 'BROWSE_PUSH', type: 'button', category: 'MIXER', instruction: 'Press the Browse Encoder' },
    { label: 'Browse (Scroll)', action: 'BROWSE_SCROLL', type: 'knob', category: 'MIXER', instruction: 'Turn Browse Encoder one full circle' },
    { label: 'SHIFT', action: 'SHIFT', type: 'button', category: 'MIXER', instruction: 'Press and hold the Shift button' },

    // --- FX ---
    { label: 'Paddle A', action: 'FX_PADDLE_A', type: 'button', category: 'FX', instruction: 'Pull or Push Paddle A' },
    { label: 'Paddle B', action: 'FX_PADDLE_B', type: 'button', category: 'FX', instruction: 'Pull or Push Paddle B' },
    { label: 'HPF Button', action: 'FX_HPF', type: 'button', category: 'FX', instruction: 'Press HPF' },
    { label: 'LPF Button', action: 'FX_LPF', type: 'button', category: 'FX', instruction: 'Press LPF' },
    { label: 'Flanger', action: 'FX_FLANGER', type: 'button', category: 'FX', instruction: 'Press Flanger' },
    { label: 'Echo', action: 'FX_ECHO', type: 'button', category: 'FX', instruction: 'Press Echo' },
    { label: 'Reverb', action: 'FX_REVERB', type: 'button', category: 'FX', instruction: 'Press Reverb' },
    { label: 'Phaser', action: 'FX_PHASER', type: 'button', category: 'FX', instruction: 'Press Phaser' },
];

const ControlRow = ({ control, isActive, onClick, pendingMapping, onConfirm, isFlashActive }: { 
    control: ControlDef, 
    isActive: boolean, 
    onClick: () => void,
    pendingMapping: { key: string, val: number, min?: number, max?: number } | null,
    onConfirm: () => void,
    isFlashActive: boolean
}) => {
    
    const getIcon = () => {
        switch (control.type) {
            case 'fader': return (
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                </svg>
            );
            case 'knob': return (
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            );
            case 'jog': return (
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.933 12.8a1 1 0 00-.933-1.28h-.133m-2.667 0h-2.133m-1.333 3.2l-1.6 2.133m16-2.133l1.6 2.133M7.2 18.133l-1.6 2.133m8.533-2.133l1.6 2.133M12 2a10 10 0 110 20 10 10 0 010-20z" />
                </svg>
            );
            case 'pad': return (
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <rect x="3" y="3" width="18" height="18" rx="2" strokeWidth={2} />
                    <circle cx="12" cy="12" r="3" fill="currentColor" opacity={0.2} />
                </svg>
            );
            default: return (
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
                </svg>
            );
        }
    };

    return (
        <div 
            onClick={onClick}
            className={`
                group flex items-center justify-between p-3 rounded-lg border transition-all cursor-pointer
                ${isFlashActive ? 'bg-green-500 text-white border-green-400 shadow-[0_0_20px_rgba(34,197,94,0.6)] scale-105 z-50' : 
                  isActive 
                    ? 'bg-[var(--accent)] border-[var(--accent)] text-[var(--bg-main)] shadow-[0_0_15px_var(--accent)] scale-[1.01]' 
                    : 'bg-[var(--bg-surface)] border-[var(--border)] hover:border-[var(--text-secondary)] hover:bg-[var(--bg-panel)]'}
            `}
        >
            <div className="flex items-center gap-3">
                <div className={`p-2 rounded-md ${isFlashActive ? 'bg-white/20' : isActive ? 'bg-black/10' : 'bg-[var(--bg-main)]'}`}>
                    {getIcon()}
                </div>
                <div>
                    <div className="font-bold text-xs uppercase tracking-wider">{control.label}</div>
                    <div className={`text-[10px] font-mono ${isFlashActive ? 'text-white' : isActive ? 'text-black/70 font-bold' : 'text-[var(--text-secondary)]'}`}>
                        {isFlashActive ? 'SIGNAL DETECTED ✓' : isActive ? (
                            <span className="flex items-center gap-2">
                                <span className="animate-pulse">●</span> LISTENING...
                            </span>
                        ) : `ID: ${control.action}`}
                    </div>
                </div>
            </div>
            
            <div className="text-right">
                 {isActive ? (
                     pendingMapping ? (
                         <div className="flex items-center gap-2 animate-[fadeIn_0.2s]">
                             <div className="text-right mr-2 flex flex-col items-end">
                                 <div className="text-[10px] font-bold">SIGNAL: {pendingMapping.key}</div>
                                 <div className="text-[9px] font-mono opacity-80">
                                     RANGE: {pendingMapping.min} - {pendingMapping.max}
                                 </div>
                                 {/* Calibration Visual */}
                                 {(control.type === 'fader' || control.type === 'knob') && pendingMapping.max !== undefined && pendingMapping.min !== undefined && (
                                     <div className="w-20 h-1 bg-black/20 mt-1 rounded-full overflow-hidden">
                                         <div 
                                            className="h-full bg-black/50" 
                                            style={{ 
                                                width: `${((pendingMapping.val - pendingMapping.min) / Math.max(1, pendingMapping.max - pendingMapping.min)) * 100}%` 
                                            }}
                                         ></div>
                                     </div>
                                 )}
                             </div>
                             <button 
                                onClick={(e) => { e.stopPropagation(); onConfirm(); }}
                                className="bg-black text-white px-3 py-1.5 rounded text-[10px] font-bold hover:scale-105 active:scale-95 transition-transform shadow-lg border border-white/20"
                             >
                                 CONFIRM
                             </button>
                         </div>
                     ) : (
                        <div className="text-[10px] italic opacity-80 px-2">Waiting for input...</div>
                     )
                 ) : (
                     <div className={`text-[10px] px-2 py-1 rounded border ${isFlashActive ? 'border-white/50 bg-white/20 font-bold' : 'border-transparent group-hover:border-[var(--border)]'}`}>
                         {isFlashActive ? 'OK!' : 'MAP'}
                     </div>
                 )}
            </div>
        </div>
    );
};

const MixtrackMapper: React.FC<MixtrackMapperProps> = ({ onMapClick, waitingForAction, pendingMapping, onConfirm, onExport, lastActiveAction }) => {
    const [activeCategory, setActiveCategory] = useState<Category>('DECK A');
    const scrollRef = useRef<HTMLDivElement>(null);

    // Auto-switch category if the detected action belongs to a different one
    useEffect(() => {
        if (lastActiveAction) {
            const def = CONTROLS.find(c => c.action === lastActiveAction);
            if (def && def.category !== activeCategory) {
                setActiveCategory(def.category);
            }
            // Auto scroll to the element would happen here if we used refs for each row, 
            // but category switching is a good start.
        }
    }, [lastActiveAction]);

    const filteredControls = useMemo(() => {
        return CONTROLS.filter(c => c.category === activeCategory);
    }, [activeCategory]);

    const activeControlDef = CONTROLS.find(c => c.action === waitingForAction);

    // Auto-scroll to category when clicked
    useEffect(() => {
        if (scrollRef.current) scrollRef.current.scrollTop = 0;
    }, [activeCategory]);

    return (
        <div className="w-full h-full flex flex-col bg-[var(--bg-main)] overflow-hidden rounded-xl shadow-2xl border border-[var(--border)]">
            
            {/* Top Instruction Bar - Calibration Mode */}
            <div className="flex-shrink-0 p-6 bg-[var(--bg-panel)] border-b border-[var(--border)] relative overflow-hidden">
                <div className="absolute inset-0 bg-[var(--accent)]/5 pointer-events-none"></div>
                
                {activeControlDef ? (
                    <div className="flex flex-col items-center justify-center gap-2 animate-[fadeIn_0.2s] relative z-10">
                         <div className="text-[var(--accent)] font-bold text-xs tracking-[0.2em] uppercase mb-1 border-b border-[var(--accent)] pb-1">CALIBRATION MODE</div>
                         <h2 className="text-3xl font-serif italic text-[var(--text-primary)]">{activeControlDef.label}</h2>
                         
                         <div className="bg-[var(--accent)] text-[var(--bg-main)] px-6 py-2 rounded-full font-bold text-sm mt-3 shadow-[0_0_20px_rgba(207,171,72,0.3)] animate-pulse flex items-center gap-2">
                             <span>ℹ</span> {activeControlDef.instruction}
                         </div>
                         
                         {activeControlDef.type === 'fader' || activeControlDef.type === 'knob' ? (
                             <div className="flex flex-col items-center mt-2">
                                <p className="text-[var(--text-secondary)] text-[10px] font-mono bg-black/30 px-2 py-1 rounded mb-1">
                                    Move control all the way DOWN (Min) then all the way UP (Max).
                                </p>
                                <p className="text-[9px] text-[var(--accent)] opacity-80">
                                    System detects largest amplitude automatically.
                                </p>
                             </div>
                         ) : (
                            <p className="text-[var(--text-secondary)] text-[10px] mt-2 font-mono bg-black/30 px-2 py-1 rounded">
                                 Press the button firmly once. Auto-maps on press.
                             </p>
                         )}
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center h-24 text-[var(--text-secondary)] relative z-10">
                        <div className="w-12 h-12 rounded-full border-2 border-[var(--border)] flex items-center justify-center mb-2 opacity-50">
                            <span className="text-xl">👆</span>
                        </div>
                        <p className="text-sm font-medium">Select a component below to map it.</p>
                        <p className="text-[10px] opacity-60 mt-1">Mixtrack Pro FX Profile Active</p>
                    </div>
                )}
            </div>

            {/* Category Tabs */}
            <div className="flex border-b border-[var(--border)] bg-[var(--bg-surface)]">
                {(['DECK A', 'MIXER', 'FX', 'DECK B'] as Category[]).map(cat => (
                    <button
                        key={cat}
                        onClick={() => setActiveCategory(cat)}
                        className={`
                            flex-1 py-4 text-[10px] md:text-xs font-bold tracking-widest uppercase transition-all
                            ${activeCategory === cat 
                                ? 'bg-[var(--bg-main)] text-[var(--accent)] border-b-2 border-[var(--accent)]' 
                                : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-panel)]'}
                        `}
                    >
                        {cat}
                    </button>
                ))}
            </div>

            {/* Scrollable List */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 bg-[var(--bg-main)]">
                <div className="grid grid-cols-1 gap-2 pb-20">
                    {filteredControls.map((ctrl, idx) => (
                        <ControlRow 
                            key={idx} 
                            control={ctrl} 
                            isActive={waitingForAction === ctrl.action} 
                            isFlashActive={lastActiveAction === ctrl.action}
                            pendingMapping={waitingForAction === ctrl.action ? pendingMapping : null}
                            onClick={() => onMapClick(ctrl.action)}
                            onConfirm={onConfirm}
                        />
                    ))}
                </div>
            </div>
            
            {/* Footer Actions */}
            <div className="p-4 bg-[var(--bg-panel)] border-t border-[var(--border)] flex justify-between items-center gap-4">
                 <div className="text-[10px] text-[var(--text-secondary)]">
                     <span className="block font-bold text-[var(--text-primary)]">MAPPING PROGRESS</span>
                     <span>Map all controls then export.</span>
                 </div>
                 <button 
                    onClick={onExport}
                    className="bg-[var(--accent)] hover:bg-white text-black px-6 py-3 rounded font-bold text-xs tracking-widest shadow-lg hover:shadow-[0_0_20px_rgba(255,255,255,0.4)] transition-all flex items-center gap-2"
                 >
                     <span>💾</span> EXPORT MAPPING FILE
                 </button>
            </div>

        </div>
    );
};

export default MixtrackMapper;
