
import { useEffect, useRef, useState, useCallback } from 'react';
import { Track, SamplerSlot, AiMelody } from '../types';

interface AudioDeck {
  source: AudioBufferSourceNode | null;
  trimNode: GainNode; 
  gainNode: GainNode; 
  cueGainNode: GainNode; // New Cue Send
  lowFilter: BiquadFilterNode;
  midFilter: BiquadFilterNode;
  highFilter: BiquadFilterNode;
  sweepLowPass: BiquadFilterNode;
  sweepHighPass: BiquadFilterNode;
  
  // FX Nodes (Placeholder for simulation)
  fxNode: GainNode;

  analyser: AnalyserNode;
  
  // Time Keeping
  startTime: number; // When the *current* source started playing context time
  pauseTime: number; // Where we are in the track (seconds)
  
  // State
  isPlaying: boolean;
  buffer: AudioBuffer | null;
  isCueActive: boolean; // Monitor state
  
  // Interactions
  isScratching: boolean; // Touching the top vinyl
  isNudging: boolean;    // Touching the outer ring
  playbackRateVal: number; // Base Pitch Slider Value
  
  hotCues: number[]; 
  activeLoop: { start: number, length: number, padIndex: number } | null;
  
  // Hardware FX State
  activeFx: 'none' | 'flanger' | 'echo' | 'reverb';
}

const DEFAULT_SAMPLES = [
  { id: 0, name: 'KICK', color: 'bg-red-500', type: 'kick' },
  { id: 1, name: 'SNARE', color: 'bg-orange-500', type: 'snare' },
  { id: 2, name: 'HIHAT', color: 'bg-yellow-500', type: 'hihat' },
  { id: 3, name: 'VOCAL', color: 'bg-green-500', type: 'vocal' },
  { id: 4, name: 'HORN', color: 'bg-blue-500', type: 'horn' },
  { id: 5, name: 'LASER', color: 'bg-indigo-500', type: 'laser' },
  { id: 6, name: 'CRASH', color: 'bg-violet-500', type: 'crash' },
  { id: 7, name: 'RISER', color: 'bg-pink-500', type: 'riser' },
];

const createSyntheticBuffer = (ctx: AudioContext, type: string): AudioBuffer => {
    const buffer = ctx.createBuffer(1, ctx.sampleRate * 0.5, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    const len = data.length;
    for (let i = 0; i < len; i++) {
        const t = i / ctx.sampleRate;
        if (type === 'kick') {
            const freq = 150 * Math.exp(-t * 15);
            data[i] = Math.sin(2 * Math.PI * freq * t) * Math.exp(-t * 5);
        } else if (type === 'snare') {
            const noise = (Math.random() * 2 - 1) * Math.exp(-t * 10);
            const tone = Math.sin(2 * Math.PI * 200 * t) * Math.exp(-t * 8);
            data[i] = (noise * 0.7 + tone * 0.3);
        } else {
            data[i] = (Math.random() * 2 - 1) * Math.exp(-t * 5);
        }
    }
    return buffer;
}

const extractPeaks = (buffer: AudioBuffer, samplesPerPixel: number = 1000) => {
    const data = buffer.getChannelData(0);
    const len = data.length;
    const peaks = [];
    for(let i=0; i<len; i+= samplesPerPixel) {
        let max = 0;
        for(let j=0; j<100 && i+j<len; j++) {
            const v = Math.abs(data[i+j]);
            if(v > max) max = v;
        }
        peaks.push(max);
    }
    return peaks;
};

// --- SIMPLIFIED BPM DETECTION ALGORITHM ---
const detectBPM = (buffer: AudioBuffer): { bpm: number, signature: string } => {
    try {
        const data = buffer.getChannelData(0);
        const sampleRate = buffer.sampleRate;
        const startSec = Math.min(30, buffer.duration / 4);
        const endSec = Math.min(60, buffer.duration / 2 + 15);
        const start = Math.floor(startSec * sampleRate);
        const end = Math.floor(endSec * sampleRate);
        const fragment = data.slice(start, end);
        
        const peaks = [];
        const threshold = 0.6;
        const minDistance = sampleRate * 0.3;
        
        for(let i=0; i<fragment.length; i++) {
            if (Math.abs(fragment[i]) > threshold) {
                if (peaks.length === 0 || i - peaks[peaks.length-1] > minDistance) {
                    peaks.push(i);
                }
            }
        }
        
        if (peaks.length < 10) return { bpm: 128, signature: '4/4' };

        const intervals = [];
        for(let i=1; i<peaks.length; i++) {
            intervals.push(peaks[i] - peaks[i-1]);
        }
        
        const counts: Record<number, number> = {};
        intervals.forEach(int => {
            const quantized = Math.round(int / 500) * 500;
            counts[quantized] = (counts[quantized] || 0) + 1;
        });
        
        let bestInterval = 0;
        let maxCount = 0;
        for (const [int, count] of Object.entries(counts)) {
            if (count > maxCount) {
                maxCount = count;
                bestInterval = parseInt(int);
            }
        }
        
        if (bestInterval === 0) return { bpm: 128, signature: '4/4' };
        let bpm = 60 * sampleRate / bestInterval;
        while (bpm < 70) bpm *= 2;
        while (bpm > 180) bpm /= 2;

        bpm = Math.round(bpm * 10) / 10;
        const signature = (bpm > 110 && bpm < 150) ? '4/4' : (Math.random() > 0.9 ? '3/4' : '4/4');
        return { bpm, signature };

    } catch (e) {
        return { bpm: 128, signature: '4/4' };
    }
};

export const useAudioEngine = () => {
  const audioContextRef = useRef<AudioContext | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);
  const cueBusRef = useRef<GainNode | null>(null);
  const cueDestinationRef = useRef<MediaStreamAudioDestinationNode | null>(null);
  const cueAudioElementRef = useRef<HTMLAudioElement | null>(null);
  
  const deckARef = useRef<AudioDeck | null>(null);
  const deckBRef = useRef<AudioDeck | null>(null);
  
  const [samples, setSamples] = useState<SamplerSlot[]>(
    DEFAULT_SAMPLES.map(s => ({ ...s, buffer: null, isTriggered: false }))
  );
  const samplesRef = useRef<SamplerSlot[]>(
    DEFAULT_SAMPLES.map(s => ({ ...s, buffer: null, isTriggered: false }))
  );

  const [isReady, setIsReady] = useState(false);
  const [waveformDataA, setWaveformDataA] = useState<Uint8Array>(new Uint8Array(0));
  const [waveformDataB, setWaveformDataB] = useState<Uint8Array>(new Uint8Array(0));
  
  const [progressA, setProgressA] = useState(0);
  const [progressB, setProgressB] = useState(0);
  
  const [availableDevices, setAvailableDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedCueDeviceId, setSelectedCueDeviceId] = useState<string>('');

  // Audio Output Handling
  const scanAudioDevices = useCallback(async () => {
      try {
          if (!navigator.mediaDevices?.enumerateDevices) return;
          const devices = await navigator.mediaDevices.enumerateDevices();
          const audioOutputs = devices.filter(d => d.kind === 'audiooutput');
          setAvailableDevices(audioOutputs);
      } catch (e) { console.error("Device scan failed", e); }
  }, []);

  const setCueOutputDevice = useCallback(async (deviceId: string) => {
      if (!cueAudioElementRef.current) return;
      try {
          // @ts-ignore
          if (typeof cueAudioElementRef.current.setSinkId === 'function') {
              // @ts-ignore
              await cueAudioElementRef.current.setSinkId(deviceId);
              setSelectedCueDeviceId(deviceId);
              console.log("Cue output set to:", deviceId);
          } else {
              console.warn("setSinkId not supported in this browser");
          }
      } catch (e) { console.error("Failed to set sink ID", e); }
  }, []);

  const initAudio = useCallback(() => {
    if (audioContextRef.current) return;
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = new AudioContextClass();
    audioContextRef.current = ctx;

    const master = ctx.createGain();
    const compressor = ctx.createDynamicsCompressor();
    master.connect(compressor);
    compressor.connect(ctx.destination);
    masterGainRef.current = master;
    
    // CUE BUS SETUP
    const cueBus = ctx.createGain();
    cueBusRef.current = cueBus;
    const cueDest = ctx.createMediaStreamDestination();
    cueBus.connect(cueDest);
    cueDestinationRef.current = cueDest;
    
    // Create Hidden Audio Element for Cueing Output
    const audio = new Audio();
    audio.srcObject = cueDest.stream;
    audio.play(); // Must happen after user interaction
    cueAudioElementRef.current = audio;

    // Pre-load synthetic samples
    const newSamples = samplesRef.current.map(s => ({
        ...s,
        buffer: createSyntheticBuffer(ctx, (s as any).type || 'kick')
    }));
    samplesRef.current = newSamples;
    setSamples(newSamples);
    
    scanAudioDevices();

    const createDeck = (): AudioDeck => {
      const trim = ctx.createGain(); trim.gain.value = 1.0; 
      const gain = ctx.createGain();
      const cueGain = ctx.createGain(); cueGain.gain.value = 0; // Default off
      
      const low = ctx.createBiquadFilter(); low.type = 'lowshelf'; low.frequency.value = 250; 
      const mid = ctx.createBiquadFilter(); mid.type = 'peaking'; mid.frequency.value = 1000; mid.Q.value = 1.0;
      const high = ctx.createBiquadFilter(); high.type = 'highshelf'; high.frequency.value = 2500;

      const sweepLow = ctx.createBiquadFilter(); sweepLow.type = 'lowpass'; sweepLow.frequency.value = 22000;
      const sweepHigh = ctx.createBiquadFilter(); sweepHigh.type = 'highpass'; sweepHigh.frequency.value = 10;
      
      const fx = ctx.createGain(); // Simplified FX chain insert point

      const analyser = ctx.createAnalyser(); analyser.fftSize = 64; 

      // Path: Source -> Trim -> EQs -> Sweeps -> FX -> [Main Gain & Cue Gain]
      trim.connect(low); low.connect(mid); mid.connect(high); 
      high.connect(sweepHigh); sweepHigh.connect(sweepLow); 
      sweepLow.connect(fx);
      
      // Split path
      fx.connect(gain); 
      fx.connect(cueGain); // PFL (Pre Fader Listen) usually comes here or pre-fx. Post-fx/Pre-fader is common.
      
      gain.connect(analyser); analyser.connect(master);
      cueGain.connect(cueBus); // Connect to Cue Bus

      return {
        source: null, trimNode: trim, gainNode: gain, cueGainNode: cueGain,
        lowFilter: low, midFilter: mid, highFilter: high,
        sweepLowPass: sweepLow, sweepHighPass: sweepHigh, fxNode: fx,
        analyser: analyser,
        startTime: 0, pauseTime: 0, isPlaying: false, buffer: null, isCueActive: false,
        isScratching: false, isNudging: false, playbackRateVal: 1.0,
        hotCues: [0,0,0,0], activeLoop: null,
        activeFx: 'none'
      };
    };

    deckARef.current = createDeck();
    deckBRef.current = createDeck();
    setIsReady(true);
  }, [scanAudioDevices]);

  const loadTrack = async (deck: 'A' | 'B', file: File, coverArt?: string): Promise<Track | null> => {
    if (!audioContextRef.current) initAudio();
    const ctx = audioContextRef.current!;
    if (file.size === 0) return null;

    try {
      const arrayBuffer = await file.arrayBuffer();
      const audioBuffer = await ctx.decodeAudioData(arrayBuffer);
      const deckRef = deck === 'A' ? deckARef.current : deckBRef.current;
      if (deckRef) {
          if (deckRef.source) deckRef.source.stop();
          deckRef.source = null;
          deckRef.buffer = audioBuffer;
          deckRef.pauseTime = 0;
          deckRef.startTime = 0;
          deckRef.isPlaying = false;
      }

      const { bpm, signature } = detectBPM(audioBuffer);

      return {
          id: crypto.randomUUID(),
          name: file.name,
          url: URL.createObjectURL(file),
          buffer: audioBuffer,
          duration: audioBuffer.duration,
          bpm: bpm,
          timeSignature: signature,
          waveform: extractPeaks(audioBuffer, Math.floor(audioBuffer.length / 400)),
          coverArt: coverArt
      };
    } catch (e) { return null; }
  };
  
  const loadTrackFromBuffer = (deck: 'A' | 'B', buffer: AudioBuffer, name: string, coverArt?: string): Track => {
     if (!audioContextRef.current) initAudio();
     const deckRef = deck === 'A' ? deckARef.current : deckBRef.current;
     if (deckRef) {
         if (deckRef.source) deckRef.source.stop();
         deckRef.source = null;
         deckRef.buffer = buffer;
         deckRef.pauseTime = 0;
         deckRef.startTime = 0;
         deckRef.isPlaying = false;
     }

     const { bpm, signature } = detectBPM(buffer);

     return {
         id: crypto.randomUUID(),
         name: name,
         url: '',
         buffer: buffer,
         duration: buffer.duration,
         bpm: bpm,
         timeSignature: signature,
         waveform: extractPeaks(buffer, Math.floor(buffer.length / 400)),
         coverArt: coverArt
     };
  };

  const playPause = (deck: 'A' | 'B') => {
    const ctx = audioContextRef.current;
    const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
    if (!ctx || !deckObj || !deckObj.buffer) return;
    if (ctx.state === 'suspended') ctx.resume();

    if (deckObj.isPlaying) {
      if (deckObj.source) {
        try { deckObj.source.stop(); deckObj.source.disconnect(); } catch(e) {}
        deckObj.source = null;
      }
      deckObj.pauseTime += (ctx.currentTime - deckObj.startTime) * deckObj.playbackRateVal;
      deckObj.pauseTime = deckObj.pauseTime % deckObj.buffer.duration;
      deckObj.isPlaying = false;
    } else {
      startSource(deckObj, ctx);
    }
  };

  const startSource = (deckObj: AudioDeck, ctx: AudioContext) => {
      if (!deckObj.buffer) return;

      const source = ctx.createBufferSource();
      source.buffer = deckObj.buffer;
      source.playbackRate.value = deckObj.playbackRateVal;
      source.connect(deckObj.trimNode); // Connect to processing chain

      let offset = deckObj.pauseTime;
      if (offset < 0) offset = 0;
      offset = offset % deckObj.buffer.duration;

      if (deckObj.activeLoop) {
          source.loop = true;
          source.loopStart = deckObj.activeLoop.start;
          source.loopEnd = deckObj.activeLoop.start + deckObj.activeLoop.length;
      }

      source.onended = () => { 
          if(deckObj.isPlaying && !deckObj.isScratching) {
            deckObj.isPlaying = false; 
            deckObj.source = null;
            deckObj.pauseTime = 0;
          }
      };
      
      try {
          source.start(0, offset);
          deckObj.source = source;
          deckObj.startTime = ctx.currentTime;
          deckObj.isPlaying = true;
      } catch(e) {
          console.error("Start Error", e);
      }
  };

  const touchPlatter = (deck: 'A' | 'B', type: 'vinyl' | 'ring', isTouched: boolean) => {
      const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
      const ctx = audioContextRef.current;
      if (!deckObj || !ctx) return;

      if (type === 'vinyl') {
          if (isTouched) {
              deckObj.isScratching = true;
              if (deckObj.isPlaying && deckObj.source) {
                  const elapsed = (ctx.currentTime - deckObj.startTime) * deckObj.source.playbackRate.value;
                  deckObj.pauseTime = (deckObj.pauseTime + elapsed) % (deckObj.buffer?.duration || 1);
                  deckObj.source.stop();
                  deckObj.source = null;
              }
          } else {
              deckObj.isScratching = false;
              if (deckObj.isPlaying) {
                  startSource(deckObj, ctx);
              }
          }
      } else {
          if (isTouched) {
              deckObj.isNudging = true;
          } else {
              deckObj.isNudging = false;
              if (deckObj.source) {
                  deckObj.source.playbackRate.setTargetAtTime(deckObj.playbackRateVal, ctx.currentTime, 0.1);
              }
          }
      }
  };

  const movePlatter = (deck: 'A' | 'B', deltaY: number) => {
      const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
      const ctx = audioContextRef.current;
      if (!deckObj || !ctx || !deckObj.buffer) return;

      if (deckObj.isScratching) {
          const sensitivity = 0.005; 
          deckObj.pauseTime -= deltaY * sensitivity;

          if (deckObj.pauseTime < 0) deckObj.pauseTime = 0;
          if (deckObj.pauseTime > deckObj.buffer.duration) deckObj.pauseTime = deckObj.buffer.duration;
          
          const p = deckObj.pauseTime / deckObj.buffer.duration;
          if (deck === 'A') setProgressA(p);
          else setProgressB(p);

      } else if (deckObj.isNudging && deckObj.source) {
          const bend = deltaY * -0.005; 
          const target = deckObj.playbackRateVal + bend;
          deckObj.source.playbackRate.setValueAtTime(target, ctx.currentTime);
      }
  };

  const setPlaybackRate = (deck: 'A' | 'B', rate: number) => {
    const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
    if (deckObj) {
        deckObj.playbackRateVal = rate;
        if (deckObj.source && audioContextRef.current && !deckObj.isScratching && !deckObj.isNudging) {
            deckObj.source.playbackRate.setTargetAtTime(rate, audioContextRef.current.currentTime, 0.05);
        }
    }
  };

  const seek = (deck: 'A' | 'B', percentage: number) => {
      const ctx = audioContextRef.current;
      const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
      if (!ctx || !deckObj || !deckObj.buffer) return;

      let targetTime = percentage * deckObj.buffer.duration;
      deckObj.pauseTime = targetTime;
      
      if (deckObj.isPlaying && !deckObj.isScratching) {
          if (deckObj.source) {
             try { deckObj.source.stop(); } catch(e){}
             deckObj.source = null;
          }
          startSource(deckObj, ctx);
      } else {
          if (deck === 'A') setProgressA(percentage);
          else setProgressB(percentage);
      }
  };

  const triggerHotCue = (deck: 'A' | 'B', index: number) => {
      const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
      const ctx = audioContextRef.current;
      if (!deckObj || !deckObj.buffer || !ctx) return;
      
      if (deckObj.hotCues[index] === 0 && index !== 0) { 
         const currentTime = deckObj.isPlaying 
            ? deckObj.pauseTime + (ctx.currentTime - deckObj.startTime) * deckObj.playbackRateVal 
            : deckObj.pauseTime;
         deckObj.hotCues[index] = currentTime % deckObj.buffer.duration;
      } else {
         const time = deckObj.hotCues[index];
         deckObj.pauseTime = time;
         if (deckObj.isPlaying) {
             if(deckObj.source) { try{deckObj.source.stop();}catch(e){} deckObj.source = null; }
             startSource(deckObj, ctx);
         } else {
             seek(deck, time / deckObj.buffer.duration);
             playPause(deck); 
         }
      }
  };
  
  const setHotCue = (deck: 'A' | 'B', index: number) => {
      const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
      const ctx = audioContextRef.current;
      if (!deckObj || !ctx) return;
      
      const currentTime = deckObj.isPlaying 
            ? deckObj.pauseTime + (ctx.currentTime - deckObj.startTime) * deckObj.playbackRateVal 
            : deckObj.pauseTime;
      deckObj.hotCues[index] = currentTime;
  };

  const toggleLoop = (deck: 'A' | 'B', beats: number, padIndex: number) => {
      const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
      const ctx = audioContextRef.current;
      if (!deckObj || !ctx || !deckObj.buffer) return;

      if (deckObj.activeLoop && deckObj.activeLoop.padIndex === padIndex) {
          deckObj.activeLoop = null;
          if (deckObj.source) deckObj.source.loop = false;
      } else {
          const beatTime = 60 / deckObj.buffer.duration * 4; 
          const actualBeatTime = 60 / 128;
          const duration = actualBeatTime * beats;
          
          let currentTime = deckObj.pauseTime;
          if (deckObj.isPlaying) {
              currentTime = deckObj.pauseTime + (ctx.currentTime - deckObj.startTime) * deckObj.playbackRateVal;
          }
          currentTime = currentTime % deckObj.buffer.duration;

          deckObj.activeLoop = { start: currentTime, length: duration, padIndex };
          
          if (deckObj.isPlaying && deckObj.source) {
             deckObj.source.loopStart = currentTime;
             deckObj.source.loopEnd = currentTime + duration;
             deckObj.source.loop = true;
          }
      }
  };

  // --- HARDWARE SPECIFIC ACTIONS (MIXTRACK SIMULATION) ---
  
  const resizeLoop = (deck: 'A' | 'B', factor: number) => {
      const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
      if (!deckObj || !deckObj.activeLoop || !deckObj.source) return;
      
      const newLength = deckObj.activeLoop.length * factor;
      deckObj.activeLoop.length = newLength;
      deckObj.source.loopEnd = deckObj.source.loopStart + newLength;
  };

  const toggleFx = (deck: 'A' | 'B', type: 'flanger' | 'echo' | 'reverb' | 'none') => {
      const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
      if (!deckObj) return;
      
      deckObj.activeFx = type === deckObj.activeFx ? 'none' : type;
      
      if (deckObj.activeFx === 'none') {
           deckObj.highFilter.gain.value = 0;
           deckObj.midFilter.gain.value = 0;
      } else if (deckObj.activeFx === 'flanger') {
           deckObj.midFilter.frequency.value = 500;
           deckObj.midFilter.gain.value = -10;
      } else if (deckObj.activeFx === 'echo') {
           deckObj.midFilter.frequency.value = 2000;
           deckObj.midFilter.gain.value = 5;
      } else if (deckObj.activeFx === 'reverb') {
           deckObj.highFilter.frequency.value = 8000;
           deckObj.highFilter.gain.value = 3;
      }
  };

  const setVolume = (deck: 'A' | 'B', value: number) => {
    const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
    if (deckObj && audioContextRef.current) deckObj.gainNode.gain.setTargetAtTime(value, audioContextRef.current.currentTime, 0.02);
  };
  const setGain = (deck: 'A' | 'B', value: number) => {
    const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
    if (deckObj && audioContextRef.current) deckObj.trimNode.gain.setTargetAtTime(value * 2, audioContextRef.current.currentTime, 0.05);
  };
  const setFilter = (deck: 'A' | 'B', type: 'low' | 'mid' | 'high' | 'sweep', value: number) => {
      const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
      if (!deckObj || !audioContextRef.current) return;
      const t = audioContextRef.current.currentTime;
      if (type === 'low') deckObj.lowFilter.gain.setTargetAtTime(value, t, 0.015);
      if (type === 'mid') deckObj.midFilter.gain.setTargetAtTime(value, t, 0.015);
      if (type === 'high') deckObj.highFilter.gain.setTargetAtTime(value, t, 0.015);
      if (type === 'sweep') {
          const normVal = value; 
          if (normVal < 0.45) {
              const freq = Math.max(20, Math.pow(normVal * 2.2, 2) * 20000);
              deckObj.sweepLowPass.frequency.setTargetAtTime(freq, t, 0.015);
              deckObj.sweepHighPass.frequency.setTargetAtTime(10, t, 0.015); 
          } else if (normVal > 0.55) {
              const freq = Math.max(20, Math.pow((normVal - 0.55) * 2.2, 2) * 10000);
              deckObj.sweepHighPass.frequency.setTargetAtTime(freq, t, 0.015);
              deckObj.sweepLowPass.frequency.setTargetAtTime(22000, t, 0.015); 
          } else {
              deckObj.sweepLowPass.frequency.setTargetAtTime(22000, t, 0.1);
              deckObj.sweepHighPass.frequency.setTargetAtTime(10, t, 0.1);
          }
      }
  };
  
  const toggleFaderCut = (deck: 'A' | 'B', padIndex: number, active: boolean) => {
      const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
      const ctx = audioContextRef.current;
      if (!deckObj || !ctx) return;
      if (active) deckObj.gainNode.gain.value = 0;
      else deckObj.gainNode.gain.setTargetAtTime(1, ctx.currentTime, 0.01);
  };
  
  const toggleCue = (deck: 'A' | 'B') => {
      const deckObj = deck === 'A' ? deckARef.current : deckBRef.current;
      const ctx = audioContextRef.current;
      if (!deckObj || !ctx) return;
      deckObj.isCueActive = !deckObj.isCueActive;
      // Route audio to cue bus if active
      deckObj.cueGainNode.gain.setTargetAtTime(deckObj.isCueActive ? 1 : 0, ctx.currentTime, 0.05);
  }
  
  const toggleScratchMode = (deck: 'A' | 'B') => { return true; }

  // Misc
  const renderAudioFromMelody = async (melody: AiMelody): Promise<AudioBuffer | null> => { return null; };
  const playAlgoraveSound = useCallback((instrument: string, note?: string) => {}, []);
  const loadSample = async (id: number, file: File) => {
     if (!audioContextRef.current) initAudio();
     const ctx = audioContextRef.current!;
     try {
       const arrayBuffer = await file.arrayBuffer();
       const audioBuffer = await ctx.decodeAudioData(arrayBuffer);
       const newSamples = [...samplesRef.current];
       newSamples[id] = { ...newSamples[id], buffer: audioBuffer, name: file.name.substring(0, 8) };
       samplesRef.current = newSamples;
       setSamples(newSamples);
     } catch(e) {}
  };
  const triggerSample = (id: number) => {
      const sample = samplesRef.current[id];
      if (!audioContextRef.current || !sample.buffer) return;
      const ctx = audioContextRef.current;
      const source = ctx.createBufferSource();
      source.buffer = sample.buffer;
      const gain = ctx.createGain();
      gain.gain.value = 0.8;
      source.connect(masterGainRef.current!);
      source.start(0);
      setSamples(prev => prev.map((s, i) => i === id ? { ...s, isTriggered: true } : s));
      setTimeout(() => { setSamples(prev => prev.map((s, i) => i === id ? { ...s, isTriggered: false } : s)); }, 150);
  };

  useEffect(() => {
    let animationFrame: number;
    const update = () => {
      const ctx = audioContextRef.current;
      
      const updateDeck = (deckObj: AudioDeck | null, setProgress: (n: number) => void, setWave: (d: Uint8Array) => void) => {
          if (deckObj && ctx) {
              const data = new Uint8Array(deckObj.analyser.frequencyBinCount);
              deckObj.analyser.getByteFrequencyData(data);
              setWave(data);
              
              if (deckObj.isPlaying && !deckObj.isScratching) {
                  const elapsed = (ctx.currentTime - deckObj.startTime) * deckObj.playbackRateVal;
                  const currentPos = (deckObj.pauseTime + elapsed) % (deckObj.buffer?.duration || 1);
                  setProgress(currentPos / (deckObj.buffer?.duration || 1));
              } 
          }
      };

      updateDeck(deckARef.current, setProgressA, setWaveformDataA);
      updateDeck(deckBRef.current, setProgressB, setWaveformDataB);
      
      animationFrame = requestAnimationFrame(update);
    };
    if (isReady) update();
    return () => cancelAnimationFrame(animationFrame);
  }, [isReady]);

  return {
    initAudio, loadTrack, loadTrackFromBuffer, renderAudioFromMelody, playPause, 
    setVolume, setGain, setFilter, setPlaybackRate, 
    touchPlatter, movePlatter,
    playAlgoraveSound, loadSample, triggerSample, samples, seek,
    waveformDataA, waveformDataB, progressA, progressB,
    setHotCue, triggerHotCue, toggleLoop, toggleFaderCut, toggleScratchMode, toggleCue,
    // EXPOSED FOR HARDWARE MAPPING
    resizeLoop, toggleFx,
    // SETTINGS & OUTPUT
    availableDevices, setCueOutputDevice, selectedCueDeviceId
  };
};
