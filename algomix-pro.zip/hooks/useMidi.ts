
import { useEffect, useState, useCallback, useRef } from 'react';

export interface MidiInput {
  id: string;
  name: string;
  manufacturer: string;
}

export const useMidi = (
  onMidiMessage: (msg: { command: number, note: number, velocity: number }) => void
) => {
  const [inputs, setInputs] = useState<MidiInput[]>([]);
  const [midiAccess, setMidiAccess] = useState<any>(null);
  
  // Use a ref to keep track of the latest callback without changing the handleMessage identity
  const onMidiMessageRef = useRef(onMidiMessage);

  useEffect(() => {
    onMidiMessageRef.current = onMidiMessage;
  }, [onMidiMessage]);

  const handleMessage = useCallback((event: any) => {
    const command = event.data[0];
    const note = event.data[1];
    const velocity = event.data[2];

    // Filter active sensing
    if (command >= 248) return;

    // Call the ref to ensure we use the latest closure (with updated isMappingMode state)
    if (onMidiMessageRef.current) {
        onMidiMessageRef.current({ command, note, velocity });
    }
  }, []);

  const refreshInputs = useCallback((access: any) => {
      const inputsList: MidiInput[] = [];
      for (let input of access.inputs.values()) {
          inputsList.push({
              id: input.id,
              name: input.name,
              manufacturer: input.manufacturer
          });
      }
      setInputs(inputsList);
  }, []);

  useEffect(() => {
    if (navigator.requestMIDIAccess) {
      navigator.requestMIDIAccess().then((access) => {
        setMidiAccess(access);
        refreshInputs(access);

        access.onstatechange = () => {
            refreshInputs(access);
        };
      }, () => {
          console.error("WebMIDI Rejected");
      });
    }
  }, [refreshInputs]);

  const connectInput = useCallback((id: string) => {
      if (!midiAccess) return;
      
      // D'abord, déconnecter les anciens listeners pour éviter les doublons
      for (let input of midiAccess.inputs.values()) {
          input.onmidimessage = null;
      }

      // Connecter le nouveau
      const input = midiAccess.inputs.get(id);
      if (input) {
          console.log(`Connecté à: ${input.name}`);
          input.onmidimessage = handleMessage;
      }
  }, [midiAccess, handleMessage]);

  return { inputs, connectInput };
};
