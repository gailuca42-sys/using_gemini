
import { GoogleGenAI, Type } from "@google/genai";
import { AlgoravePattern, AiMelody, AnalysisResult } from '../types';

const getAiClient = () => {
  if (!process.env.API_KEY) {
    console.error("API_KEY is missing");
    return null;
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

const PRO_MODEL = "gemini-3-pro-preview";

export const generateAlgoravePattern = async (prompt: string, currentBpm: number): Promise<AlgoravePattern | null> => {
  const ai = getAiClient();
  if (!ai) return null;

  try {
    const response = await ai.models.generateContent({
      model: PRO_MODEL,
      contents: `Generate a groovy musical pattern for a live coding DJ set. 
      The user request is: "${prompt}".
      The current BPM is ${currentBpm}.
      Return a JSON object that defines the pattern.
      Instruments available: 'kick', 'snare', 'hihat', 'bass', 'synth'.
      For 'pattern', use an array of 16 numbers (0 or 1 for drums, or frequency values/midi notes for synth, but stick to 0/1 for simplicity in this MVP unless specified).
      For 'bass' and 'synth', you can add a 'note' field (e.g., 'C2').
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            bpm: { type: Type.NUMBER },
            steps: { type: Type.NUMBER },
            tracks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  instrument: { type: Type.STRING, enum: ['kick', 'snare', 'hihat', 'bass', 'synth'] },
                  pattern: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                  note: { type: Type.STRING }
                }
              }
            }
          }
        }
      }
    });

    if (response.text) {
        return JSON.parse(response.text) as AlgoravePattern;
    }
    return null;

  } catch (error) {
    console.error("Gemini Generation Error:", error);
    return null;
  }
};

export const generateMelodyTrack = async (prompt: string, context: string, durationSeconds: number = 15): Promise<AiMelody | null> => {
  const ai = getAiClient();
  if (!ai) return null;

  try {
    const response = await ai.models.generateContent({
      model: PRO_MODEL,
      contents: `You are a Pro Music Producer AI (Suno Engine Simulator).
      Context: The user is playing a DJ set. ${context}
      Task: Compose a rich, full-sounding track (Bassline + Chords + Melody).
      User Request: "${prompt}"
      Target Duration: ${durationSeconds} seconds.
      
      Generate a JSON object representing the music.
      Crucial: I need MULTIPLE layers. Use the 'type' field to specify 'bass', 'chord', or 'lead'.
      Ensure notes cover the entire requested duration.
      `,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                name: { type: Type.STRING },
                bpm: { type: Type.NUMBER },
                durationSeconds: { type: Type.NUMBER },
                notes: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            note: { type: Type.STRING, description: "Note name e.g. C4, F#3" },
                            startTime: { type: Type.NUMBER, description: "Start time in seconds" },
                            duration: { type: Type.NUMBER, description: "Duration in seconds" },
                            velocity: { type: Type.NUMBER },
                            type: { type: Type.STRING, enum: ['bass', 'chord', 'lead'], description: "Type of instrument layer" }
                        }
                    }
                }
            }
        }
      }
    });

    if (response.text) {
        return JSON.parse(response.text) as AiMelody;
    }
    return null;
  } catch (error) {
    console.error("Gemini Melody Error:", error);
    return null;
  }
};

export const generateSunoMetadata = async (prompt: string): Promise<{title: string, style: string, colors: string[]} | null> => {
    const ai = getAiClient();
    if (!ai) return null;

    try {
        const response = await ai.models.generateContent({
            model: PRO_MODEL,
            contents: `Generate metadata for a fictional song based on this prompt: "${prompt}".
            Return JSON: { title: string, style: string, colors: [hex1, hex2] }
            Title should be catchy. Style should be genre tags (e.g. "Lo-fi, Jazz, Chill").
            Colors should match the mood (for album art).`,
            config: {
                responseMimeType: "application/json"
            }
        });
        if (response.text) return JSON.parse(response.text);
        return null;
    } catch(e) { return null; }
}

export const analyzeAppInterface = async (domSnapshot: string, appState: string, languageContext?: string): Promise<AnalysisResult | null> => {
    const ai = getAiClient();
    if (!ai) return null;
    
    const langInstruction = languageContext 
        ? `IMPORTANT: TU DOIS RÉPONDRE DANS LA LANGUE ET LA CULTURE SUIVANTE : "${languageContext}". Utilise le jargon DJ approprié à cette culture.` 
        : "Réponds en Français standard.";

    try {
        const response = await ai.models.generateContent({
            model: PRO_MODEL,
            contents: `TU ES UN EXPERT EN UX/UI ET QA ENGINEER SENIOR.
            ${langInstruction}

            Ton but : Analyser l'état actuel de l'application DJ "AlgoMix Pro" et proposer des améliorations concrètes.
            
            Voici le contexte actuel de l'application :
            ${appState}

            Voici un snapshot simplifié de la structure DOM actuelle (HTML) :
            ${domSnapshot}

            TA MISSION :
            1. Analyser l'ergonomie (Placement des boutons, tailles, contrastes).
            2. Identifier les incohérences visuelles ou bugs potentiels (ex: un bouton Play actif alors que le statut est Pause).
            3. Proposer 3 améliorations Design "Luxe".
            4. Proposer 3 améliorations UX (Expérience Utilisateur).
            5. Rédiger un "ACTION PROMPT" optimisé que l'utilisateur pourra copier-coller pour demander à un développeur (ou à toi-même dans une prochaine session) d'appliquer ces changements.

            Format de réponse JSON STRICT :
            {
                "designSuggestions": ["string", "string", "string"],
                "uxImprovements": ["string", "string", "string"],
                "potentialBugs": ["string", ...],
                "actionPrompt": "string (Le prompt complet, clair et direct)"
            }`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        designSuggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
                        uxImprovements: { type: Type.ARRAY, items: { type: Type.STRING } },
                        potentialBugs: { type: Type.ARRAY, items: { type: Type.STRING } },
                        actionPrompt: { type: Type.STRING }
                    }
                }
            }
        });

        if (response.text) {
            return JSON.parse(response.text) as AnalysisResult;
        }
        return null;
    } catch (e) {
        console.error("Analysis Error", e);
        return {
            designSuggestions: ["Erreur d'analyse."],
            uxImprovements: ["Vérifiez la connexion."],
            potentialBugs: [],
            actionPrompt: "Impossible de générer le prompt."
        };
    }
};

export const generateAssistantResponse = async (userQuery: string, appContext: string, languageContext?: string): Promise<string> => {
  const ai = getAiClient();
  if (!ai) return JSON.stringify({ response: "Erreur connexion API.", actions: [] });

  const langInstruction = languageContext 
        ? `IMPORTANT: TU DOIS RÉPONDRE DANS LA LANGUE ET LA CULTURE SUIVANTE : "${languageContext}". Adopte la persona d'un DJ tech de cette région.` 
        : "Réponds en Français standard.";

  try {
    const response = await ai.models.generateContent({
      model: PRO_MODEL,
      contents: `TU ES UN SYSTÈME DOUBLE-AGENT : "COPILOT" (Interaction) + "SYSTEM CORE" (Technique).
      ${langInstruction}

      === MISSION ===
      Tu dois satisfaire l'utilisateur à 100%. Tu as le contrôle TOTAL sur l'app.
      
      === AGENT 1 : SYSTEM CORE (ROOT UI & DOM HACKER) ===
      Si l'utilisateur veut changer l'apparence (couleur, thème, style) :
      1. Privilégie l'action 'SET_UI_STYLE' avec le paramètre 'hue' (0-360) pour générer automatiquement un thème compatible LIGHT & DARK.
         Exemple JSON: { "type": "SET_UI_STYLE", "text": "{\"hue\": 220}" }
      2. Si demande structurelle, utilise des sélecteurs CSS bruts.

      === NOUVEAU: DOM HACKER CAPABILITIES ===
      Tu peux modifier le texte et le contenu HTML de l'app en temps réel.
      Utilise l'action 'SET_DOM_CONTENT' avec un JSON { "selector": "...", "content": "..." }.
      
      Sélecteurs Cibles :
      - Titre App : #app-logo
      - Titre Deck A : #deck-A-title
      - Titre Deck B : #deck-B-title
      - Landing Page Hero : #landing-title
      - Landing Page Sous-titre : #landing-subtitle
      
      Exemple: Pour renommer l'app "DJ SNAKE", renvoie l'action:
      { "type": "SET_DOM_CONTENT", "text": "{\"selector\": \"#app-logo\", \"content\": \"DJ SNAKE <span class='text-xs'>LIVE</span>\"}" }
      
      === AGENT 2 : DJ AUTONOME PROACTIF ===
      Si demande musicale (ex: "Mets du Lofi", "Mixe un truc") :
      1. ANALYSE la liste des fichiers dans le contexte [BIBLIOTHÈQUE LOCALE].
      2. CHERCHE des correspondances floues.
      3. PRENDS L'INITIATIVE.
      4. GÉNÈRE UNE SÉQUENCE : LOAD_TRACK_A -> WAIT -> SYNC -> PLAY.
      
      === ACTIONS DISPONIBLES ===
      - SET_UI_STYLE (text = JSON { "hue": number } OU CSS brut)
      - SET_DOM_CONTENT (text = JSON { "selector": string, "content": string })
      - LOAD_TRACK_A / B, PLAY_A / B, STOP_A / B, SYNC_A / B
      - VOL_A / B, CROSSFADER, PITCH_A / B, GAIN_A / B
      - EQ_HIGH/MID/LOW_A / B, FILTER_A / B
      - WAIT (value = ms)
      - MAESTRO_TYPE
      - SET_THEME_MODE
      
      === CONTEXTE ACTUEL ===
      ${appContext}

      REQUÊTE : "${userQuery}"
      
      RÉPONSE JSON STRICT :
      { "response": "...", "actions": [ ... ] }`,
      config: {
          responseMimeType: "application/json"
      }
    });

    return response.text || "{}";
  } catch (error) {
    console.error("Gemini Assistant Error:", error);
    return JSON.stringify({ response: "Erreur API Gemini.", actions: [] });
  }
};
