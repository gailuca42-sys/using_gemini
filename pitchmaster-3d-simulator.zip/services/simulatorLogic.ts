
// Fix: Use Google GenAI SDK guidelines for content generation and JSON responses.
import { GoogleGenAI, Type } from "@google/genai";
import { 
  SimulationConfig, 
  Persona, 
  AttendeeState, 
  SimulationStats,
  DataPoint
} from '../types';
import { FRENCH_NAMES, ARCHETYPES } from '../constants';

const cleanAIResponse = (text: string) => {
  const jsonStart = text.indexOf('{');
  const jsonEnd = text.lastIndexOf('}');
  if (jsonStart !== -1 && jsonEnd !== -1) {
    return text.substring(jsonStart, jsonEnd + 1);
  }
  return text;
};

const clamp = (val: number) => Math.min(100, Math.max(0, val));

export const analyzePitchTimeline = async (config: SimulationConfig): Promise<SimulationStats> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const customMetricsPrompt = config.customMetrics.length > 0 
    ? `Analyse aussi ces métriques spécifiques pour chaque segment (dans customScores) et globalement (dans overallCustomMetrics) : ${config.customMetrics.join(', ')}.`
    : "";

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Tu es un simulateur d'audience expert de haut vol. Analyse ce pitch segment par segment pour un contexte spécifique.
    
    CONTEXTE : "${config.context}"
    TYPE D'AUDIENCE : "${config.type}" (Âge moyen: ${config.avgAge} ans, Bienveillance de départ: ${config.kindness}/100).
    PITCH COMPLET : "${config.pitch}"
    
    ${customMetricsPrompt}

    INSTRUCTIONS CRUCIALES POUR LE CHAMP "analysis" :
    Le champ "analysis" pour chaque segment doit être une observation ULTRA-SPÉCIFIQUE et CONCRÈTE sur ce qui vient d'être dit (ex: "le chiffre de 2M€ cité", "l'analogie sur le marathon", "le ton hésitant sur la partie technique", "l'absence de chiffres sur le ROI"). 
    ÉVITE ABSOLUMENT les termes génériques comme "ce passage", "l'argumentation" ou "la présentation". Cite des éléments du texte si possible.

    Découpe le pitch en 10 segments chronologiques.
    Pour CHAQUE segment, évalue l'attention, l'intérêt et la compréhension.
    Les scores doivent refléter RÉELLEMENT la qualité intrinseque du texte fourni par rapport à l'audience cible.
    
    Retourne un JSON correspondant au schéma fourni.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          timeline: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                attention: { type: Type.NUMBER },
                interest: { type: Type.NUMBER },
                comprehension: { type: Type.NUMBER },
                analysis: { type: Type.STRING, description: "Observation précise et unique sur le contenu de ce segment précis." },
                ...(config.customMetrics.length > 0 ? {
                  customScores: {
                    type: Type.OBJECT,
                    description: "Scores for custom metrics provided in the config",
                    properties: config.customMetrics.reduce((acc, m) => {
                      acc[m] = { type: Type.NUMBER };
                      return acc;
                    }, {} as any),
                    required: config.customMetrics
                  }
                } : {})
              },
              required: ["attention", "interest", "comprehension", "analysis", ...(config.customMetrics.length > 0 ? ["customScores"] : [])]
            }
          },
          overallCustomMetrics: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                label: { type: Type.STRING },
                value: { type: Type.NUMBER }
              },
              required: ["id", "label", "value"]
            }
          }
        },
        required: ["timeline", "overallCustomMetrics"]
      }
    }
  });

  try {
    const cleaned = cleanAIResponse(response.text || "");
    const rawData = JSON.parse(cleaned) as SimulationStats;
    
    return {
      timeline: (rawData.timeline || []).map(pt => ({
        ...pt,
        attention: clamp(pt.attention),
        interest: clamp(pt.interest),
        comprehension: clamp(pt.comprehension),
        customScores: pt.customScores || {}
      })),
      overallCustomMetrics: (rawData.overallCustomMetrics || []).map(m => ({ ...m, value: clamp(m.value) }))
    };
  } catch (e) {
    console.error("Analysis failed", e);
    return { 
      timeline: Array(10).fill(0).map((_, i) => ({ 
        attention: clamp(50 + Math.sin(i) * 20), 
        interest: clamp(40 + i * 5), 
        comprehension: 70, 
        analysis: "une partie du discours",
        customScores: {} 
      })), 
      overallCustomMetrics: [] 
    };
  }
};

export const generateDynamicPersonas = (config: SimulationConfig, stats: SimulationStats): Persona[] => {
  const personas: Persona[] = [];
  const radiusStep = 3.5;
  const archetypeKeys = Object.keys(ARCHETYPES);
  
  for (let i = 0; i < config.size; i++) {
    const ring = Math.floor(i / 15);
    const posInRing = i % 15;
    const angle = (posInRing / 15) * Math.PI - Math.PI/2;
    const r = 10 + ring * radiusStep;
    
    // Attribution semi-aléatoire des archétypes
    const archetype = archetypeKeys[Math.floor(Math.random() * archetypeKeys.length)];
    
    personas.push({
      id: i,
      name: FRENCH_NAMES[i % FRENCH_NAMES.length],
      age: Math.floor(config.avgAge - 10 + Math.random() * 20),
      job: "Auditeur",
      archetype: archetype,
      traits: ["Analytique", "Sceptique", "Enthousiaste", "Curieux", "Rationnel", "Émotif"].sort(() => 0.5 - Math.random()).slice(0, 2),
      emotion: "Neutre",
      state: AttendeeState.ATTENTIVE,
      thought: "Prêt pour le début...",
      reactionOffset: Math.random() * 0.2, // Décalage individuel accru
      modifiers: {
        attention: (Math.random() * 25 - 12) + (config.kindness / 12),
        interest: (Math.random() * 25 - 12),
        comprehension: (Math.random() * 25 - 12)
      },
      position: [Math.cos(angle) * r, ring * 0.4, Math.sin(angle) * r]
    });
  }
  return personas;
};

export const getPersonaStateAtTime = (persona: Persona, timeline: DataPoint[], progress: number): { state: AttendeeState, emotion: string, thought: string } => {
  if (progress <= 0 || timeline.length === 0) {
    return { state: AttendeeState.ATTENTIVE, emotion: "Neutre", thought: "En attente du début..." };
  }

  const delayedProgress = Math.max(0, progress - persona.reactionOffset);
  const index = Math.min(timeline.length - 1, Math.floor(delayedProgress * timeline.length));
  const point = timeline[index];
  
  const arch = ARCHETYPES[persona.archetype] || ARCHETYPES["L'Analyste"];
  const weights = arch.focusWeight;

  // Calcul d'un score pondéré par la personnalité
  const weightedAttention = (point.attention + persona.modifiers.attention) * weights.attention;
  const weightedInterest = (point.interest + persona.modifiers.interest) * weights.interest;
  const weightedComprehension = (point.comprehension + persona.modifiers.comprehension) * weights.comprehension;
  
  const averageScore = (weightedAttention + weightedInterest + weightedComprehension) / 3;
  const finalScore = clamp(averageScore - arch.baseThreshold);
  
  let state = AttendeeState.ATTENTIVE;
  let emotionPrefix = "Intéressé";
  let emoji = "🤔";
  
  if (finalScore > 78) {
    state = AttendeeState.VERY_ATTENTIVE;
    emotionPrefix = "Captivé";
    emoji = "😍";
  } else if (finalScore < 20) {
    state = AttendeeState.DROPPED_OUT;
    emotionPrefix = "Perdu";
    emoji = "😵‍";
  } else if (finalScore < 45) {
    state = AttendeeState.DISTRACTED;
    emotionPrefix = "Distrait";
    emoji = "🥱";
  }

  const reactionPool = arch.reactions[state] || arch.reactions[AttendeeState.ATTENTIVE];
  const reactionBase = reactionPool[persona.id % reactionPool.length];
  
  // Utilisation de l'observation ultra-spécifique de l'IA
  const aiAnalysis = point.analysis || "ce passage";
  const thought = reactionBase.replace("{analysis}", aiAnalysis.trim().toLowerCase());

  return { state, emotion: `${emotionPrefix} ${emoji}`, thought };
};
