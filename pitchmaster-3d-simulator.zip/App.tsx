
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { SimulationConfig, Persona, SimulationStats, AttendeeState } from './types';
import { analyzePitchTimeline, generateDynamicPersonas, getPersonaStateAtTime } from './services/simulatorLogic';
import SimulationScene from './components/SimulationScene';
import ConfigScreen from './components/ConfigScreen';
import PersonaDetails from './components/PersonaDetails';

const App: React.FC = () => {
  const [config, setConfig] = useState<SimulationConfig | null>(null);
  const [stats, setStats] = useState<SimulationStats | null>(null);
  const [personas, setPersonas] = useState<Persona[]>([]);
  const [selectedPersona, setSelectedPersona] = useState<Persona | null>(null);
  const [showConfig, setShowConfig] = useState(true);
  const [loading, setLoading] = useState(false);

  const [elapsedTime, setElapsedTime] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const timerRef = useRef<number | null>(null);

  const words = useMemo(() => config?.pitch.split(/\s+/) || [], [config?.pitch]);
  const estimatedDuration = useMemo(() => Math.max(1, (words.length / 130) * 60), [words.length]);
  const progressRatio = useMemo(() => Math.min(1, elapsedTime / estimatedDuration), [elapsedTime, estimatedDuration]);
  
  // Utilisation d'un state local pour les personas dynamiques pour forcer le rafraîchissement visuel
  const [currentPersonas, setCurrentPersonas] = useState<Persona[]>([]);

  // Mise à jour synchrone des émotions et pensées quand le temps avance
  useEffect(() => {
    if (!stats || personas.length === 0) return;
    
    // On met à jour les personas directement lors du changement de progressRatio
    // pour éviter les problèmes d'intervalle qui se nettoie trop vite
    setCurrentPersonas(personas.map(p => {
      const { state, emotion, thought } = getPersonaStateAtTime(p, stats.timeline, progressRatio);
      return { ...p, state, emotion, thought };
    }));
  }, [progressRatio, stats, personas]);

  const currentWordIndex = Math.min(words.length - 1, Math.floor(progressRatio * words.length));

  const handleStartSimulation = async (newConfig: SimulationConfig) => {
    setLoading(true);
    try {
      const analysis = await analyzePitchTimeline(newConfig);
      const initialPersonas = generateDynamicPersonas(newConfig, analysis);
      setStats(analysis);
      setPersonas(initialPersonas);
      setCurrentPersonas(initialPersonas);
      setConfig(newConfig);
      setShowConfig(false);
      setElapsedTime(0);
      setIsPaused(false);
    } catch (e) {
      console.error(e);
      alert("L'analyse a échoué. Vérifiez votre connexion.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!showConfig && !isPaused && elapsedTime < estimatedDuration) {
      timerRef.current = window.setInterval(() => setElapsedTime(prev => prev + 0.1), 100);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [showConfig, isPaused, elapsedTime, estimatedDuration]);

  return (
    <div className="relative w-full h-full text-white bg-slate-950 overflow-hidden font-sans">
      {loading && (
        <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-slate-950/90 backdrop-blur-xl">
          <div className="w-16 h-16 border-t-2 border-indigo-500 rounded-full animate-spin mb-6"></div>
          <h2 className="text-2xl font-bold text-indigo-400 font-serif">Génération des réactions...</h2>
          <p className="text-slate-500 text-sm mt-2 animate-pulse">Gemini analyse la pertinence de chaque mot pour votre audience.</p>
        </div>
      )}

      {!showConfig && config && (
        <SimulationScene 
          personas={currentPersonas} 
          onSelectPersona={(p) => setSelectedPersona(p)} 
        />
      )}

      {showConfig && <ConfigScreen onStart={handleStartSimulation} initialConfig={config || undefined} />}

      {stats && !showConfig && (
        <>
          <div className="fixed top-0 left-0 right-0 z-20 h-28 glass border-b border-white/5 p-4 flex flex-col overflow-hidden">
             <div className="flex justify-between items-center mb-2 px-2 shrink-0">
                <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Analyse de l'Impact IA</span>
                <div className="flex gap-4 text-[8px] font-bold">
                  <span className="text-emerald-400 flex items-center gap-1"><div className="w-1.5 h-1.5 rounded-full bg-emerald-400"></div> ATTENTION</span>
                  <span className="text-yellow-400 flex items-center gap-1"><div className="w-1.5 h-1.5 rounded-full bg-yellow-400"></div> INTÉRÊT</span>
                  <span className="text-sky-400 flex items-center gap-1"><div className="w-1.5 h-1.5 rounded-full bg-sky-400"></div> COMPRÉHENSION</span>
                </div>
             </div>
             
             <div className="flex-1 relative cursor-crosshair overflow-hidden rounded-lg bg-black/20" onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const x = e.clientX - rect.left;
                setElapsedTime((x / rect.width) * estimatedDuration);
             }}>
                <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full">
                  {['attention', 'interest', 'comprehension'].map((key, i) => (
                    <polyline
                      key={key}
                      fill="none"
                      stroke={['#34d399', '#facc15', '#38bdf8'][i]}
                      strokeWidth="2"
                      strokeLinejoin="round"
                      points={stats.timeline.map((p, idx) => 
                        `${(idx / (stats.timeline.length - 1)) * 100},${100 - Math.min(100, Math.max(0, (p as any)[key]))}`
                      ).join(' ')}
                      className="transition-all duration-1000"
                    />
                  ))}
                  <line x1={progressRatio * 100} y1="0" x2={progressRatio * 100} y2="100" stroke="white" strokeWidth="0.5" strokeDasharray="2" />
                </svg>
             </div>
          </div>

          <div className="fixed bottom-6 left-6 z-10 w-96 glass rounded-[2rem] border border-white/10 shadow-2xl overflow-hidden animate-in slide-in-from-bottom-4">
             <div className="bg-indigo-500/10 px-6 py-4 border-b border-white/5 flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${isPaused ? 'bg-yellow-500' : 'bg-emerald-500 animate-pulse'}`}></div>
                  <h3 className="text-[10px] font-black uppercase tracking-widest text-indigo-300">Téléprompteur</h3>
                </div>
                <div className="flex gap-4">
                  <button onClick={() => setElapsedTime(0)} className="text-slate-500 hover:text-white transition-colors"><i className="fas fa-undo-alt text-xs"></i></button>
                  <button onClick={() => setIsPaused(!isPaused)} className="text-white hover:scale-110 transition-transform"><i className={`fas ${isPaused ? 'fa-play' : 'fa-pause'} text-xs`}></i></button>
                </div>
             </div>
             <div className="h-48 overflow-y-auto p-8 font-serif text-lg leading-relaxed scroll-smooth bg-gradient-to-b from-transparent to-black/20">
                {words.map((w, idx) => (
                  <span key={idx} className={`mr-1.5 transition-all duration-300 inline-block ${idx === currentWordIndex ? 'text-indigo-400 font-bold scale-110' : idx < currentWordIndex ? 'text-slate-200' : 'text-slate-600'}`}>
                    {w}
                  </span>
                ))}
             </div>
             <div className="px-8 py-3 bg-black/40 text-[9px] font-mono text-slate-500 flex justify-between border-t border-white/5">
                <span className="flex items-center gap-2"><i className="fas fa-clock"></i> {Math.floor(elapsedTime / 60)}:{(elapsedTime % 60).toFixed(0).padStart(2, '0')}</span>
                <span>SEGMENT {Math.floor(progressRatio * 10) + 1} / 10</span>
             </div>
          </div>

          <div className="fixed bottom-6 right-6 z-10 flex flex-col items-end gap-3">
            {stats.overallCustomMetrics.map(m => (
              <div key={m.id} className="glass px-6 py-3 rounded-2xl border border-indigo-500/20 shadow-xl flex items-center gap-5 hover:border-indigo-500/50 transition-colors">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{m.label}</span>
                <span className="text-indigo-400 font-black text-xl">{m.value}%</span>
              </div>
            ))}
            <button onClick={() => setShowConfig(true)} className="group glass px-8 py-4 rounded-2xl bg-indigo-600/10 hover:bg-indigo-600/20 border border-indigo-500/30 font-bold transition-all shadow-lg flex items-center gap-3">
              <i className="fas fa-magic text-indigo-400 group-hover:rotate-12 transition-transform"></i> NOUVEAU PITCH
            </button>
          </div>
        </>
      )}

      {selectedPersona && (
        <PersonaDetails 
          persona={currentPersonas.find(p => p.id === selectedPersona.id) || selectedPersona} 
          onClose={() => setSelectedPersona(null)} 
          onRetry={() => setShowConfig(true)} 
        />
      )}
    </div>
  );
};

export default App;
