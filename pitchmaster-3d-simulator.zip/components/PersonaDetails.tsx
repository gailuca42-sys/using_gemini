
import React from 'react';
import { Persona } from '../types';
import { COLORS } from '../constants';

interface PersonaDetailsProps {
  persona: Persona;
  onClose: () => void;
  onRetry: () => void;
}

const PersonaDetails: React.FC<PersonaDetailsProps> = ({ persona, onClose, onRetry }) => {
  const color = COLORS[persona.state];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-300" onClick={onClose}>
      <div 
        className="w-full max-w-md glass rounded-[3rem] overflow-hidden shadow-2xl border border-white/10"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="h-2" style={{ backgroundColor: color }}></div>
        
        <div className="p-10">
          <div className="flex justify-between items-start mb-8">
            <div>
              <div className="flex items-center gap-3 mb-1">
                <h2 className="text-3xl font-black text-white">{persona.name}</h2>
                <span className="text-2xl">{persona.emotion.split(' ').pop()}</span>
              </div>
              <p className="text-indigo-400 font-bold text-xs uppercase tracking-widest mb-1">{persona.archetype}</p>
              <p className="text-slate-500 text-sm">{persona.age} ans • {persona.job}</p>
            </div>
            <button onClick={onClose} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-slate-400 hover:text-white transition-all">
              <i className="fas fa-times"></i>
            </button>
          </div>

          <div className="space-y-6">
            <div className="p-8 rounded-[2rem] bg-indigo-500/5 border border-indigo-500/10 relative overflow-hidden">
              <i className="fas fa-quote-left absolute top-4 left-4 text-indigo-500/10 text-4xl"></i>
              <div className="flex justify-between items-center mb-4 relative z-10">
                <span className="text-[10px] font-black text-indigo-400/60 uppercase tracking-widest">Réflexion interne</span>
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-white/5" style={{ color }}>{persona.emotion}</span>
              </div>
              <p className="text-lg text-slate-200 italic leading-relaxed font-serif relative z-10">
                "{persona.thought}"
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <MetricBox label="Affinité" val={Math.round(50 + persona.modifiers.interest)} color={color} />
              <MetricBox label="Attention" val={Math.round(50 + persona.modifiers.attention)} color={color} />
            </div>

            <div className="pt-4 flex gap-3">
               {persona.traits.map(t => (
                 <span key={t} className="text-[9px] px-3 py-1 rounded-full bg-white/5 text-slate-400 border border-white/5">#{t}</span>
               ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const MetricBox = ({ label, val, color }: { label: string, val: number, color: string }) => (
  <div className="p-5 rounded-2xl bg-black/20 border border-white/5">
    <div className="text-[9px] font-black text-slate-500 uppercase mb-2 tracking-widest">{label}</div>
    <div className="text-2xl font-black text-white mb-2">{Math.min(100, Math.max(0, val))}%</div>
    <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
      <div className="h-full transition-all duration-1000" style={{ width: `${val}%`, backgroundColor: color }}></div>
    </div>
  </div>
);

export default PersonaDetails;
