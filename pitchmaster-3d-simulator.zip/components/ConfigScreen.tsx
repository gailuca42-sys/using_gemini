
import React, { useState } from 'react';
import { SimulationConfig } from '../types';

interface ConfigScreenProps {
  onStart: (config: SimulationConfig) => void;
  initialConfig?: SimulationConfig;
}

const ConfigScreen: React.FC<ConfigScreenProps> = ({ onStart, initialConfig }) => {
  const [config, setConfig] = useState<SimulationConfig>(initialConfig || {
    pitch: '',
    context: 'Pitch deck devant un jury d\'investisseurs exigeants',
    size: 50,
    avgAge: 35,
    type: 'Business Angels & Directeurs Innovation',
    kindness: 50,
    customMetrics: []
  });

  const [newMetric, setNewMetric] = useState('');

  const addMetric = () => {
    if (newMetric.trim() && !config.customMetrics.includes(newMetric)) {
      setConfig({ ...config, customMetrics: [...config.customMetrics, newMetric.trim()] });
      setNewMetric('');
    }
  };

  const removeMetric = (m: string) => {
    setConfig({ ...config, customMetrics: config.customMetrics.filter(x => x !== m) });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950 overflow-y-auto">
      <div className="w-full max-w-3xl glass rounded-3xl p-8 shadow-2xl border-white/10 animate-in fade-in zoom-in duration-300 my-8">
        <h1 className="text-3xl font-bold text-white mb-2">Configuration du Pitch</h1>
        <p className="text-slate-400 mb-8 font-light">Paramétrez le contexte pour une analyse IA ultra-personnalisée.</p>

        <form onSubmit={(e) => { e.preventDefault(); onStart(config); }} className="space-y-8">
          <div className="space-y-2">
            <label className="text-xs font-bold text-indigo-400 uppercase tracking-widest flex justify-between">
              Votre Pitch
              <span className="text-[10px] text-slate-500 normal-case font-normal italic">Plus vous êtes précis, plus les réactions le seront.</span>
            </label>
            <textarea
              className="w-full h-40 bg-slate-900/80 border border-slate-700 rounded-2xl p-4 text-white font-serif text-lg leading-relaxed focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              placeholder="Ex: Bonjour à tous, aujourd'hui je vais vous présenter..."
              value={config.pitch}
              onChange={(e) => setConfig({ ...config, pitch: e.target.value })}
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase">Contexte de la Présentation</label>
                <input
                  type="text"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  value={config.context}
                  onChange={(e) => setConfig({ ...config, context: e.target.value })}
                  placeholder="Ex: Soutenance de Master, Conférence TEDx, Demo Day..."
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase">Cible de l'Audience</label>
                <input
                  type="text"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  value={config.type}
                  onChange={(e) => setConfig({ ...config, type: e.target.value })}
                  placeholder="Ex: Experts en IA, Enfants de 10 ans, Clients potentiels..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase">Âge Moyen</label>
                  <input
                    type="number" min="5" max="100"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white outline-none"
                    value={config.avgAge}
                    onChange={(e) => setConfig({ ...config, avgAge: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase">Nombre d'Auditeurs</label>
                  <input
                    type="number" min="5" max="150"
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white outline-none"
                    value={config.size}
                    onChange={(e) => setConfig({ ...config, size: Math.min(150, parseInt(e.target.value) || 5) })}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase">Métriques de Succès</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl p-3 text-white text-sm outline-none"
                    placeholder="Ex: Crédibilité, Humour, Émotion..."
                    value={newMetric}
                    onChange={(e) => setNewMetric(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addMetric())}
                  />
                  <button type="button" onClick={addMetric} className="px-4 bg-indigo-600 rounded-xl hover:bg-indigo-500 transition-colors">
                    <i className="fas fa-plus"></i>
                  </button>
                </div>
                <div className="flex flex-wrap gap-2 mt-2 max-h-24 overflow-y-auto p-1">
                  {config.customMetrics.map(m => (
                    <span key={m} className="px-3 py-1 bg-indigo-500/20 text-indigo-300 text-[10px] rounded-full flex items-center gap-2 border border-indigo-500/30">
                      {m} <i className="fas fa-times cursor-pointer hover:text-white" onClick={() => removeMetric(m)}></i>
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase">Niveau de Bienveillance ({config.kindness}%)</label>
                <div className="flex items-center gap-4">
                  <i className="fas fa-angry text-red-500 text-xs"></i>
                  <input
                    type="range" min="0" max="100"
                    className="flex-1 h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                    value={config.kindness}
                    onChange={(e) => setConfig({ ...config, kindness: parseInt(e.target.value) })}
                  />
                  <i className="fas fa-smile text-emerald-500 text-xs"></i>
                </div>
              </div>
            </div>
          </div>

          <button type="submit" className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-2xl shadow-xl shadow-indigo-600/20 transition-all flex items-center justify-center gap-3 active:scale-[0.98]">
            <i className="fas fa-magic"></i> GÉNÉRER L'AUDIENCE ET L'ANALYSE
          </button>
        </form>
      </div>
    </div>
  );
};

export default ConfigScreen;
