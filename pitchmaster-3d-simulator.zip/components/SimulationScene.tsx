
// Fix: Use React Three Fiber types to augment JSX intrinsic elements.
import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame, ThreeElements } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Stars } from '@react-three/drei';
import * as THREE from 'three';
import { Persona, AttendeeState } from '../types';
import { COLORS } from '../constants';

// Fix: Augment global JSX namespaces to include Three.js elements.
declare global {
  namespace React {
    namespace JSX {
      interface IntrinsicElements extends ThreeElements {}
    }
  }
}

interface SpherePersonProps {
  persona: Persona;
  onClick: (persona: Persona) => void;
}

const SpherePerson: React.FC<SpherePersonProps> = ({ persona, onClick }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const color = COLORS[persona.state];
  
  // Chaque personne a une "taille" légèrement différente pour briser l'uniformité
  const individualScale = useMemo(() => 0.8 + (persona.id % 5) * 0.1, [persona.id]);

  useFrame((state) => {
    if (!meshRef.current) return;
    const t = state.clock.getElapsedTime();
    const phase = persona.id * 0.5;

    switch (persona.state) {
      case AttendeeState.VERY_ATTENTIVE:
        // Gentle bounce + pulsing
        meshRef.current.position.y = persona.position[1] + Math.sin(t * 3 + phase) * 0.15;
        meshRef.current.scale.setScalar(individualScale + Math.sin(t * 2) * 0.05);
        break;
      case AttendeeState.ATTENTIVE:
        // Slow rotation
        meshRef.current.rotation.y += 0.01;
        meshRef.current.position.y = persona.position[1] + Math.sin(t * 1 + phase) * 0.05;
        break;
      case AttendeeState.DISTRACTED:
        // Erratic jitter or swaying
        meshRef.current.position.x = persona.position[0] + Math.sin(t * 2 + phase) * 0.15;
        meshRef.current.rotation.z = Math.sin(t * 1 + phase) * 0.1;
        break;
      case AttendeeState.DROPPED_OUT:
        // Sinking drift
        meshRef.current.position.y = persona.position[1] - 0.3 + Math.sin(t * 0.5 + phase) * 0.05;
        meshRef.current.rotation.x = 0.5; // "Looking down"
        break;
    }
  });

  return (
    <group position={persona.position}>
      <mesh 
        ref={meshRef} 
        scale={individualScale}
        onClick={(e) => {
          e.stopPropagation();
          onClick(persona);
        }}
        onPointerOver={() => (document.body.style.cursor = 'pointer')}
        onPointerOut={() => (document.body.style.cursor = 'auto')}
      >
        <sphereGeometry args={[0.5, 32, 32]} />
        <meshStandardMaterial 
          color={color} 
          emissive={color} 
          emissiveIntensity={persona.state === AttendeeState.VERY_ATTENTIVE ? 0.4 : 0.1} 
          roughness={0.4} 
          metalness={0.6} 
        />
      </mesh>
    </group>
  );
};

const Stage = () => {
  return (
    <group position={[0, -1, 0]}>
      {/* Speaker Platform */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.05, 0]}>
        <circleGeometry args={[5, 64]} />
        <meshStandardMaterial color="#0f172a" metalness={0.8} roughness={0.2} />
      </mesh>
      {/* Light for the speaker */}
      <spotLight position={[0, 10, 0]} angle={0.4} penumbra={1} intensity={3} color="#fff" castShadow />
      
      {/* Room Floor */}
      <gridHelper args={[120, 40, "#1e293b", "#0f172a"]} />
    </group>
  );
};

interface SimulationSceneProps {
  personas: Persona[];
  onSelectPersona: (persona: Persona) => void;
}

const SimulationScene: React.FC<SimulationSceneProps> = ({ personas, onSelectPersona }) => {
  return (
    <div className="w-full h-full bg-slate-950">
      <Canvas shadows dpr={[1, 2]}>
        <PerspectiveCamera makeDefault position={[0, 15, 35]} fov={50} />
        <OrbitControls 
          enableDamping 
          dampingFactor={0.05}
          maxPolarAngle={Math.PI / 1.8} 
          minDistance={10}
          maxDistance={80}
          target={[0, 4, 0]}
        />
        
        <ambientLight intensity={0.2} />
        <pointLight position={[20, 30, 20]} intensity={1.5} color="#4f46e5" />
        <pointLight position={[-20, 30, 20]} intensity={1} color="#3b82f6" />
        <Stars radius={100} depth={50} count={3000} factor={4} saturation={0} fade speed={0.5} />
        
        <Stage />
        
        {personas.map((p) => (
          <SpherePerson key={p.id} persona={p} onClick={onSelectPersona} />
        ))}
      </Canvas>
    </div>
  );
};

export default SimulationScene;
