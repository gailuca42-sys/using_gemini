
export enum AttendeeState {
  VERY_ATTENTIVE = 'VERY_ATTENTIVE',
  ATTENTIVE = 'ATTENTIVE',
  DISTRACTED = 'DISTRACTED',
  DROPPED_OUT = 'DROPPED_OUT'
}

export interface CustomMetric {
  id: string;
  label: string;
  value: number;
}

export interface Persona {
  id: number;
  name: string;
  age: number;
  job: string;
  archetype: string; // ex: "Le Sceptique", "L'Enthousiaste"
  traits: string[];
  emotion: string;
  state: AttendeeState;
  thought: string;
  reactionOffset: number; // Pour désynchroniser les réactions (0.0 to 0.1)
  modifiers: {
    attention: number;
    interest: number;
    comprehension: number;
  };
  position: [number, number, number];
}

export interface SimulationConfig {
  pitch: string;
  context: string; // Nouveau: Contexte de la présentation (Jury, Conférence, etc.)
  size: number;
  avgAge: number;
  type: string;
  kindness: number;
  customMetrics: string[];
}

export interface DataPoint {
  attention: number;
  interest: number;
  comprehension: number;
  analysis: string; // Analyse spécifique du contenu par l'IA pour ce segment
  customScores: Record<string, number>;
}

export interface SimulationStats {
  timeline: DataPoint[];
  overallCustomMetrics: CustomMetric[];
}
