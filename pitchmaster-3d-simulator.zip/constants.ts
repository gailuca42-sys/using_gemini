
import { AttendeeState } from './types';

export const COLORS = {
  [AttendeeState.VERY_ATTENTIVE]: '#4ade80',
  [AttendeeState.ATTENTIVE]: '#facc15',
  [AttendeeState.DISTRACTED]: '#fb923c',
  [AttendeeState.DROPPED_OUT]: '#f87171',
};

export const STATE_LABELS = {
  [AttendeeState.VERY_ATTENTIVE]: 'Très attentif 🟢',
  [AttendeeState.ATTENTIVE]: 'Attentif 🟡',
  [AttendeeState.DISTRACTED]: 'Distrait 🟠',
  [AttendeeState.DROPPED_OUT]: 'Décroché 🔴',
};

export const FRENCH_NAMES = [
  'Sophie L.', 'Jean-Marc P.', 'Marie D.', 'Thomas B.', 'Lucie M.', 'Antoine R.', 'Camille G.',
  'Nicolas V.', 'Julie F.', 'Pierre K.', 'Elodie S.', 'Guillaume T.', 'Amandine C.', 'Benoît J.',
  'Chloé H.', 'Damien W.', 'Emilie N.', 'Fabien Q.', 'Gaëlle Z.', 'Hugo O.', 'Inès U.', 'Jérôme E.',
  'Kévin A.', 'Léa I.', 'Maxime S.', 'Noémie P.', 'Olivier L.', 'Pauline G.', 'Quentin M.', 'Roxane D.',
  'Victor B.', 'Sarah M.', 'Yassine K.', 'Léna P.', 'Arthur J.', 'Zoé F.', 'Théo R.', 'Clara L.'
];

export const ARCHETYPES: Record<string, any> = {
  "Le Sceptique": {
    focusWeight: { attention: 0.8, interest: 1.2, comprehension: 1.0 },
    baseThreshold: 18, 
    reactions: {
      [AttendeeState.VERY_ATTENTIVE]: ["D'habitude je doute, mais {analysis} me semble vraiment solide.", "Il a marqué un point décisif sur {analysis}."],
      [AttendeeState.ATTENTIVE]: ["C'est intéressant ce qu'il dit sur {analysis}, mais j'attends la preuve.", "Je note l'argument sur {analysis}, c'est à creuser."],
      [AttendeeState.DISTRACTED]: ["Je ne suis pas convaincu par {analysis}, ça manque de profondeur.", "Trop de zones d'ombre sur {analysis} pour que j'y croie."],
      [AttendeeState.DROPPED_OUT]: ["C'est du vent. {analysis} est un argument totalement fallacieux.", "J'ai arrêté d'écouter, {analysis} n'a aucun sens pour moi."]
    }
  },
  "L'Enthousiaste": {
    focusWeight: { attention: 1.1, interest: 1.2, comprehension: 0.7 },
    baseThreshold: -12, 
    reactions: {
      [AttendeeState.VERY_ATTENTIVE]: ["Génial ! {analysis} est exactement ce que je voulais entendre !", "Je suis totalement fan de son approche sur {analysis}."],
      [AttendeeState.ATTENTIVE]: ["C'est super inspirant quand il évoque {analysis}.", "Très bonne énergie sur {analysis}, ça me parle !"],
      [AttendeeState.DISTRACTED]: ["C'est un peu moins percutant quand on parle de {analysis}...", "J'aime l'idée mais {analysis} mériterait d'être plus punchy."],
      [AttendeeState.DROPPED_OUT]: ["Dommage, j'ai perdu l'excitation du début sur {analysis}.", "C'est devenu trop complexe au moment de {analysis}."]
    }
  },
  "L'Analyste": {
    focusWeight: { attention: 0.7, interest: 0.8, comprehension: 1.5 },
    baseThreshold: 8,
    reactions: {
      [AttendeeState.VERY_ATTENTIVE]: ["La logique derrière {analysis} est implacable. Très structuré.", "Les données évoquées sur {analysis} sont excellentes."],
      [AttendeeState.ATTENTIVE]: ["D'accord avec {analysis}, c'est cohérent avec les indicateurs.", "L'explication sur {analysis} est rationnelle et précise."],
      [AttendeeState.DISTRACTED]: ["Il manque de précision chiffrée sur {analysis} pour me convaincre.", "Un peu trop superficiel sur {analysis} à mon goût."],
      [AttendeeState.DROPPED_OUT]: ["Incohérence majeure sur {analysis}, je ne peux plus suivre.", "Erreur de raisonnement sur {analysis}, je décroche."]
    }
  },
  "Le Visionnaire": {
    focusWeight: { attention: 1.0, interest: 1.4, comprehension: 0.6 },
    baseThreshold: 2,
    reactions: {
      [AttendeeState.VERY_ATTENTIVE]: ["Enfin quelqu'un qui ose voir grand avec {analysis} !", "C'est disruptif, surtout la vision sur {analysis}."],
      [AttendeeState.ATTENTIVE]: ["Potentiel de transformation énorme sur {analysis}.", "Ça pourrait changer les règles du jeu s'il développe {analysis}."],
      [AttendeeState.DISTRACTED]: ["Un peu trop classique dans son approche de {analysis}.", "Il manque d'ambition sur le sujet de {analysis}."],
      [AttendeeState.DROPPED_OUT]: ["Zéro vision à long terme. {analysis} est trop limité.", "C'est du déjà-vu. {analysis} ne m'apporte rien de neuf."]
    }
  },
  "Le Novice": {
    focusWeight: { attention: 0.5, interest: 1.0, comprehension: 1.5 },
    baseThreshold: 6,
    reactions: {
      [AttendeeState.VERY_ATTENTIVE]: ["Ah d'accord ! {analysis} m'aide vraiment à y voir clair.", "C'est hyper pédagogique sur {analysis}, je comprends enfin."],
      [AttendeeState.ATTENTIVE]: ["J'apprends quelque chose de nouveau sur {analysis}.", "C'est intéressant cette explication sur {analysis}."],
      [AttendeeState.DISTRACTED]: ["Il utilise des termes trop techniques pour {analysis}...", "Je commence à me sentir perdu sur {analysis}."],
      [AttendeeState.DROPPED_OUT]: ["Je ne comprends strictement rien à {analysis}.", "Complètement largué par les explications sur {analysis}."]
    }
  },
  "Le Pressé": {
    focusWeight: { attention: 1.4, interest: 1.1, comprehension: 0.5 },
    baseThreshold: 12,
    reactions: {
      [AttendeeState.VERY_ATTENTIVE]: ["Efficace, il va droit au but sur {analysis}.", "Clair et concis sur {analysis}. J'apprécie l'effort."],
      [AttendeeState.ATTENTIVE]: ["Ça avance bien. {analysis} est un point clé expédié.", "Ok, j'ai l'info pour {analysis}, on passe à la suite ?"],
      [AttendeeState.DISTRACTED]: ["Il s'écoute parler sur {analysis}, c'est trop long...", "Abrège sur {analysis}, j'ai un timing serré."],
      [AttendeeState.DROPPED_OUT]: ["Beaucoup trop de blabla sur {analysis}. Je m'en vais.", "Perte de temps sur {analysis}, je n'écoute plus."]
    }
  }
};
