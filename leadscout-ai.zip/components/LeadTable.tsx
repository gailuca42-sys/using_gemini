
import React, { useState } from 'react';
import { ProspectEmail } from '../types';

interface EmailListProps {
  emails: ProspectEmail[];
}

const EmailCard: React.FC<{ email: ProspectEmail }> = ({ email }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    const text = `Objet : ${email.subjectLine}\n\n${email.emailContent}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden flex flex-col h-full">
      <div className="px-5 py-3 bg-gray-50 border-b border-gray-100 flex justify-between items-center">
        <div>
          <h3 className="font-bold text-gray-900">{email.companyName}</h3>
          <p className="text-xs text-indigo-600 font-medium">Cible : {email.targetRole}</p>
        </div>
        <button 
          onClick={handleCopy}
          className={`text-xs px-3 py-1.5 rounded-md font-bold transition-all flex items-center gap-1.5 ${
            copied ? 'bg-green-100 text-green-700' : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
          }`}
        >
          {copied ? <><i className="fas fa-check"></i> Copié</> : <><i className="fas fa-copy"></i> Copier</>}
        </button>
      </div>
      <div className="p-5 flex-grow">
        <div className="mb-3">
          <span className="text-[10px] uppercase tracking-wider font-bold text-gray-400">Objet</span>
          <p className="text-sm font-semibold text-gray-800">{email.subjectLine}</p>
        </div>
        <div className="bg-indigo-50/30 p-4 rounded-lg border border-indigo-100/50">
          <p className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed italic">
            {email.emailContent}
          </p>
        </div>
      </div>
      <div className="px-5 py-2 bg-indigo-50 border-t border-indigo-100">
        <p className="text-[10px] text-indigo-700 italic">
          <i className="fas fa-magic mr-1"></i> Basé sur : {email.keyPersonalizationPoint}
        </p>
      </div>
    </div>
  );
};

const LeadTable: React.FC<EmailListProps> = ({ emails }) => {
  const [allCopied, setAllCopied] = useState(false);

  if (emails.length === 0) return null;

  const handleCopyAll = () => {
    const text = emails.map(email => (
      `--- ${email.companyName.toUpperCase()} ---\n` +
      `Cible : ${email.targetRole}\n` +
      `Objet : ${email.subjectLine}\n\n` +
      `${email.emailContent}\n\n`
    )).join('\n');
    
    navigator.clipboard.writeText(text);
    setAllCopied(true);
    setTimeout(() => setAllCopied(false), 2000);
  };

  return (
    <div className="mt-12 animate-fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Emails de Prospection Générés</h2>
          <p className="text-sm text-gray-500 mt-1">Cliquez sur copier pour utiliser les messages dans votre outil d'envoi.</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="bg-indigo-100 text-indigo-700 text-xs font-bold px-3 py-1 rounded-full border border-indigo-200">
            {emails.length} Prospects
          </span>
          <button 
            onClick={handleCopyAll}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all shadow-sm ${
              allCopied 
                ? 'bg-green-600 text-white' 
                : 'bg-indigo-600 text-white hover:bg-indigo-700'
            }`}
          >
            {allCopied ? (
              <><i className="fas fa-check"></i> Tous copiés !</>
            ) : (
              <><i className="fas fa-copy"></i> Tout copier</>
            )}
          </button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {emails.map((email, idx) => (
          <EmailCard key={idx} email={email} />
        ))}
      </div>
    </div>
  );
};

export default LeadTable;
