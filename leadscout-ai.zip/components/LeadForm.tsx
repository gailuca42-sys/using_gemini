
import React, { useState } from 'react';
import { UserContext } from '../types';

interface LeadFormProps {
  onAnalyze: (context: UserContext, rawData: string) => void;
  isAnalyzing: boolean;
}

const LeadForm: React.FC<LeadFormProps> = ({ onAnalyze, isAnalyzing }) => {
  const [context, setContext] = useState<UserContext>({
    productDescription: '',
    targetAudience: '',
    valueProposition: '',
    emailTemplate: '',
    additionalInstructions: ''
  });
  const [rawData, setRawData] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // On permet l'envoi même si les champs sont vides
    onAnalyze(context, rawData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-xl shadow-sm border border-gray-200">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Colonne Gauche : Paramètres de vente */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-wider">Configuration Vente</h3>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Produit / Service (Facultatif)
            </label>
            <input
              type="text"
              placeholder="ex: SaaS de gestion de projet BTP"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
              value={context.productDescription}
              onChange={(e) => setContext({ ...context, productDescription: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Profil Client Idéal (Facultatif)
            </label>
            <input
              type="text"
              placeholder="ex: Directeurs techniques d'entreprises de construction"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
              value={context.targetAudience}
              onChange={(e) => setContext({ ...context, targetAudience: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Modèle d'Inspiration (Facultatif)
            </label>
            <textarea
              rows={3}
              placeholder="L'IA s'inspirera du style sans le copier mot pour mot..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
              value={context.emailTemplate}
              onChange={(e) => setContext({ ...context, emailTemplate: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Instructions Spécifiques (Facultatif)
            </label>
            <textarea
              rows={2}
              placeholder="ex: Mentionne notre offre d'essai de 30 jours, utilise un ton très décontracté..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
              value={context.additionalInstructions}
              onChange={(e) => setContext({ ...context, additionalInstructions: e.target.value })}
            />
          </div>
        </div>

        {/* Colonne Droite : Données Sources */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-wider">Données Sources</h3>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              Données Brutes (Facultatif)
            </label>
            <textarea
              rows={12}
              placeholder="Collez ici les infos récoltées sur vos prospects (LinkedIn, articles, rapports...)"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono text-xs"
              value={rawData}
              onChange={(e) => setRawData(e.target.value)}
            />
            <p className="mt-2 text-[10px] text-gray-400 italic flex items-center gap-1">
              <i className="fas fa-info-circle"></i>
              Si aucun texte n'est fourni, l'IA créera des exemples basés sur votre configuration.
            </p>
          </div>
        </div>
      </div>

      <div className="flex justify-end pt-4 border-t border-gray-100">
        <button
          type="submit"
          disabled={isAnalyzing}
          className={`flex items-center gap-2 px-8 py-3 rounded-lg font-bold text-white transition-all shadow-lg ${
            isAnalyzing 
              ? 'bg-gray-400 cursor-not-allowed' 
              : 'bg-indigo-600 hover:bg-indigo-700 active:scale-95'
          }`}
        >
          {isAnalyzing ? (
            <>
              <i className="fas fa-spinner fa-spin"></i>
              Génération en cours...
            </>
          ) : (
            <>
              <i className="fas fa-magic"></i>
              Générer les Emails
            </>
          )}
        </button>
      </div>
    </form>
  );
};

export default LeadForm;
