
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
              <i className="fas fa-radar text-white text-sm"></i>
            </div>
            <h1 className="text-xl font-bold text-gray-900 tracking-tight">LeadScout <span className="text-indigo-600">AI</span></h1>
          </div>
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-gray-500 hover:text-gray-900 text-sm font-medium">Tableau de bord</a>
            <a href="#" className="text-gray-500 hover:text-gray-900 text-sm font-medium">Historique</a>
            <a href="#" className="text-gray-500 hover:text-gray-900 text-sm font-medium">Exportations</a>
          </nav>
          <div className="flex items-center gap-4">
             <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
              <span className="w-2 h-2 mr-1.5 bg-green-500 rounded-full"></span>
              Gemini 3 Pro Actif
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
