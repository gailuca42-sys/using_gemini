
import React, { useState } from 'react';
import Header from './components/Header';
import LeadForm from './components/LeadForm';
import LeadTable from './components/LeadTable';
import { AnalysisState, ProspectEmail, UserContext } from './types';
import { generateProspectEmails } from './geminiService';

const App: React.FC = () => {
  const [state, setState] = useState<AnalysisState>({
    isAnalyzing: false,
    error: null,
    results: null,
    progressMessage: ''
  });

  const handleAnalyze = async (context: UserContext, rawData: string) => {
    setState({
      ...state,
      isAnalyzing: true,
      error: null,
      results: null,
      progressMessage: 'Analyse en cours...'
    });

    const messages = [
      'Analyse du contexte...',
      'Préparation de la stratégie...',
      'Rédaction des messages...',
      'Affinage du ton...',
      'Finalisation...'
    ];

    let msgIdx = 0;
    const interval = setInterval(() => {
      if (msgIdx < messages.length) {
        setState(prev => ({ ...prev, progressMessage: messages[msgIdx++] }));
      } else {
        clearInterval(interval);
      }
    }, 2500);

    try {
      const results = await generateProspectEmails(context, rawData);
      setState({
        isAnalyzing: false,
        error: null,
        results,
        progressMessage: ''
      });
      clearInterval(interval);
    } catch (err: any) {
      setState({
        isAnalyzing: false,
        error: err.message || 'Une erreur est survenue.',
        results: null,
        progressMessage: ''
      });
      clearInterval(interval);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        <div className="mb-10 text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Générateur d'Emails de Prospection IA
          </h2>
          <p className="mt-4 text-lg text-gray-500">
            Passez du texte brut à des emails de vente personnalisés. 
            Tous les champs sont maintenant facultatifs pour une flexibilité totale.
          </p>
        </div>

        <LeadForm onAnalyze={handleAnalyze} isAnalyzing={state.isAnalyzing} />

        {state.isAnalyzing && (
          <div className="mt-12 text-center animate-fade-in">
            <div className="inline-block relative">
               <div className="w-16 h-16 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
               <div className="absolute inset-0 flex items-center justify-center">
                 <i className="fas fa-pen-nib text-indigo-600 text-xl"></i>
               </div>
            </div>
            <p className="mt-4 text-gray-600 font-medium animate-pulse">{state.progressMessage}</p>
          </div>
        )}

        {state.error && (
          <div className="mt-8 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3 text-red-700">
            <i className="fas fa-exclamation-circle mt-1"></i>
            <div>
              <p className="font-bold">Erreur de génération</p>
              <p className="text-sm">{state.error}</p>
            </div>
          </div>
        )}

        {state.results && <LeadTable emails={state.results} />}

        {!state.results && !state.isAnalyzing && (
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 opacity-60">
            <div className="p-6 bg-white rounded-xl border border-dashed border-gray-300 flex flex-col items-center text-center">
              <i className="fas fa-bullseye text-gray-400 text-3xl mb-3"></i>
              <h3 className="font-semibold text-gray-900">Ciblage flexible</h3>
              <p className="text-xs text-gray-500 mt-2">Définissez ce que vous voulez, quand vous le voulez.</p>
            </div>
            <div className="p-6 bg-white rounded-xl border border-dashed border-gray-300 flex flex-col items-center text-center">
              <i className="fas fa-keyboard text-gray-400 text-3xl mb-3"></i>
              <h3 className="font-semibold text-gray-900">IA Intelligente</h3>
              <p className="text-xs text-gray-500 mt-2">Gemini 3 Pro s'adapte au manque d'information pour proposer des solutions.</p>
            </div>
            <div className="p-6 bg-white rounded-xl border border-dashed border-gray-300 flex flex-col items-center text-center">
              <i className="fas fa-paper-plane text-gray-400 text-3xl mb-3"></i>
              <h3 className="font-semibold text-gray-900">Action immédiate</h3>
              <p className="text-xs text-gray-500 mt-2">Copiez-collez et lancez votre campagne instantanément.</p>
            </div>
          </div>
        )}
      </main>

      <footer className="bg-white border-t border-gray-200 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-gray-400 text-sm">© 2024 EmailScout AI. Propulsé par Gemini 3 Pro.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
