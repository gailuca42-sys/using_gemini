
import { GoogleGenAI, Type } from "@google/genai";
import { ProspectEmail, UserContext } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateProspectEmails(context: UserContext, rawData: string): Promise<ProspectEmail[]> {
  const productInfo = context.productDescription || "un produit ou service générique de haute qualité";
  const audienceInfo = context.targetAudience || "des décideurs B2B";
  const valueInfo = context.valueProposition || "l'amélioration de l'efficacité opérationnelle";

  const templateInstruction = context.emailTemplate 
    ? `MODÈLE D'INSPIRATION (Ne pas copier mot pour mot, s'en inspirer pour le style et la structure) : \n"${context.emailTemplate}"`
    : `Utilisez votre expertise pour rédiger des emails uniques, percutants et professionnels.`;

  const extraInstructions = context.additionalInstructions
    ? `INSTRUCTIONS SUPPLÉMENTAIRES (À respecter impérativement) : \n"${context.additionalInstructions}"`
    : "";

  const dataInstruction = rawData 
    ? `Données brutes pour l'analyse et la rédaction : \n\n ${rawData}`
    : `Note : Aucune donnée brute n'a été fournie. Générez 3 exemples d'emails fictifs mais réalistes basés sur le contexte fourni.`;

  const systemInstruction = `
    Vous êtes un expert en Copywriting et en Outbound Sales (Cold Emailing).
    Votre tâche est de rédiger des emails de prospection personnalisés et originaux.

    CONTEXTE DE VENTE :
    - Produit à vendre : ${productInfo}
    - Cible visée : ${audienceInfo}
    - Proposition de valeur : ${valueInfo}

    ${templateInstruction}
    ${extraInstructions}

    RÈGLES DE RÉDACTION :
    1. FLEXIBILITÉ : Si certains champs de contexte sont vides, faites preuve d'imagination créative pour proposer des solutions cohérentes.
    2. ORIGINALITÉ : Ne copiez pas le modèle d'inspiration mot pour mot. Adaptez le vocabulaire.
    3. PERSONNALISATION : Si des données brutes sont fournies, utilisez un élément concret. Sinon, laissez des [VARIABLES] claires pour que l'utilisateur puisse les remplir.
    4. STRUCTURE : Crochet personnalisé -> Valeur ajoutée -> Appel à l'action (CTA) simple.
    5. TON : Professionnel et humain.
    6. LANGUE : Français impeccable.

    RETOUR JSON :
    Générez une liste d'objets contenant le nom de l'entreprise, l'objet du mail, le corps du mail, le rôle ciblé et le point clé de personnalisation utilisé.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: [
        {
          text: dataInstruction
        }
      ],
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              companyName: { type: Type.STRING, description: "Nom de l'entreprise" },
              subjectLine: { type: Type.STRING, description: "Objet de l'email" },
              emailContent: { type: Type.STRING, description: "Corps de l'email" },
              targetRole: { type: Type.STRING, description: "Poste visé" },
              keyPersonalizationPoint: { type: Type.STRING, description: "Élément personnalisé utilisé" }
            },
            required: ["companyName", "subjectLine", "emailContent", "targetRole"]
          }
        },
        thinkingConfig: { thinkingBudget: 4000 }
      },
    });

    const jsonStr = response.text?.trim() || "[]";
    return JSON.parse(jsonStr);
  } catch (error) {
    console.error("Erreur de génération d'emails :", error);
    throw new Error("Échec de la rédaction des emails. Vérifiez vos paramètres et réessayez.");
  }
}
