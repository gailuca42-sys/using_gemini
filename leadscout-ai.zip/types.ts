
export interface ProspectEmail {
  companyName: string;
  subjectLine: string;
  emailContent: string;
  targetRole: string;
  keyPersonalizationPoint: string;
}

export interface AnalysisState {
  isAnalyzing: boolean;
  error: string | null;
  results: ProspectEmail[] | null;
  progressMessage: string;
}

export interface UserContext {
  productDescription: string;
  targetAudience: string;
  valueProposition: string;
  emailTemplate?: string;
  additionalInstructions?: string;
}
