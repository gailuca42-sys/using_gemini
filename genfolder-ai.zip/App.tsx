
import React, { useState, useRef } from 'react';
import { generateFolderContent } from './services/geminiService';
import { createZipArchive, downloadBlob } from './services/fileService';
import { GenerationState, PdfConfig } from './types';

const App: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [pdfConfig, setPdfConfig] = useState<PdfConfig>({
    fontSize: 11,
    margin: 20,
    logoDataUrl: null,
    logoPosition: 'header',
  });

  const [state, setState] = useState<GenerationState>({
    isGenerating: false,
    status: 'Ready for request',
    logs: [],
    zipUrl: null,
    error: null,
  });
  
  const zipBlobRef = useRef<Blob | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const addLog = (message: string) => {
    setState(prev => ({
      ...prev,
      logs: [message, ...prev.logs].slice(0, 8),
      status: message
    }));
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPdfConfig(prev => ({ ...prev, logoDataUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const removeLogo = () => {
    setPdfConfig(prev => ({ ...prev, logoDataUrl: null }));
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setState(prev => ({ ...prev, error: "Kindly provide your project details to proceed." }));
      return;
    }

    setState(prev => ({
      ...prev,
      isGenerating: true,
      error: null,
      zipUrl: null,
      logs: []
    }));

    try {
      addLog("Curating architectural logic...");
      const result = await generateFolderContent(prompt);
      
      addLog(`Mastering ${result.files.length} unique assets...`);
      
      addLog("Refining visual typography and layout...");
      const zipBlob = await createZipArchive(result.files, pdfConfig);
      zipBlobRef.current = zipBlob;
      
      const zipUrl = URL.createObjectURL(zipBlob);
      
      setState(prev => ({
        ...prev,
        isGenerating: false,
        status: 'Assets refined',
        zipUrl: zipUrl
      }));
      addLog("Your bespoke collection is ready for delivery.");

    } catch (err: any) {
      console.error(err);
      setState(prev => ({
        ...prev,
        isGenerating: false,
        status: 'Interrupted',
        error: err.message || "An unexpected technicality occurred during refinement."
      }));
    }
  };

  const handleDownload = () => {
    if (zipBlobRef.current) {
      downloadBlob(zipBlobRef.current, 'bespoke_collection.zip');
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-6 py-16 animate-in fade-in slide-in-from-bottom-8 duration-1000">
      {/* Premium Header */}
      <header className="text-center mb-16 relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-12 w-64 h-64 bg-blue-100/30 blur-[100px] rounded-full -z-10"></div>
        <div className="inline-flex items-center justify-center w-20 h-20 bg-[#1a1a1a] text-white rounded-[2rem] mb-8 shadow-2xl shadow-black/20 animate-float">
          <i className="fas fa-feather-pointed text-2xl"></i>
        </div>
        <h1 className="text-6xl font-black text-[#1a1a1a] mb-4 tracking-tighter luxe-serif">GenFolder</h1>
        <div className="flex items-center justify-center gap-4">
          <div className="h-px w-12 bg-slate-200"></div>
          <p className="text-slate-400 font-light uppercase tracking-[0.3em] text-xs">Architectural Intelligence</p>
          <div className="h-px w-12 bg-slate-200"></div>
        </div>
      </header>

      {/* Main Artisan Console */}
      <div className="glass-panel rounded-[2.5rem] shadow-[0_40px_100px_-20px_rgba(0,0,0,0.08)] p-1 md:p-1">
        <div className="bg-white/50 rounded-[2.4rem] p-8 md:p-12">
          <div className="space-y-8">
            {/* Input Section */}
            <div className="relative">
              <div className="flex items-center justify-between mb-4">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] ml-2">
                  Project Vision
                </label>
                <button 
                  onClick={() => setShowSettings(!showSettings)}
                  className={`group flex items-center gap-2 px-4 py-2 rounded-full transition-all text-xs font-semibold ${showSettings ? 'bg-[#1a1a1a] text-white' : 'text-slate-500 hover:bg-slate-100'}`}
                >
                  <i className={`fas fa-palette transition-transform duration-500 ${showSettings ? 'rotate-180' : ''}`}></i>
                  Bespoke Style
                </button>
              </div>
              
              <textarea
                className="w-full px-8 py-6 rounded-3xl border-none bg-[#f8f8f7] text-[#1a1a1a] focus:ring-2 focus:ring-[#1a1a1a]/5 transition-all outline-none resize-none text-xl placeholder:text-slate-300 shadow-inner min-h-[160px] font-light leading-relaxed"
                placeholder='Describe your masterpiece folder...'
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                disabled={state.isGenerating}
              />
            </div>

            {/* Customization Drawer */}
            {showSettings && (
              <div className="bg-white/80 rounded-3xl p-8 border border-slate-100 shadow-sm animate-in zoom-in-95 duration-300">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between text-[10px] font-black text-slate-400 mb-4 tracking-wider">
                        <span>TYPOGRAPHY SCALE</span>
                        <span className="text-[#1a1a1a]">{pdfConfig.fontSize}PT</span>
                      </div>
                      <input 
                        type="range" min="8" max="18"
                        value={pdfConfig.fontSize}
                        onChange={(e) => setPdfConfig(prev => ({ ...prev, fontSize: parseInt(e.target.value) }))}
                        className="w-full h-1 bg-slate-100 rounded-full appearance-none cursor-pointer accent-[#1a1a1a]"
                      />
                    </div>
                    <div>
                      <div className="flex justify-between text-[10px] font-black text-slate-400 mb-4 tracking-wider">
                        <span>SPATIAL MARGINS</span>
                        <span className="text-[#1a1a1a]">{pdfConfig.margin}MM</span>
                      </div>
                      <input 
                        type="range" min="10" max="40" step="5"
                        value={pdfConfig.margin}
                        onChange={(e) => setPdfConfig(prev => ({ ...prev, margin: parseInt(e.target.value) }))}
                        className="w-full h-1 bg-slate-100 rounded-full appearance-none cursor-pointer accent-[#1a1a1a]"
                      />
                    </div>
                  </div>
                  
                  <div className="flex flex-col justify-center">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider mb-4">Corporate Insignia</span>
                    {!pdfConfig.logoDataUrl ? (
                      <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-slate-200 rounded-2xl cursor-pointer hover:border-[#c5a059] hover:bg-[#c5a059]/5 transition-all group">
                        <i className="fas fa-plus text-slate-300 group-hover:text-[#c5a059] mb-2"></i>
                        <span className="text-[10px] font-black text-slate-300 group-hover:text-[#c5a059]">UPLOAD LOGO</span>
                        <input ref={fileInputRef} type="file" className="hidden" accept="image/*" onChange={handleLogoUpload} />
                      </label>
                    ) : (
                      <div className="flex items-center gap-6 bg-slate-50 p-4 rounded-2xl">
                        <div className="w-16 h-16 bg-white rounded-xl shadow-sm flex items-center justify-center p-2">
                          <img src={pdfConfig.logoDataUrl} alt="Logo" className="max-h-full max-w-full object-contain" />
                        </div>
                        <div className="flex-1">
                          <p className="text-[10px] font-bold text-slate-400 mb-2">PLACEMENT</p>
                          <div className="flex gap-2">
                            <button 
                              onClick={() => setPdfConfig(prev => ({ ...prev, logoPosition: 'header' }))}
                              className={`px-3 py-1 text-[10px] font-bold rounded-lg transition-all ${pdfConfig.logoPosition === 'header' ? 'bg-[#1a1a1a] text-white shadow-lg' : 'bg-white text-slate-400'}`}
                            >CREST</button>
                            <button 
                              onClick={() => setPdfConfig(prev => ({ ...prev, logoPosition: 'footer' }))}
                              className={`px-3 py-1 text-[10px] font-bold rounded-lg transition-all ${pdfConfig.logoPosition === 'footer' ? 'bg-[#1a1a1a] text-white shadow-lg' : 'bg-white text-slate-400'}`}
                            >BASE</button>
                          </div>
                        </div>
                        <button onClick={removeLogo} className="w-10 h-10 flex items-center justify-center text-slate-300 hover:text-red-400 transition-colors"><i className="fas fa-trash-can"></i></button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* CTA Section */}
            <div className="flex flex-col sm:flex-row gap-6 pt-4">
              <button
                onClick={handleGenerate}
                disabled={state.isGenerating || !prompt.trim()}
                className={`flex-1 relative overflow-hidden group py-6 rounded-3xl font-bold text-lg transition-all shadow-2xl ${
                  state.isGenerating 
                  ? 'bg-slate-100 text-slate-300 cursor-not-allowed' 
                  : 'bg-[#1a1a1a] text-white hover:shadow-black/20 hover:-translate-y-1 active:scale-[0.98]'
                }`}
              >
                <div className="relative z-10 flex items-center justify-center gap-3">
                  {state.isGenerating ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                      <span className="tracking-widest uppercase text-sm">Crafting...</span>
                    </>
                  ) : (
                    <>
                      <i className="fas fa-bolt-lightning text-sm text-[#c5a059]"></i>
                      <span className="tracking-widest uppercase text-sm">Manifest Collection</span>
                    </>
                  )}
                </div>
                {!state.isGenerating && (
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:animate-[shimmer_2s_infinite]"></div>
                )}
              </button>

              {state.zipUrl && (
                <button
                  onClick={handleDownload}
                  className="flex items-center justify-center gap-4 py-6 px-12 rounded-3xl bg-white border border-slate-100 text-[#1a1a1a] font-bold text-sm tracking-widest uppercase hover:bg-slate-50 hover:shadow-xl hover:-translate-y-1 active:scale-[0.98] transition-all shadow-sm animate-in fade-in zoom-in-90 duration-500"
                >
                  <i className="fas fa-download text-[#c5a059]"></i>
                  Archive
                </button>
              )}
            </div>

            {/* Elegantly handled Errors */}
            {state.error && (
              <div className="p-4 bg-red-50/50 text-red-700 text-xs font-medium rounded-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                <i className="fas fa-circle-exclamation text-red-400"></i>
                {state.error}
              </div>
            )}

            {/* Diagnostic Logs - The 'Engine Room' */}
            {(state.isGenerating || state.logs.length > 0) && (
              <div className="mt-12 pt-12 border-t border-slate-100">
                <div className="flex items-center justify-between mb-6">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">Engine Status</span>
                  <div className="flex items-center gap-2">
                    <div className={`w-1.5 h-1.5 rounded-full ${state.isGenerating ? 'bg-blue-500 animate-pulse' : 'bg-emerald-500'}`}></div>
                    <span className="text-[10px] font-black text-slate-800 uppercase tracking-widest">
                      {state.status}
                    </span>
                  </div>
                </div>
                <div className="space-y-3">
                  {state.logs.map((log, i) => (
                    <div key={i} className={`flex items-center gap-4 text-[11px] transition-all duration-700 ${i === 0 ? 'text-[#1a1a1a] translate-x-1 font-semibold' : 'text-slate-300 opacity-60'}`}>
                      <span className="w-12 text-[9px] font-mono text-slate-200">{new Date().toLocaleTimeString([], {minute:'2-digit', second:'2-digit'})}</span>
                      <span className="h-px w-4 bg-slate-100"></span>
                      <p>{log}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Sophisticated Features Footer */}
      <footer className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-16 px-8">
        {[
          { icon: 'fa-gem', title: 'Precision Layout', desc: 'Sophisticated algorithms ensuring flawless typographical flow and balance.' },
          { icon: 'fa-paper-plane', title: 'Swift Synthesis', desc: 'High-speed cloud neural networks delivering instant bespoke collections.' },
          { icon: 'fa-shield-halved', title: 'End-to-End Privacy', desc: 'Zero data retention. Your intellectual property stays within your reach.' }
        ].map((feat, idx) => (
          <div key={idx} className="group text-center">
            <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-6 mx-auto group-hover:scale-110 group-hover:shadow-xl transition-all duration-500">
              <i className={`fas ${feat.icon} text-[#c5a059] text-xl`}></i>
            </div>
            <h3 className="font-bold text-slate-800 mb-3 uppercase text-[11px] tracking-[0.2em]">{feat.title}</h3>
            <p className="text-sm text-slate-400 font-light leading-relaxed">{feat.desc}</p>
          </div>
        ))}
      </footer>
    </div>
  );
};

export default App;