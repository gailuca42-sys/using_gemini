
import JSZip from 'jszip';
import { jsPDF } from 'jspdf';
import { GeneratedFile, PdfConfig, PdfStyle } from '../types';

/**
 * Robust sanitization for jsPDF Standard Fonts (WinAnsiEncoding).
 * This ensures French accents like é, à, ç, etc. render correctly without gaps or weird symbols.
 */
const sanitizeForPdf = (text: string): string => {
  if (!text) return "";
  
  // 1. Normalize to decompose combined characters
  let clean = text.normalize('NFC');

  // 2. Explicitly map common problematic characters to WinAnsi equivalents
  // Standard jsPDF fonts use WinAnsi. If we don't map them, jsPDF might trip.
  const charMap: Record<string, string> = {
    '—': '--',
    '–': '-',
    '…': '...',
    '‘': "'",
    '’': "'",
    '“': '"',
    '”': '"',
    '„': '"',
    '†': '+',
    '‡': '++',
    '‰': '%',
    '•': '*',
    '€': 'EUR',
    '™': '(TM)',
    'œ': 'oe',
    'Œ': 'OE',
  };

  // Replace symbols based on map
  Object.keys(charMap).forEach(key => {
    clean = clean.split(key).join(charMap[key]);
  });

  // 3. Remove non-printable characters and weird AI artifacts like %4%$
  // This keeps standard Latin-1/WinAnsi range (which includes French accents)
  return clean.replace(/[^\x00-\x7F\x80-\xFF]/g, "");
};

/**
 * Generates a ZIP archive containing all files.
 */
export const createZipArchive = async (files: GeneratedFile[], pdfConfig: PdfConfig): Promise<Blob> => {
  const zip = new JSZip();

  for (const file of files) {
    const type = file.type.toLowerCase();
    if (type === 'pdf' || file.name.endsWith('.pdf')) {
      const pdfBlob = generatePdfBlob(file, pdfConfig);
      zip.file(file.name, pdfBlob);
    } else {
      zip.file(file.name, file.content);
    }
  }

  return await zip.generateAsync({ type: 'blob' });
};

const ptToMm = (pt: number) => pt * 0.3527;

const hexToRgb = (hex: string): [number, number, number] => {
  try {
    const cleanHex = hex.replace('#', '');
    const r = parseInt(cleanHex.slice(0, 2), 16);
    const g = parseInt(cleanHex.slice(2, 4), 16);
    const b = parseInt(cleanHex.slice(4, 6), 16);
    return [isNaN(r) ? 26 : r, isNaN(g) ? 26 : g, isNaN(b) ? 26 : b];
  } catch {
    return [26, 26, 26];
  }
};

/**
 * Professional PDF rendering engine with fixed encoding for Latin characters.
 */
const generatePdfBlob = (file: GeneratedFile, config: PdfConfig): Blob => {
  // Use 'pt' for more precise typography control internally
  const doc = new jsPDF({ 
    unit: 'mm', 
    format: 'a4',
    putOnlyUsedFonts: true,
    compress: true
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = config.margin;
  const contentWidth = pageWidth - (margin * 2);

  const style: PdfStyle = file.style || {
    primaryColor: '#1a1a1a',
    secondaryColor: '#c5a059',
    backgroundColor: '#ffffff',
    accentColor: '#f8f8f7',
    layoutTheme: 'corporate'
  };

  const [pr, pg, pb] = hexToRgb(style.primaryColor);
  const [sr, sg, sb] = hexToRgb(style.secondaryColor);

  const drawPageDecorations = () => {
    const [br, bg, bb] = hexToRgb(style.backgroundColor);
    doc.setFillColor(br, bg, bb);
    doc.rect(0, 0, pageWidth, pageHeight, 'F');

    // Minimalist Luxe Side Accent
    doc.setFillColor(pr, pg, pb);
    doc.rect(0, 0, 1.2, pageHeight, 'F');

    if (config.logoPosition === 'header' && config.logoDataUrl) {
      try { doc.addImage(config.logoDataUrl, 'PNG', margin, 12, 22, 10); } catch (e) {}
    }
  };

  const drawFooter = () => {
    const pageNum = doc.getNumberOfPages();
    doc.setFontSize(8);
    doc.setTextColor(190, 190, 190);
    doc.setFont("helvetica", "normal");
    doc.text(`Page ${pageNum}`, pageWidth - margin, pageHeight - 10, { align: 'right' });
    
    if (config.logoPosition === 'footer' && config.logoDataUrl) {
      try { doc.addImage(config.logoDataUrl, 'PNG', margin, pageHeight - 15, 12, 6); } catch (e) {}
    }
  };

  drawPageDecorations();
  let curY = (config.logoPosition === 'header' && config.logoDataUrl) ? 35 : margin + 10;

  // Title Rendering
  doc.setFontSize(config.fontSize + 14);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(pr, pg, pb);
  const rawTitle = (file.name || 'DOCUMENT').replace('.pdf', '').replace(/_/g, ' ');
  const docTitle = sanitizeForPdf(rawTitle).toUpperCase();
  doc.text(docTitle, margin, curY);
  
  // Aesthetic Rule
  doc.setDrawColor(sr, sg, sb);
  doc.setLineWidth(0.6);
  doc.line(margin, curY + 3, margin + 25, curY + 3);
  curY += 22;

  // Paragraph processing
  const rawParagraphs = file.content.split('\n');
  const standardLineHeight = ptToMm(config.fontSize) * 1.6;

  rawParagraphs.forEach((p) => {
    const text = sanitizeForPdf(p.trim());
    if (text === '') {
      curY += standardLineHeight * 0.5;
      return;
    }

    let fontSize = config.fontSize;
    let fontStyle = "normal";
    let color: [number, number, number] = [26, 26, 26];
    let isBullet = false;
    let extraSpace = 2;

    if (text.startsWith('# ')) {
      fontSize = config.fontSize + 8;
      fontStyle = "bold";
      color = [pr, pg, pb];
      extraSpace = 6;
    } else if (text.startsWith('## ')) {
      fontSize = config.fontSize + 4;
      fontStyle = "bold";
      color = [sr, sg, sb];
      extraSpace = 4;
    } else if (text.startsWith('- ') || text.startsWith('* ')) {
      isBullet = true;
    } else if (text.includes('**')) {
      fontStyle = "bold";
    }

    doc.setFont("helvetica", fontStyle);
    doc.setFontSize(fontSize);
    doc.setTextColor(color[0], color[1], color[2]);

    const cleanText = text.replace(/^#+ /, '').replace(/^[-*] /, '').replace(/\*\*/g, '');
    const currentLineHeight = ptToMm(fontSize) * 1.5;
    
    // We use a slightly smaller width to avoid clipping during rendering
    const wrappedLines = doc.splitTextToSize(cleanText, isBullet ? contentWidth - 10 : contentWidth - 2);

    wrappedLines.forEach((line: string, lIdx: number) => {
      const bottomLimit = pageHeight - margin - 15;
      
      if (curY > bottomLimit) {
        drawFooter();
        doc.addPage();
        drawPageDecorations();
        curY = margin + 15;
        // Re-apply font settings for the new page
        doc.setFont("helvetica", fontStyle);
        doc.setFontSize(fontSize);
        doc.setTextColor(color[0], color[1], color[2]);
      }

      if (isBullet && lIdx === 0) {
        doc.setFillColor(sr, sg, sb);
        doc.circle(margin + 2.5, curY - (ptToMm(fontSize)/2.5), 0.7, 'F');
        doc.text(line, margin + 8, curY);
      } else {
        doc.text(line, isBullet ? margin + 8 : margin, curY);
      }

      curY += currentLineHeight;
    });

    curY += extraSpace;
  });

  drawFooter();

  return doc.output('blob');
};

export const downloadBlob = (blob: Blob, filename: string) => {
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  link.parentNode?.removeChild(link);
  window.URL.revokeObjectURL(url);
};
