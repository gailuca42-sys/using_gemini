
import { GoogleGenAI, Type } from "@google/genai";
import { AIResponse } from "../types";

export const generateFolderContent = async (userPrompt: string): Promise<AIResponse> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following request and generate the content for all requested files.
    User Request: "${userPrompt}"
    
    CRITICAL INSTRUCTIONS:
    1. LANGUAGE: Use the same language as the user (French if the user writes in French).
    2. PDF ENCODING: Use standard French accents (é, à, è, etc.) but AVOID any exotic symbols, emoji, or non-standard mathematical characters that are not found on a standard keyboard.
    3. NO MARKDOWN ARTIFACTS: Do not include strange character sequences like "%4%$" or raw code blocks inside the "content" string unless specifically requested for code files.
    4. STRUCTURE: For PDFs, use clean Markdown (# Title, ## Subtitle, - Bullets).

    Return the result strictly in JSON.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          files: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING, description: "Full filename with extension" },
                type: { type: Type.STRING, description: "File extension" },
                content: { type: Type.STRING, description: "Full text content of the file" },
                style: {
                  type: Type.OBJECT,
                  properties: {
                    primaryColor: { type: Type.STRING },
                    secondaryColor: { type: Type.STRING },
                    backgroundColor: { type: Type.STRING },
                    accentColor: { type: Type.STRING },
                    layoutTheme: { 
                      type: Type.STRING, 
                      enum: ['corporate', 'modern', 'minimalist', 'creative']
                    }
                  },
                  required: ["primaryColor", "secondaryColor", "backgroundColor", "accentColor", "layoutTheme"]
                }
              },
              required: ["name", "type", "content"]
            }
          }
        },
        required: ["files"]
      }
    }
  });

  try {
    const jsonStr = response.text.trim();
    return JSON.parse(jsonStr) as AIResponse;
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    throw new Error("AI returned an invalid data format. Please try again.");
  }
};
