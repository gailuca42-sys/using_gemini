
export enum FileType {
  PDF = 'pdf',
  CSV = 'csv',
  TXT = 'txt',
  JSON = 'json',
  MARKDOWN = 'md',
  HTML = 'html',
  XML = 'xml',
  SQL = 'sql',
  JS = 'js',
  PY = 'py'
}

export interface PdfStyle {
  primaryColor: string;
  secondaryColor: string;
  backgroundColor: string;
  accentColor: string;
  layoutTheme: 'corporate' | 'modern' | 'minimalist' | 'creative';
}

export interface PdfConfig {
  fontSize: number;
  margin: number;
  logoDataUrl: string | null;
  logoPosition: 'header' | 'footer';
}

export interface GeneratedFile {
  name: string;
  type: string; // Changed from FileType enum to string to support any extension
  content: string; // Plain text or formatted string
  style?: PdfStyle; // AI provided styling for PDF
}

export interface GenerationState {
  isGenerating: boolean;
  status: string;
  logs: string[];
  zipUrl: string | null;
  error: string | null;
}

export interface AIResponse {
  files: GeneratedFile[];
}
