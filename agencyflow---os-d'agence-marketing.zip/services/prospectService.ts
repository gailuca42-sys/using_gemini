
import { Prospect, AppData } from '../types';

const STORAGE_KEY = 'agencyflow_data_v3';

/**
 * Charge l'intégralité de la base de données locale
 */
export function loadAppData(): AppData {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return { clients: [], tasks: [], prospects: [] };
  try {
    return JSON.parse(raw);
  } catch (e) {
    console.error("Erreur de lecture localStorage", e);
    return { clients: [], tasks: [], prospects: [] };
  }
}

/**
 * Sauvegarde l'intégralité de la base de données locale
 */
export function saveAppData(data: AppData) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

/**
 * Supprime un prospect par son ID et persiste immédiatement
 */
export function deleteProspectFromStorage(id: string): Prospect[] {
  const current = loadAppData();
  const updatedProspects = current.prospects.filter(p => p.id !== id);
  saveAppData({ ...current, prospects: updatedProspects });
  return updatedProspects;
}
