
import { Prospect } from '../types';

export const calculateProspectScore = (prospect: Prospect): number => {
  let score = 0;

  // 1. Valeur estimée (Max 40 points)
  if (prospect.value >= 50000) score += 40;
  else if (prospect.value >= 20000) score += 30;
  else if (prospect.value >= 10000) score += 20;
  else if (prospect.value >= 5000) score += 10;
  else score += 5;

  // 2. Récence de l'interaction (Max 40 points)
  const lastDate = new Date(prospect.lastInteraction);
  const diffDays = Math.ceil((new Date().getTime() - lastDate.getTime()) / (1000 * 3600 * 24));

  if (diffDays <= 2) score += 40;
  else if (diffDays <= 7) score += 25;
  else if (diffDays <= 14) score += 10;
  else score -= 10; // Pénalité pour prospect "froid" ou négligé

  // 3. Statut (Max 20 points)
  switch (prospect.status) {
    case 'En discussion': score += 20; break;
    case 'Nouveau': score += 15; break;
    case 'Contacté': score += 10; break;
    case 'Perdu': score = 0; break;
    default: score += 5;
  }

  return Math.max(0, Math.min(score, 100));
};

export const getProspectTemperature = (score: number) => {
  if (score >= 70) return { label: 'Chaud', color: 'bg-rose-500', bg: 'bg-rose-50' };
  if (score >= 35) return { label: 'Tiède', color: 'bg-orange-500', bg: 'bg-orange-50' };
  return { label: 'Froid', color: 'bg-blue-500', bg: 'bg-blue-50' };
};
