
import { Client, Task, TaskPriority } from '../types';

export const calculatePriorityScore = (task: Task, client?: Client): number => {
  let score = 0;

  // 1. Deadline urgency (max 50 points)
  const today = new Date();
  const deadline = new Date(task.deadline);
  const diffDays = Math.ceil((deadline.getTime() - today.getTime()) / (1000 * 3600 * 24));

  if (diffDays < 0) score += 50; // Late
  else if (diffDays === 0) score += 45; // Today
  else if (diffDays <= 2) score += 35; // Very soon
  else if (diffDays <= 7) score += 20; // This week
  else score += 5;

  // 2. Client Value (max 30 points)
  if (client) {
    if (client.estimatedValue > 20000) score += 30;
    else if (client.estimatedValue > 10000) score += 20;
    else if (client.estimatedValue > 5000) score += 10;
    else score += 5;
  }

  // 3. Manual override or adjustment (max 20 points)
  if (task.manualPriority) {
    switch (task.manualPriority) {
      case TaskPriority.CRITICAL: score += 20; break;
      case TaskPriority.HIGH: score += 15; break;
      case TaskPriority.MEDIUM: score += 10; break;
      case TaskPriority.LOW: score += 5; break;
    }
  } else {
    score += 10; // Default medium adjustment
  }

  return Math.min(score, 100);
};

export const getPriorityLabelFromScore = (score: number): TaskPriority => {
  if (score >= 80) return TaskPriority.CRITICAL;
  if (score >= 60) return TaskPriority.HIGH;
  if (score >= 35) return TaskPriority.MEDIUM;
  return TaskPriority.LOW;
};
