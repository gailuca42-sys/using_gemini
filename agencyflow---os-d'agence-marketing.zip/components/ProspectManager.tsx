
import React, { useState, useMemo } from 'react';
import { AppData, Prospect, ProspectStatus } from '../types';
import { getProspectTemperature } from '../services/scoringService';
import { Plus, Search, Edit2, Trash2, X, RefreshCw, Calendar, Mail, Phone, DollarSign, Target } from 'lucide-react';

interface ProspectManagerProps {
  data: AppData;
  onSave: (prospect: Omit<Prospect, 'id' | 'createdAt' | 'score'>) => void;
  onDelete: (id: string) => void;
  onConvert: (id: string) => void;
}

const ProspectManager: React.FC<ProspectManagerProps> = ({ data, onSave, onDelete, onConvert }) => {
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Prospect | null>(null);
  const [search, setSearch] = useState('');

  const [formData, setFormData] = useState<Omit<Prospect, 'id' | 'createdAt' | 'score'>>({
    name: '',
    email: '',
    phone: '',
    status: 'Nouveau',
    value: 0,
    lastInteraction: new Date().toISOString().split('T')[0],
    nextAction: '',
    notes: ''
  });

  const sortedProspects = useMemo(() => {
    return [...data.prospects]
      .filter(p => p.name.toLowerCase().includes(search.toLowerCase()))
      .sort((a, b) => b.score - a.score);
  }, [data.prospects, search]);

  const handleOpenEdit = (p: Prospect) => {
    setEditing(p);
    setFormData({ ...p });
    setShowModal(true);
  };

  const handleOpenAdd = () => {
    setEditing(null);
    setFormData({
      name: '', email: '', phone: '', status: 'Nouveau',
      value: 0, lastInteraction: new Date().toISOString().split('T')[0],
      nextAction: '', notes: ''
    });
    setShowModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(editing ? { ...formData, id: editing.id } as any : formData);
    setShowModal(false);
  };

  // LOGIQUE DE SUPPRESSION STRICTE
  const handleDeleteProspect = (id: string) => {
    if (window.confirm('Voulez-vous vraiment supprimer définitivement ce prospect ?')) {
      onDelete(id);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex justify-between items-end">
        <div>
          <p className="text-zinc-500 font-medium mb-1">Acquisition Business</p>
          <h2 className="text-3xl font-bold text-zinc-900">Prospects & Leads</h2>
        </div>
        <button 
          onClick={handleOpenAdd}
          className="bg-zinc-900 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 hover:bg-zinc-800 transition-all shadow-lg active:scale-95 no-print"
        >
          <Plus size={20} /> Nouveau Prospect
        </button>
      </header>

      <div className="bg-white rounded-2xl border border-zinc-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-zinc-100 flex items-center gap-4 bg-zinc-50/50 no-print">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
            <input 
              type="text" 
              placeholder="Rechercher par nom..." 
              value={search} 
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none text-sm font-medium" 
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="text-[10px] uppercase text-zinc-400 font-bold bg-zinc-50">
              <tr>
                <th className="px-6 py-4">Score / Temp.</th>
                <th className="px-6 py-4">Prospect</th>
                <th className="px-6 py-4">Valeur</th>
                <th className="px-6 py-4">Dernier contact</th>
                <th className="px-6 py-4 text-right no-print">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {sortedProspects.length > 0 ? sortedProspects.map(p => {
                const temp = getProspectTemperature(p.score);
                const diffDays = Math.ceil((new Date().getTime() - new Date(p.lastInteraction).getTime()) / (1000 * 3600 * 24));
                const isNeglected = diffDays > 7 && p.status !== 'Perdu';

                return (
                  <tr key={p.id} className="hover:bg-zinc-50/80 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl ${temp.bg} flex items-center justify-center font-bold ${temp.color.replace('bg-', 'text-')}`}>
                          {p.score}
                        </div>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${temp.bg} ${temp.color.replace('bg-', 'text-')} border-current`}>
                          {temp.label}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="font-bold text-zinc-900 text-sm">{p.name}</div>
                        {isNeglected && <div className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" title="Relance nécessaire"></div>}
                      </div>
                      <div className="text-[10px] text-zinc-400 font-medium">{p.email}</div>
                    </td>
                    <td className="px-6 py-4 font-bold text-zinc-700 text-sm">{p.value.toLocaleString()} €</td>
                    <td className="px-6 py-4">
                      <div className="text-xs font-semibold text-zinc-600">{new Date(p.lastInteraction).toLocaleDateString()}</div>
                      <div className="text-[10px] text-zinc-400 italic truncate max-w-[150px]">{p.nextAction || 'Aucune action prévue'}</div>
                    </td>
                    <td className="px-6 py-4 text-right no-print">
                      <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-all">
                        <button onClick={() => onConvert(p.id)} className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors" title="Convertir en client">
                          <RefreshCw size={16} />
                        </button>
                        <button onClick={() => handleOpenEdit(p)} className="p-2 text-zinc-400 hover:text-zinc-900 rounded-lg transition-colors">
                          <Edit2 size={16} />
                        </button>
                        {/* BOUTON SUPPRIMER AVEC BINDING STRICT */}
                        <button 
                          onClick={() => handleDeleteProspect(p.id)} 
                          className="p-2 text-rose-400 hover:text-rose-600 rounded-lg transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              }) : (
                <tr><td colSpan={5} className="px-6 py-12 text-center text-zinc-400 italic">Aucun prospect. Commencez à bâtir votre pipeline.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-zinc-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50/50">
              <h3 className="text-xl font-bold text-zinc-900">{editing ? 'Détails Prospect' : 'Nouveau Prospect'}</h3>
              <button onClick={() => setShowModal(false)} className="text-zinc-400 hover:text-zinc-900 transition-colors"><X size={24} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-8 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2"><Target size={14}/> Nom / Entreprise</label>
                  <input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none font-medium" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2"><DollarSign size={14}/> Valeur Estimée (€)</label>
                  <input type="number" required value={formData.value} onChange={e => setFormData({...formData, value: Number(e.target.value)})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none font-bold" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2"><Mail size={14}/> Email</label>
                  <input type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2"><Phone size={14}/> Téléphone</label>
                  <input value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2"><RefreshCw size={14}/> Statut</label>
                  <select value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as any})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl font-bold outline-none">
                    <option value="Nouveau">Nouveau</option>
                    <option value="Contacté">Contacté</option>
                    <option value="En discussion">En discussion</option>
                    <option value="Perdu">Perdu</option>
                    <option value="Converti">Converti</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2"><Calendar size={14}/> Dernière interaction</label>
                  <input type="date" value={formData.lastInteraction} onChange={e => setFormData({...formData, lastInteraction: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Prochaine action</label>
                <input placeholder="ex: Envoyer le devis final..." value={formData.nextAction} onChange={e => setFormData({...formData, nextAction: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none italic" />
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Notes internes</label>
                <textarea rows={3} value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none resize-none" />
              </div>

              <div className="pt-4 flex gap-3">
                {editing && (
                  <button type="button" onClick={() => handleDeleteProspect(editing.id)} className="flex-1 py-4 bg-rose-50 text-rose-600 font-bold rounded-2xl hover:bg-rose-100 transition-all flex items-center justify-center gap-2"><Trash2 size={18} /> Supprimer</button>
                )}
                <button type="submit" className="flex-[2] py-4 bg-zinc-900 text-white font-bold rounded-2xl hover:bg-zinc-800 shadow-xl active:scale-95 transition-all">Sauvegarder</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProspectManager;
