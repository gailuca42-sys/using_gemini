
import React from 'react';
import { 
  LayoutDashboard, 
  Users, 
  PlusCircle, 
  BarChart3, 
  BookOpen, 
  ShieldCheck,
  LogOut,
  Target,
  Kanban
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onReset?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, onReset }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'prospects', label: 'Prospects', icon: Target },
    { id: 'pipeline', label: 'Pipeline Commercial', icon: Kanban },
    { id: 'clients', label: 'Clients Actifs', icon: Users },
    { id: 'brief', label: 'Nouveau Brief', icon: PlusCircle },
    { id: 'reports', label: 'Analyses', icon: BarChart3 },
    { id: 'docs', label: 'Guide', icon: BookOpen },
  ];

  return (
    <div className="w-64 bg-zinc-900 h-screen text-zinc-400 p-6 flex flex-col no-print shrink-0">
      <div className="mb-10 flex items-center gap-3">
        <div className="bg-white p-2 rounded-lg">
          <ShieldCheck className="text-zinc-900 w-6 h-6" />
        </div>
        <h1 className="text-xl font-semibold text-white tracking-tight font-serif italic">AgencyFlow</h1>
      </div>

      <nav className="flex-1 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                isActive 
                  ? 'bg-white text-zinc-900 shadow-lg' 
                  : 'hover:bg-zinc-800/50 hover:text-zinc-200'
              }`}
            >
              <Icon size={20} />
              <span className="font-bold text-sm tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="pt-6 border-t border-zinc-800 space-y-4">
        <button 
          onClick={onReset}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-rose-500/10 hover:text-rose-400 transition-all text-zinc-600 font-bold text-xs uppercase tracking-widest"
        >
          <LogOut size={16} />
          Quitter l'OS
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
