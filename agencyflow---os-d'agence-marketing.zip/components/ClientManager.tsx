
import React, { useState } from 'react';
import { AppData, Client, ClientStatus } from '../types';
import { Plus, Search, Copy, Check, X, Edit2, Trash2 } from 'lucide-react';

interface ClientManagerProps {
  data: AppData;
  addClient: (client: Omit<Client, 'id' | 'createdAt'>) => void;
  deleteClient: (clientId: string) => void;
  updateClient: (client: Client) => void;
}

const ClientManager: React.FC<ClientManagerProps> = ({ data, addClient, deleteClient, updateClient }) => {
  const [showModal, setShowModal] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [search, setSearch] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState<Omit<Client, 'id' | 'createdAt'>>({
    name: '',
    contact: '',
    email: '',
    status: ClientStatus.LEAD,
    estimatedValue: 0
  });

  const filteredClients = data.clients.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.contact.toLowerCase().includes(search.toLowerCase())
  );

  const handleOpenAdd = () => {
    setEditingClient(null);
    setFormData({ name: '', contact: '', email: '', status: ClientStatus.LEAD, estimatedValue: 0 });
    setShowModal(true);
  };

  const handleOpenEdit = (client: Client) => {
    setEditingClient(client);
    setFormData({ 
      name: client.name, 
      contact: client.contact, 
      email: client.email, 
      status: client.status, 
      estimatedValue: client.estimatedValue 
    });
    setShowModal(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingClient) {
      updateClient({ ...editingClient, ...formData });
    } else {
      addClient(formData);
    }
    setShowModal(false);
  };

  const handleDelete = () => {
    if (editingClient) {
      if (window.confirm("Êtes-vous sûr de vouloir supprimer ce client et toutes ses tâches ?")) {
        deleteClient(editingClient.id);
        setShowModal(false);
      }
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex justify-between items-end">
        <div>
          <p className="text-zinc-500 font-medium mb-1">Portefeuille d'affaires</p>
          <h2 className="text-3xl font-bold text-zinc-900">Clients & Leads</h2>
        </div>
        <button 
          onClick={handleOpenAdd}
          className="bg-zinc-900 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 hover:bg-zinc-800 transition-all shadow-lg active:scale-95 no-print"
        >
          <Plus size={20} />
          Nouveau Client
        </button>
      </header>

      <div className="bg-white rounded-2xl border border-zinc-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-zinc-100 flex items-center gap-4 bg-zinc-50/50 no-print">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
            <input 
              type="text"
              placeholder="Rechercher un client ou contact..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none text-sm font-medium"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="text-[10px] uppercase text-zinc-400 font-bold bg-zinc-50">
              <tr>
                <th className="px-6 py-4">Client</th>
                <th className="px-6 py-4">Statut</th>
                <th className="px-6 py-4">Valeur Estimée</th>
                <th className="px-6 py-4">Contact Principal</th>
                <th className="px-6 py-4 text-right no-print">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {filteredClients.length > 0 ? filteredClients.map((client) => (
                <tr key={client.id} className="hover:bg-zinc-50/80 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="font-bold text-zinc-900 text-sm">{client.name}</div>
                    <div className="text-[10px] text-zinc-500 font-medium">Inscrit le {new Date(client.createdAt).toLocaleDateString('fr-FR')}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${
                      client.status === ClientStatus.ACTIVE ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                      client.status === ClientStatus.LEAD ? 'bg-blue-50 text-blue-700 border-blue-100' :
                      client.status === ClientStatus.ON_HOLD ? 'bg-orange-50 text-orange-700 border-orange-100' :
                      'bg-zinc-100 text-zinc-600 border-zinc-200'
                    }`}>
                      {client.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="font-bold text-zinc-700 text-sm">{client.estimatedValue.toLocaleString()} €</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-semibold text-zinc-700">{client.contact}</div>
                    <div className="flex items-center gap-1.5 mt-1 group cursor-pointer" onClick={() => copyToClipboard(client.email, client.id)}>
                      <span className="text-[10px] text-zinc-400 font-medium group-hover:text-zinc-600 truncate max-w-[150px]">{client.email}</span>
                      {copiedId === client.id ? <Check size={10} className="text-emerald-500" /> : <Copy size={10} className="text-zinc-300 opacity-0 group-hover:opacity-100" />}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right no-print">
                    <button 
                      onClick={() => handleOpenEdit(client)}
                      className="text-zinc-400 hover:text-zinc-900 p-2 transition-all opacity-0 group-hover:opacity-100"
                    >
                      <Edit2 size={16} />
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-zinc-400 italic font-medium">
                    Aucun client trouvé. Cliquez sur "Nouveau Client" pour commencer.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-zinc-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 no-print">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50/50">
              <h3 className="text-xl font-bold text-zinc-900">{editingClient ? 'Modifier Client' : 'Nouveau Client'}</h3>
              <button onClick={() => setShowModal(false)} className="text-zinc-400 hover:text-zinc-900 transition-colors">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-8 space-y-5">
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Nom de l'entreprise</label>
                <input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none font-medium" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Contact</label>
                  <input required value={formData.contact} onChange={e => setFormData({...formData, contact: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none font-medium" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Email</label>
                  <input required type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none font-medium" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Statut</label>
                  <select value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as ClientStatus})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none font-bold">
                    {Object.values(ClientStatus).map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Valeur (€)</label>
                  <input required type="number" value={formData.estimatedValue} onChange={e => setFormData({...formData, estimatedValue: Number(e.target.value)})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none font-medium" />
                </div>
              </div>
              <div className="pt-4 flex gap-3">
                {editingClient && (
                  <button 
                    type="button"
                    onClick={handleDelete}
                    className="flex-1 py-4 bg-rose-50 text-rose-600 font-bold rounded-2xl hover:bg-rose-100 transition-all flex items-center justify-center gap-2"
                  >
                    <Trash2 size={18} />
                    Supprimer
                  </button>
                )}
                <button type="submit" className="flex-[2] py-4 bg-zinc-900 text-white font-bold rounded-2xl hover:bg-zinc-800 transition-all shadow-xl active:scale-95">
                  {editingClient ? 'Enregistrer' : 'Ajouter le Client'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClientManager;
