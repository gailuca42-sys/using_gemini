
import React, { useState, useMemo } from 'react';
import { AppData, TaskStatus, TaskPriority, Task } from '../types';
import { TASK_TYPES } from '../constants';
import { AlertCircle, Clock, CheckCircle2, LayoutDashboard, Edit2, X, Trash2, Calendar, FileText, Target, TrendingUp, Wallet } from 'lucide-react';
import { getPriorityLabelFromScore } from '../services/priorityService';

interface DashboardProps {
  data: AppData;
  updateTaskStatus: (taskId: string, status: TaskStatus) => void;
  deleteTask: (taskId: string) => void;
  updateTask: (task: Task) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ data, updateTaskStatus, deleteTask, updateTask }) => {
  const [filter, setFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'priority' | 'deadline'>('priority');
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const pipelineValue = useMemo(() => {
    // Fix: Prospect has 'value' property instead of 'estimatedValue'
    return data.prospects.reduce((sum, p) => sum + p.value, 0);
  }, [data.prospects]);

  const activeRevenue = useMemo(() => {
    return data.clients.reduce((sum, c) => sum + c.estimatedValue, 0);
  }, [data.clients]);

  const filteredTasks = useMemo(() => {
    let tasks = [...data.tasks];
    if (filter !== 'all') tasks = tasks.filter(t => t.status === filter);
    return tasks.sort((a, b) => {
      if (sortBy === 'priority') return b.calculatedPriorityScore - a.calculatedPriorityScore;
      return new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
    });
  }, [data.tasks, filter, sortBy]);

  const stats = {
    totalTasks: data.tasks.length,
    activeClients: data.clients.length,
    hotProspects: data.prospects.filter(p => p.score >= 70).length,
    urgentTasks: data.tasks.filter(t => t.calculatedPriorityScore > 75 && t.status !== TaskStatus.DONE).length,
  };

  const getPriorityColor = (score: number) => {
    if (score >= 80) return 'bg-rose-50 text-rose-700 border-rose-200';
    if (score >= 60) return 'bg-orange-50 text-orange-700 border-orange-200';
    if (score >= 35) return 'bg-blue-50 text-blue-700 border-blue-200';
    return 'bg-zinc-50 text-zinc-600 border-zinc-200';
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex justify-between items-end">
        <div>
          <p className="text-zinc-500 font-medium mb-1">Bienvenue dans l'OS</p>
          <h2 className="text-3xl font-bold text-zinc-900">Dashboard Business</h2>
        </div>
      </header>

      {/* Business Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-zinc-900 p-8 rounded-[2rem] text-white shadow-2xl relative overflow-hidden group">
          <Wallet className="absolute -right-4 -bottom-4 text-white/10 group-hover:scale-110 transition-transform" size={140} />
          <p className="text-zinc-400 text-xs font-bold uppercase tracking-widest mb-2">Valeur du Pipeline</p>
          <p className="text-4xl font-serif font-bold italic mb-6">{pipelineValue.toLocaleString()} €</p>
          <div className="flex items-center gap-2 text-xs font-medium text-zinc-400 bg-zinc-800/50 w-fit px-3 py-1.5 rounded-full">
            <Target size={14} className="text-emerald-400" /> {data.prospects.length} Opportunités en cours
          </div>
        </div>

        <div className="bg-white p-8 rounded-[2rem] border border-zinc-100 shadow-sm flex flex-col justify-between">
          <div>
            <p className="text-zinc-400 text-xs font-bold uppercase tracking-widest mb-2">Portefeuille Actif</p>
            <p className="text-4xl font-serif font-bold text-zinc-900 mb-6">{activeRevenue.toLocaleString()} €</p>
          </div>
          <div className="flex items-center gap-2 text-xs font-medium text-zinc-500 bg-zinc-50 w-fit px-3 py-1.5 rounded-full">
            <TrendingUp size={14} className="text-blue-500" /> {stats.activeClients} Clients signés
          </div>
        </div>

        <div className="bg-white p-8 rounded-[2rem] border border-zinc-100 shadow-sm flex flex-col justify-between">
          <div>
            <p className="text-zinc-400 text-xs font-bold uppercase tracking-widest mb-2">Priorités Critique</p>
            <p className="text-4xl font-serif font-bold text-zinc-900 mb-6">{stats.urgentTasks + stats.hotProspects}</p>
          </div>
          <div className="flex gap-2">
            <span className="text-[10px] font-bold px-2 py-1 rounded-md bg-rose-50 text-rose-600 border border-rose-100">{stats.hotProspects} Prospects chauds</span>
            <span className="text-[10px] font-bold px-2 py-1 rounded-md bg-orange-50 text-orange-600 border border-orange-100">{stats.urgentTasks} Tâches urgentes</span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-zinc-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50/50">
          <h3 className="font-serif text-xl font-semibold text-zinc-800 flex items-center gap-3">
             <LayoutDashboard size={20} className="text-zinc-400" /> Flux de Travail
          </h3>
          <select 
            value={filter} 
            onChange={(e) => setFilter(e.target.value)}
            className="bg-white border border-zinc-200 rounded-lg text-sm px-3 py-2 outline-none font-bold text-zinc-900 shadow-sm no-print"
          >
            <option value="all">Toutes les tâches</option>
            {Object.values(TaskStatus).map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="text-[10px] uppercase text-zinc-400 font-bold bg-zinc-50">
              <tr>
                <th className="px-6 py-4">Priorité</th>
                <th className="px-6 py-4">Tâche</th>
                <th className="px-6 py-4">Client</th>
                <th className="px-6 py-4">Deadline</th>
                <th className="px-6 py-4">Statut</th>
                <th className="px-6 py-4 text-right no-print">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {filteredTasks.length > 0 ? filteredTasks.map((task) => {
                const client = data.clients.find(c => c.id === task.clientId);
                return (
                  <tr key={task.id} className="hover:bg-zinc-50/80 transition-colors group">
                    <td className="px-6 py-4">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border ${getPriorityColor(task.calculatedPriorityScore)}`}>
                        {getPriorityLabelFromScore(task.calculatedPriorityScore)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-bold text-zinc-900 text-sm">{task.title}</div>
                      <div className="text-[10px] text-zinc-400 font-medium italic">{task.type}</div>
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-zinc-700">{client?.name || 'Inconnu'}</td>
                    <td className="px-6 py-4 text-xs font-medium text-zinc-600">
                      <div className="flex items-center gap-1.5">
                        <Clock size={12} />
                        {new Date(task.deadline).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <select 
                        value={task.status}
                        onChange={(e) => updateTaskStatus(task.id, e.target.value as TaskStatus)}
                        className={`text-[10px] font-bold px-2 py-1 rounded-md border-0 bg-zinc-100 cursor-pointer text-zinc-900 outline-none focus:ring-1 focus:ring-zinc-900 ${
                          task.status === TaskStatus.DONE ? 'bg-emerald-50 text-emerald-700' : 
                          task.status === TaskStatus.OVERDUE ? 'bg-rose-50 text-rose-700' : ''
                        }`}
                      >
                        {Object.values(TaskStatus).map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </td>
                    <td className="px-6 py-4 text-right no-print">
                      <button 
                        onClick={() => setEditingTask(task)}
                        className="text-zinc-400 hover:text-zinc-900 p-2 transition-all opacity-0 group-hover:opacity-100"
                      >
                        <Edit2 size={16} />
                      </button>
                    </td>
                  </tr>
                );
              }) : (
                <tr><td colSpan={6} className="px-6 py-12 text-center text-zinc-500 italic">Aucune tâche en attente. Prenez une pause !</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {editingTask && (
        <div className="fixed inset-0 bg-zinc-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="p-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50/50">
              <h3 className="text-xl font-bold text-zinc-900">Modifier Tâche</h3>
              <button onClick={() => setEditingTask(null)} className="text-zinc-400 hover:text-zinc-900">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={(e) => { e.preventDefault(); updateTask(editingTask); setEditingTask(null); }} className="p-8 space-y-5">
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Client</label>
                <select value={editingTask.clientId} onChange={e => setEditingTask({...editingTask, clientId: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none font-bold">
                  {data.clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Titre</label>
                <input required value={editingTask.title} onChange={e => setEditingTask({...editingTask, title: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none font-medium" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Deadline</label>
                  <input type="date" value={editingTask.deadline} onChange={e => setEditingTask({...editingTask, deadline: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Type</label>
                  <select value={editingTask.type} onChange={e => setEditingTask({...editingTask, type: e.target.value})} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl outline-none font-bold">
                    {TASK_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => { if(window.confirm('Supprimer cette tâche ?')) { deleteTask(editingTask.id); setEditingTask(null); }}} className="flex-1 py-4 bg-rose-50 text-rose-600 font-bold rounded-2xl hover:bg-rose-100 flex items-center justify-center gap-2 transition-all"><Trash2 size={18} /> Supprimer</button>
                <button type="submit" className="flex-[2] py-4 bg-zinc-900 text-white font-bold rounded-2xl hover:bg-zinc-800 shadow-xl transition-all">Sauvegarder</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
