
import React, { useMemo } from 'react';
import { AppData, Prospect } from '../types';
import { getProspectTemperature } from '../services/scoringService';
import { Flame, Thermometer, Snowflake, RefreshCw, DollarSign } from 'lucide-react';

interface PipelineProps {
  data: AppData;
  onConvert: (id: string) => void;
}

const Pipeline: React.FC<PipelineProps> = ({ data, onConvert }) => {
  const categories = useMemo(() => {
    const hot: Prospect[] = [];
    const warm: Prospect[] = [];
    const cold: Prospect[] = [];

    data.prospects.forEach(p => {
      const score = p.score;
      if (score >= 70) hot.push(p);
      else if (score >= 35) warm.push(p);
      else cold.push(p);
    });

    const sort = (arr: Prospect[]) => arr.sort((a, b) => b.score - a.score);
    return { hot: sort(hot), warm: sort(warm), cold: sort(cold) };
  }, [data.prospects]);

  const Column = ({ title, icon: Icon, prospects, color, bg }: { title: string, icon: any, prospects: Prospect[], color: string, bg: string }) => (
    <div className={`flex-1 min-w-[300px] flex flex-col gap-6 p-4 rounded-3xl ${bg} border border-zinc-100/50`}>
      <header className="flex justify-between items-center px-2">
        <div className={`flex items-center gap-2 ${color} font-serif font-bold text-xl`}>
          <Icon size={20} />
          {title}
        </div>
        <span className="bg-white px-2.5 py-1 rounded-full text-xs font-bold text-zinc-400 border border-zinc-100">
          {prospects.length}
        </span>
      </header>

      <div className="flex flex-col gap-4 overflow-y-auto max-h-[70vh] pr-1">
        {prospects.map(p => (
          <div key={p.id} className="bg-white p-5 rounded-2xl border border-zinc-100 shadow-sm hover:shadow-md transition-all group">
            <div className="flex justify-between items-start mb-3">
              <h4 className="font-bold text-zinc-900 leading-tight">{p.name}</h4>
              <span className="text-xs font-bold text-zinc-400">{p.score} pt</span>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-600 font-bold text-sm mb-4">
              <DollarSign size={14} />
              {/* Fix: Prospect has 'value' property instead of 'estimatedValue' */}
              {p.value.toLocaleString()} €
            </div>
            <div className="flex justify-between items-center border-t border-zinc-50 pt-3">
              <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                {new Date(p.lastInteraction).toLocaleDateString()}
              </span>
              <button 
                onClick={() => onConvert(p.id)}
                className="opacity-0 group-hover:opacity-100 flex items-center gap-1.5 text-[10px] font-bold text-emerald-600 hover:text-emerald-700 transition-all uppercase"
              >
                Convertir <RefreshCw size={12} />
              </button>
            </div>
          </div>
        ))}
        {prospects.length === 0 && (
          <div className="h-32 border-2 border-dashed border-zinc-200/50 rounded-2xl flex items-center justify-center text-zinc-300 text-sm font-medium italic">
            Aucun prospect
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header>
        <p className="text-zinc-500 font-medium mb-1">Visualisation du Flux</p>
        <h2 className="text-3xl font-bold text-zinc-900">Pipeline Automatique</h2>
      </header>

      <div className="flex flex-col lg:flex-row gap-8 items-stretch">
        <Column title="Opportunités Chaudes" icon={Flame} prospects={categories.hot} color="text-rose-600" bg="bg-rose-50/30" />
        <Column title="Suivis en cours" icon={Thermometer} prospects={categories.warm} color="text-orange-600" bg="bg-orange-50/30" />
        <Column title="Nouveaux / Froids" icon={Snowflake} prospects={categories.cold} color="text-blue-600" bg="bg-blue-50/30" />
      </div>
    </div>
  );
};

export default Pipeline;
