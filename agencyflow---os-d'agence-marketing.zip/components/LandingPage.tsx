
import React from 'react';
import { ShieldCheck, Zap, BarChart3, Users, ChevronRight } from 'lucide-react';

interface LandingPageProps {
  onStart: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  return (
    <div className="min-h-screen bg-white text-zinc-900 overflow-x-hidden">
      {/* Navbar */}
      <nav className="max-w-7xl mx-auto px-6 py-8 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="bg-zinc-900 p-2 rounded-lg">
            <ShieldCheck className="text-white w-5 h-5" />
          </div>
          <span className="text-xl font-bold tracking-tight">AgencyFlow</span>
        </div>
        <button 
          onClick={onStart}
          className="bg-zinc-900 text-white px-6 py-2.5 rounded-full font-bold hover:scale-105 transition-all active:scale-95 text-sm"
        >
          Accéder à l'OS
        </button>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 pt-20 pb-32 text-center">
        <div className="inline-flex items-center gap-2 bg-zinc-100 px-4 py-2 rounded-full text-xs font-bold mb-8 animate-bounce">
          <Zap size={14} className="text-zinc-900" />
          <span>V2.0 Maintenant disponible</span>
        </div>
        <h1 className="text-6xl md:text-8xl font-serif font-bold tracking-tight mb-8 leading-[1.1]">
          L'OS ultime pour les <br /> 
          <span className="italic text-zinc-400">agences créatives.</span>
        </h1>
        <p className="max-w-2xl mx-auto text-xl text-zinc-500 mb-12 font-medium">
          Gérez vos clients, automatisez votre priorisation et générez des rapports en un clic. Le tout, stocké localement, sans serveur.
        </p>
        <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
          <button 
            onClick={onStart}
            className="group bg-zinc-900 text-white px-8 py-5 rounded-2xl font-bold text-lg flex items-center gap-3 hover:shadow-2xl transition-all active:scale-95"
          >
            Démarrer l'aventure
            <ChevronRight className="group-hover:translate-x-1 transition-transform" />
          </button>
          <p className="text-zinc-400 text-sm font-medium">Aucun compte requis. 100% Gratuit.</p>
        </div>
      </section>

      {/* Bento Grid Features */}
      <section className="bg-zinc-50 py-32 border-y border-zinc-100">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-10 rounded-[2.5rem] border border-zinc-100 shadow-sm hover:shadow-xl transition-all">
              <Users className="text-zinc-900 mb-6" size={32} />
              <h3 className="text-2xl font-serif font-bold mb-4">CRM Minimaliste</h3>
              <p className="text-zinc-500 font-medium">Suivez vos leads et clients actifs avec une clarté absolue sur leur valeur business.</p>
            </div>
            <div className="bg-zinc-900 p-10 rounded-[2.5rem] text-white shadow-2xl scale-105">
              <Zap className="text-white mb-6" size={32} />
              <h3 className="text-2xl font-serif font-bold mb-4">Smart Tasking</h3>
              <p className="text-zinc-400 font-medium">Notre algorithme calcule la priorité pour vous selon l'urgence et la valeur client.</p>
            </div>
            <div className="bg-white p-10 rounded-[2.5rem] border border-zinc-100 shadow-sm hover:shadow-xl transition-all">
              <BarChart3 className="text-zinc-900 mb-6" size={32} />
              <h3 className="text-2xl font-serif font-bold mb-4">Rapports Live</h3>
              <p className="text-zinc-500 font-medium">Visualisez la charge de travail de votre équipe et exportez vos données en CSV instantanément.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 text-center text-zinc-400 font-medium border-t border-zinc-100">
        <p>© 2025 AgencyFlow — Conçu pour l'excellence opérationnelle.</p>
      </footer>
    </div>
  );
};

export default LandingPage;
