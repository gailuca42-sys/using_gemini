
import React from 'react';
import { Book, HelpCircle, Key, Zap, CheckCircle } from 'lucide-react';

const Documentation: React.FC = () => {
  const sections = [
    {
      title: "Gestion des Clients",
      icon: <Book size={20} />,
      content: "Pour ajouter un client, rendez-vous dans l'onglet 'Clients & Leads'. Chaque client possède une valeur estimée qui influence directement la priorité des tâches qui lui sont associées."
    },
    {
      title: "Priorisation Intelligente",
      icon: <Zap size={20} />,
      content: "Notre algorithme calcule un score de 0 à 100 basé sur la deadline, la valeur du client et la priorité manuelle éventuelle. Les scores > 80 sont considérés comme Critiques."
    },
    {
      title: "Rapports & Exports",
      icon: <CheckCircle size={20} />,
      content: "Vous pouvez exporter toutes vos données en CSV pour Excel ou imprimer un rapport PDF formaté pour vos réunions d'agence via l'onglet 'Rapports'."
    },
    {
      title: "Maintenance Zéro",
      icon: <Key size={20} />,
      content: "L'application fonctionne entièrement dans votre navigateur. Les données sont stockées localement dans votre cache. Pensez à faire un export CSV régulier pour sauvegarder vos données."
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-12 animate-in fade-in duration-500">
      <header>
        <h2 className="text-3xl font-bold text-zinc-900 mb-2">Guide d'utilisation</h2>
        <p className="text-zinc-500">Apprenez à tirer le meilleur parti de AgencyFlow.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {sections.map((section, i) => (
          <div key={i} className="bg-white p-8 rounded-3xl border border-zinc-100 shadow-sm">
            <div className="w-10 h-10 bg-zinc-900 text-white rounded-xl flex items-center justify-center mb-6 shadow-lg">
              {section.icon}
            </div>
            <h3 className="font-serif text-xl font-bold mb-3">{section.title}</h3>
            <p className="text-zinc-600 leading-relaxed text-sm">
              {section.content}
            </p>
          </div>
        ))}
      </div>

      <div className="bg-blue-50 border border-blue-100 p-8 rounded-3xl flex gap-6 items-start">
        <div className="p-3 bg-blue-100 text-blue-600 rounded-2xl">
          <HelpCircle size={24} />
        </div>
        <div>
          <h4 className="font-bold text-blue-900 text-lg mb-2">Besoin de modifier le code ?</h4>
          <p className="text-blue-700 text-sm leading-relaxed">
            AgencyFlow est bâti avec React, Tailwind CSS et Lucide Icons. Vous pouvez modifier les constantes dans <code className="bg-blue-200/50 px-1 rounded">constants.tsx</code> pour changer les types de tâches par défaut ou les paliers de valeur client.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Documentation;
