
import React, { useMemo } from 'react';
import { AppData, TaskStatus } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { Download as DownloadIcon, TrendingUp as TrendingIcon, PieChart as PieChartIcon } from 'lucide-react';

interface ReportsProps {
  data: AppData;
}

const Reports: React.FC<ReportsProps> = ({ data }) => {
  const chartData = useMemo(() => [
    { name: 'À faire', value: data.tasks.filter(t => t.status === TaskStatus.TODO).length, color: '#94a3b8' },
    { name: 'En cours', value: data.tasks.filter(t => t.status === TaskStatus.IN_PROGRESS).length, color: '#3b82f6' },
    { name: 'Terminé', value: data.tasks.filter(t => t.status === TaskStatus.DONE).length, color: '#10b981' },
    { name: 'En retard', value: data.tasks.filter(t => t.status === TaskStatus.OVERDUE).length, color: '#f43f5e' },
  ], [data.tasks]);

  const exportToCSV = (e: React.MouseEvent) => {
    e.preventDefault();
    const headers = ['Client', 'Tâche', 'Type', 'Deadline', 'Statut', 'Priorité Score'];
    const rows = data.tasks.map(t => {
      const client = data.clients.find(c => c.id === t.clientId);
      return [
        `"${client?.name || 'Inconnu'}"`,
        `"${t.title}"`,
        `"${t.type}"`,
        t.deadline,
        t.status,
        t.calculatedPriorityScore
      ].join(',');
    });
    
    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `agencyflow_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex justify-between items-end no-print">
        <div>
          <p className="text-zinc-500 font-medium mb-1">Analyse & Exports</p>
          <h2 className="text-3xl font-bold text-zinc-900">Rapports Automatiques</h2>
        </div>
        <div className="flex gap-3">
          <button 
            type="button"
            onClick={exportToCSV}
            className="bg-white border border-zinc-200 text-zinc-700 px-4 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-zinc-50 transition-all shadow-sm active:scale-95"
          >
            <DownloadIcon size={18} />
            CSV
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl border border-zinc-100 shadow-sm flex flex-col">
          <div className="flex items-center gap-3 mb-8">
            <PieChartIcon className="text-zinc-400" size={20} />
            <h3 className="font-serif text-xl font-bold">Répartition des charges</h3>
          </div>
          {/* Correction ici : ajout de min-h et minWidth={0} */}
          <div className="h-64 w-full min-h-[256px]">
            <ResponsiveContainer width="100%" height="100%" minWidth={0}>
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                  isAnimationActive={false}
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-4 mt-6">
            {chartData.map(status => (
              <div key={status.name} className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: status.color }}></div>
                <span className="text-xs text-zinc-600 font-bold">{status.name}: {status.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-zinc-100 shadow-sm flex flex-col">
          <div className="flex items-center gap-3 mb-8">
            <TrendingIcon className="text-zinc-400" size={20} />
            <h3 className="font-serif text-xl font-bold">Performance par Statut</h3>
          </div>
          {/* Correction ici : ajout de min-h et minWidth={0} */}
          <div className="h-64 w-full min-h-[256px]">
             <ResponsiveContainer width="100%" height="100%" minWidth={0}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 700}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 700}} />
                <Tooltip cursor={{fill: '#f8fafc'}} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]} isAnimationActive={false}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-3xl border border-zinc-100 shadow-sm">
        <h3 className="font-serif text-xl font-bold mb-6">Performance Clients</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-zinc-50 border-y border-zinc-100">
              <tr>
                <th className="px-6 py-4 text-left text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Client</th>
                <th className="px-6 py-4 text-left text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Valeur</th>
                <th className="px-6 py-4 text-center text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Tâches</th>
                <th className="px-6 py-4 text-center text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Complétion</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-50">
              {data.clients.map(client => {
                const clientTasks = data.tasks.filter(t => t.clientId === client.id);
                const completed = clientTasks.filter(t => t.status === TaskStatus.DONE).length;
                const progress = clientTasks.length > 0 ? (completed / clientTasks.length) * 100 : 0;
                
                return (
                  <tr key={client.id} className="hover:bg-zinc-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-bold text-zinc-900 text-sm">{client.name}</div>
                      <div className="text-[10px] text-zinc-400 font-medium">{client.contact}</div>
                    </td>
                    <td className="px-6 py-4 font-bold text-zinc-700 text-sm">{client.estimatedValue.toLocaleString()} €</td>
                    <td className="px-6 py-4 text-center font-bold text-zinc-900">{clientTasks.length}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="flex-1 h-1.5 bg-zinc-100 rounded-full overflow-hidden">
                          <div className="h-full bg-zinc-900 rounded-full transition-all duration-500" style={{ width: `${progress}%` }}></div>
                        </div>
                        <span className="text-[10px] font-bold text-zinc-900 w-8">{Math.round(progress)}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Reports;
