
import React, { useState } from 'react';
import { AppData, Task, TaskPriority, TaskStatus } from '../types';
import { TASK_TYPES } from '../constants';
import { Send, Zap, Calendar, Info } from 'lucide-react';

interface TaskFormProps {
  data: AppData;
  addTask: (task: Omit<Task, 'id' | 'createdAt' | 'calculatedPriorityScore'>) => void;
}

const TaskForm: React.FC<TaskFormProps> = ({ data, addTask }) => {
  const [formData, setFormData] = useState<Omit<Task, 'id' | 'createdAt' | 'calculatedPriorityScore' | 'status'>>({
    clientId: data.clients[0]?.id || '',
    title: '',
    description: '',
    type: TASK_TYPES[0],
    deadline: new Date().toISOString().split('T')[0],
    manualPriority: undefined
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addTask({ ...formData, status: TaskStatus.TODO });
    setFormData({
      clientId: data.clients[0]?.id || '',
      title: '',
      description: '',
      type: TASK_TYPES[0],
      deadline: new Date().toISOString().split('T')[0],
      manualPriority: undefined
    });
    alert('Brief créé ! La tâche a été ajoutée et priorisée intelligemment.');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <header className="text-center">
        <div className="inline-flex p-3 bg-zinc-900 rounded-2xl mb-4 shadow-xl">
          <Zap className="text-white w-6 h-6" />
        </div>
        <h2 className="text-3xl font-bold text-zinc-900">Brief Rapide</h2>
        <p className="text-zinc-500 mt-2">Créez une tâche en quelques secondes. Notre algorithme s'occupe de la priorité.</p>
      </header>

      <div className="bg-white p-8 rounded-3xl border border-zinc-100 shadow-xl">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-500 uppercase flex items-center gap-2">
                Client associé
              </label>
              <select 
                required
                value={formData.clientId}
                onChange={e => setFormData({...formData, clientId: e.target.value})}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none text-zinc-900 font-semibold"
              >
                {data.clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-500 uppercase">Type de prestation</label>
              <select 
                value={formData.type}
                onChange={e => setFormData({...formData, type: e.target.value})}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none text-zinc-900 font-semibold"
              >
                {TASK_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-zinc-500 uppercase">Intitulé de la tâche</label>
            <input 
              required
              value={formData.title}
              onChange={e => setFormData({...formData, title: e.target.value})}
              className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none text-zinc-900"
              placeholder="ex: Rédaction newsletter hebdomadaire"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-zinc-500 uppercase">Description détaillée</label>
            <textarea 
              rows={3}
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
              className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none text-zinc-900 resize-none"
              placeholder="Précisez les objectifs, ressources et points d'attention..."
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-500 uppercase flex items-center gap-2">
                <Calendar size={14} /> Deadline
              </label>
              <input 
                required
                type="date"
                value={formData.deadline}
                onChange={e => setFormData({...formData, deadline: e.target.value})}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none text-zinc-900"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-500 uppercase flex items-center gap-2">
                Priorité manuelle (optionnel)
              </label>
              <select 
                value={formData.manualPriority || ''}
                onChange={e => setFormData({...formData, manualPriority: e.target.value as TaskPriority || undefined})}
                className="w-full px-4 py-3 bg-zinc-50 border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 outline-none text-zinc-900 font-semibold"
              >
                <option value="">Laisser le système décider ✨</option>
                {Object.values(TaskPriority).map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>

          <div className="pt-6">
            <button 
              type="submit"
              className="w-full py-4 bg-zinc-900 text-white font-bold rounded-2xl flex items-center justify-center gap-3 hover:bg-zinc-800 transition-all shadow-xl active:scale-95 group"
            >
              Envoyer le Brief
              <Send size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
            </button>
            <div className="mt-4 flex items-center gap-2 text-zinc-400 text-[10px] justify-center font-medium">
              <Info size={12} />
              <span>Priorisation automatique basée sur l'urgence et la valeur client.</span>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TaskForm;
