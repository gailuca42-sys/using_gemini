
export enum ClientStatus {
  LEAD = 'Lead',
  ACTIVE = 'Actif',
  ON_HOLD = 'En Pause',
  COMPLETED = 'Terminé'
}

export type ProspectStatus = 'Nouveau' | 'Contacté' | 'En discussion' | 'Perdu' | 'Converti';

export enum TaskStatus {
  TODO = 'À faire',
  IN_PROGRESS = 'En cours',
  DONE = 'Terminé',
  OVERDUE = 'En retard'
}

export enum TaskPriority {
  LOW = 'Basse',
  MEDIUM = 'Moyenne',
  HIGH = 'Haute',
  CRITICAL = 'Critique'
}

export interface Prospect {
  id: string;
  name: string;
  email: string;
  phone?: string;
  status: ProspectStatus;
  value: number; // Changé de estimatedValue à value pour respect strict
  lastInteraction: string; // ISO Date
  nextAction: string;
  notes?: string;
  createdAt: string;
  score: number;
}

export interface Client {
  id: string;
  name: string;
  contact: string;
  email: string;
  status: ClientStatus;
  estimatedValue: number;
  createdAt: string;
  notes?: string;
}

export interface Task {
  id: string;
  clientId: string;
  title: string;
  description: string;
  type: string;
  deadline: string;
  manualPriority?: TaskPriority;
  calculatedPriorityScore: number;
  status: TaskStatus;
  createdAt: string;
}

export interface AppData {
  clients: Client[];
  tasks: Task[];
  prospects: Prospect[];
}
