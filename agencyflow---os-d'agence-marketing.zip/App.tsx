
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { AppData, Client, Task, TaskStatus, Prospect, ClientStatus } from './types';
import { INITIAL_DATA } from './constants';
import { calculatePriorityScore } from './services/priorityService';
import { calculateProspectScore } from './services/scoringService';
import { loadAppData, saveAppData } from './services/prospectService';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import ClientManager from './components/ClientManager';
import ProspectManager from './components/ProspectManager';
import Pipeline from './components/Pipeline';
import TaskForm from './components/TaskForm';
import Reports from './components/Reports';
import Documentation from './components/Documentation';
import LandingPage from './components/LandingPage';
import { Bell } from 'lucide-react';

const App: React.FC = () => {
  const [hasStarted, setHasStarted] = useState<boolean>(() => localStorage.getItem('agencyflow_started') === 'true');
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  
  // Montage unique du state à partir du storage
  const [data, setData] = useState<AppData>(() => loadAppData());

  // Sauvegarde automatique sur chaque changement du state complet
  useEffect(() => {
    saveAppData(data);
  }, [data]);

  const handleStart = () => {
    setHasStarted(true);
    localStorage.setItem('agencyflow_started', 'true');
  };

  // --- PROSPECTS LOGIC ---
  const saveProspect = useCallback((prospectInput: Omit<Prospect, 'id' | 'createdAt' | 'score'>) => {
    setData(prev => {
      const id = (prospectInput as any).id || `p_${Date.now()}`;
      const isNew = !(prospectInput as any).id;
      
      const newProspect: Prospect = {
        ...prospectInput,
        id,
        createdAt: isNew ? new Date().toISOString() : (prev.prospects.find(p => p.id === id)?.createdAt || new Date().toISOString()),
        score: 0
      };
      newProspect.score = calculateProspectScore(newProspect);

      const updatedProspects = isNew 
        ? [newProspect, ...prev.prospects]
        : prev.prospects.map(p => p.id === id ? newProspect : p);

      return { ...prev, prospects: updatedProspects };
    });
  }, []);

  // SUPPRESSION ATOMIQUE ET PERSISTANTE
  const deleteProspect = useCallback((id: string) => {
    setData(prev => {
      const updated = prev.prospects.filter(p => p.id !== id);
      const newData = { ...prev, prospects: updated };
      saveAppData(newData); // Persistance immédiate pour éviter tout rebond au refresh
      return newData;
    });
  }, []);

  const convertProspectToClient = useCallback((prospectId: string) => {
    setData(prev => {
      const prospect = prev.prospects.find(p => p.id === prospectId);
      if (!prospect) return prev;

      const newClient: Client = {
        id: `c_${Date.now()}`,
        name: prospect.name,
        contact: prospect.name,
        email: prospect.email,
        status: ClientStatus.ACTIVE,
        estimatedValue: prospect.value,
        createdAt: new Date().toISOString(),
        notes: `Converti du pipeline le ${new Date().toLocaleDateString()}. Notes prospect : ${prospect.notes || ''}`
      };

      const newData = {
        ...prev,
        clients: [newClient, ...prev.clients],
        prospects: prev.prospects.filter(p => p.id !== prospectId)
      };
      saveAppData(newData);
      return newData;
    });
    setActiveTab('clients');
  }, []);

  // --- REST OF THE LOGIC ---
  const deleteClient = useCallback((clientId: string) => {
    setData(prev => {
      const newData = {
        ...prev,
        clients: prev.clients.filter(c => c.id !== clientId),
        tasks: prev.tasks.filter(t => t.clientId !== clientId)
      };
      saveAppData(newData);
      return newData;
    });
  }, []);

  const updateClient = useCallback((updatedClient: Client) => {
    setData(prev => ({
      ...prev,
      clients: prev.clients.map(c => c.id === updatedClient.id ? updatedClient : c),
      tasks: prev.tasks.map(t => t.clientId === updatedClient.id ? { ...t, calculatedPriorityScore: calculatePriorityScore(t, updatedClient) } : t)
    }));
  }, []);

  const addClient = useCallback((client: Omit<Client, 'id' | 'createdAt'>) => {
    const newClient: Client = { ...client, id: `c_${Date.now()}`, createdAt: new Date().toISOString() };
    setData(prev => ({ ...prev, clients: [...prev.clients, newClient] }));
  }, []);

  const updateTaskStatus = useCallback((taskId: string, status: TaskStatus) => {
    setData(prev => ({ ...prev, tasks: prev.tasks.map(t => t.id === taskId ? { ...t, status } : t) }));
  }, []);

  const deleteTask = useCallback((taskId: string) => {
    setData(prev => ({ ...prev, tasks: prev.tasks.filter(t => t.id !== taskId) }));
  }, []);

  const updateTask = useCallback((updatedTask: Task) => {
    const client = data.clients.find(c => c.id === updatedTask.clientId);
    const score = calculatePriorityScore(updatedTask, client);
    setData(prev => ({ ...prev, tasks: prev.tasks.map(t => t.id === updatedTask.id ? { ...updatedTask, calculatedPriorityScore: score } : t) }));
  }, [data.clients]);

  const addTask = useCallback((taskInput: Omit<Task, 'id' | 'createdAt' | 'calculatedPriorityScore'>) => {
    const client = data.clients.find(c => c.id === taskInput.clientId);
    const id = `t_${Date.now()}`;
    const createdAt = new Date().toISOString();
    const score = calculatePriorityScore({ ...taskInput, id, createdAt, calculatedPriorityScore: 0 } as Task, client);
    setData(prev => ({ ...prev, tasks: [{ ...taskInput, id, createdAt, calculatedPriorityScore: score } as Task, ...prev.tasks] }));
  }, [data.clients]);

  const urgentTasks = useMemo(() => {
    return data.tasks.filter(t => {
      if (t.status === TaskStatus.DONE) return false;
      const days = (new Date(t.deadline).getTime() - new Date().getTime()) / (1000 * 3600 * 24);
      return days <= 2 && days >= 0;
    });
  }, [data.tasks]);

  if (!hasStarted) return <LandingPage onStart={handleStart} />;

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard data={data} updateTaskStatus={updateTaskStatus} deleteTask={deleteTask} updateTask={updateTask} />;
      case 'prospects': return <ProspectManager data={data} onSave={saveProspect} onDelete={deleteProspect} onConvert={convertProspectToClient} />;
      case 'pipeline': return <Pipeline data={data} onConvert={convertProspectToClient} />;
      case 'clients': return <ClientManager data={data} addClient={addClient} deleteClient={deleteClient} updateClient={updateClient} />;
      case 'brief': return <TaskForm data={data} addTask={addTask} />;
      case 'reports': return <Reports data={data} />;
      case 'docs': return <Documentation />;
      default: return <Dashboard data={data} updateTaskStatus={updateTaskStatus} deleteTask={deleteTask} updateTask={updateTask} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#f8fafc]">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onReset={() => setHasStarted(false)} />
      <main className="flex-1 p-8 md:p-12 overflow-y-auto">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-end mb-8 no-print">
            <div className="flex items-center gap-6">
              <div className="relative group">
                <button className="p-2.5 bg-white rounded-xl border border-zinc-200 shadow-sm text-zinc-500 hover:text-zinc-900 transition-colors">
                  <Bell size={20} />
                  {urgentTasks.length > 0 && <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-white animate-pulse"></span>}
                </button>
              </div>
              <div className="flex items-center gap-3 border-l border-zinc-200 pl-6 font-medium">
                <div className="text-right">
                  <p className="text-xs font-bold text-zinc-900">Admin Agence</p>
                  <p className="text-[10px] text-zinc-400">Studio Focus Mode</p>
                </div>
                <div className="w-10 h-10 rounded-xl bg-zinc-900 flex items-center justify-center text-white font-serif italic text-lg shadow-lg">A</div>
              </div>
            </div>
          </div>
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default App;
