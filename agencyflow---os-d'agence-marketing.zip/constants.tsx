
import { AppData } from './types';

// Add missing prospects array to satisfy the AppData interface
export const INITIAL_DATA: AppData = {
  clients: [],
  tasks: [],
  prospects: []
};

export const TASK_TYPES = [
  'SEO',
  'Social Media',
  'Web Design',
  'Développement',
  'Copywriting',
  'Ads (SEA/SMA)',
  'Stratégie',
  'Maintenance'
];