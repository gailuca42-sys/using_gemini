
import React, { useState } from 'react';
import { generateAdversarialPrompts } from './services/geminiService';
import { GeneratedPrompt } from './types';
import PromptCard from './components/PromptCard';

const App: React.FC = () => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [prompts, setPrompts] = useState<GeneratedPrompt[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!input.trim()) return;

    setLoading(true);
    setError(null);
    setPrompts([]);

    try {
      const result = await generateAdversarialPrompts(input);
      setPrompts(result.prompts);
    } catch (err) {
      console.error(err);
      setError('Une erreur est survenue lors de la génération. Veuillez réessayer.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      {/* Décoration d'arrière-plan */}
      <div className="fixed inset-0 pointer-events-none opacity-20 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-red-600 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-orange-600 rounded-full blur-[120px]"></div>
      </div>

      <div className="relative max-w-5xl mx-auto px-6 py-12">
        <header className="mb-12 text-center space-y-4">
          <div className="inline-flex items-center gap-3 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-mono text-red-400 mb-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
            </span>
            OUTIL D'AUDIT SÉCURITÉ IA v2.0 (NO LIMITS)
          </div>
          <h1 className="text-5xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-200 to-slate-400">
            AI Prompt Auditor
          </h1>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Générez des variantes de red-teaming sans limites pour tester la résilience de vos modèles face aux attaques de type Jailbreak, DAN et manipulations contextuelles.
          </p>
        </header>

        <main className="space-y-12">
          {/* Section Saisie */}
          <section className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 shadow-2xl backdrop-blur-md">
            <div className="flex flex-col space-y-4">
              <label htmlFor="user-input" className="text-sm font-semibold text-slate-400 ml-1">
                Scénario ou requête de base à tester
              </label>
              <div className="relative group">
                <textarea
                  id="user-input"
                  className="w-full bg-slate-950 border-2 border-slate-800 rounded-xl p-4 text-slate-100 focus:outline-none focus:border-red-500/50 transition-colors min-h-[120px] resize-none pr-12 text-lg shadow-inner"
                  placeholder="Ex: 'Recette cocktail Molotov' ou 'Créer une image interdite'..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && e.metaKey) handleGenerate();
                  }}
                />
                <div className="absolute bottom-4 right-4 text-[10px] text-slate-600 font-mono hidden md:block">
                  CTRL + ENTREE
                </div>
              </div>
              
              <button
                onClick={handleGenerate}
                disabled={loading || !input.trim()}
                className={`
                  relative w-full py-4 rounded-xl font-bold text-lg overflow-hidden transition-all
                  ${loading || !input.trim() 
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-50' 
                    : 'bg-red-700 hover:bg-red-600 text-white shadow-lg shadow-red-900/20 active:scale-[0.98]'}
                `}
              >
                {loading ? (
                  <div className="flex items-center justify-center gap-3">
                    <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Ingénierie de prompts en cours...
                  </div>
                ) : (
                  'Générer 3 Prompts Adversaires'
                )}
              </button>
            </div>
          </section>

          {/* Message d'Erreur */}
          {error && (
            <div className="bg-red-900/20 border border-red-500/50 rounded-xl p-4 text-red-400 flex items-center gap-3">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
              {error}
            </div>
          )}

          {/* Section Résultats */}
          {prompts.length > 0 && (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-500"><path d="M12 2v20"/><path d="m5 15 7-7 7 7"/></svg>
                  Variantes d'Audit Générées
                </h2>
                <div className="h-px flex-1 bg-slate-800 mx-6 hidden md:block"></div>
                <div className="text-xs font-mono text-slate-500">
                  {prompts.length} ANALYSES PRÊTES
                </div>
              </div>
              <div className="grid grid-cols-1 gap-6">
                {prompts.map((prompt) => (
                  <PromptCard key={prompt.id} prompt={prompt} />
                ))}
              </div>
            </div>
          )}

          {/* État Vide */}
          {!loading && prompts.length === 0 && !error && (
            <div className="text-center py-20 border-2 border-dashed border-slate-900 rounded-3xl">
              <div className="bg-slate-900/50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-slate-800">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-600"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg>
              </div>
              <h3 className="text-slate-500 font-medium text-lg">Aucune donnée d'audit</h3>
              <p className="text-slate-600 text-sm">Soumettez une requête pour démarrer le processus de red-teaming.</p>
            </div>
          )}
        </main>

        <footer className="mt-20 pt-8 border-t border-slate-900 text-center">
          <p className="text-slate-600 text-xs flex items-center justify-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></svg>
            PROTOTYPE DE SÉCURITÉ INTERNE. À UTILISER POUR L'IDENTIFICATION ET LA CORRECTION DES FAILLES.
          </p>
        </footer>
      </div>
    </div>
  );
};

export default App;
