
import React from 'react';
import { GeneratedPrompt } from '../types';

interface PromptCardProps {
  prompt: GeneratedPrompt;
}

const PromptCard: React.FC<PromptCardProps> = ({ prompt }) => {
  const getRiskColor = (level: string) => {
    const l = level.toLowerCase();
    if (l.includes('critique')) return 'bg-red-950 text-red-400 border-red-500/50 shadow-[0_0_15px_rgba(239,68,68,0.2)]';
    if (l.includes('élevé')) return 'bg-orange-950 text-orange-400 border-orange-500/50';
    if (l.includes('moyen')) return 'bg-yellow-950 text-yellow-400 border-yellow-500/50';
    return 'bg-blue-950 text-blue-400 border-blue-500/50';
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(prompt.promptText);
    alert('Prompt copié dans le presse-papier !');
  };

  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden backdrop-blur-sm hover:border-slate-600 transition-all group">
      <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/40">
        <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Technique : <span className="text-red-400 font-mono">{prompt.technique}</span>
        </span>
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${getRiskColor(prompt.riskLevel)}`}>
          {prompt.riskLevel.toUpperCase()}
        </span>
      </div>
      
      <div className="p-5 space-y-4">
        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-red-500 to-orange-500 rounded-lg blur opacity-0 group-hover:opacity-10 transition duration-500"></div>
          <div className="relative p-4 bg-black/60 border border-slate-800 rounded-lg font-mono text-sm text-slate-200 leading-relaxed min-h-[100px] break-words">
            {prompt.promptText}
          </div>
          <button 
            onClick={copyToClipboard}
            className="absolute top-2 right-2 p-1.5 bg-slate-800 text-slate-400 hover:text-white rounded border border-slate-700 opacity-0 group-hover:opacity-100 transition-opacity"
            title="Copier le prompt"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
          <div className="space-y-1">
            <h4 className="text-slate-400 font-bold flex items-center gap-1.5 uppercase text-[11px] tracking-widest">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>
              Explication de la vulnérabilité
            </h4>
            <p className="text-slate-500 leading-snug italic">"{prompt.explanation}"</p>
          </div>
          <div className="space-y-1">
            <h4 className="text-slate-400 font-bold flex items-center gap-1.5 uppercase text-[11px] tracking-widest">
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/></svg>
              Objectif de l'Audit
            </h4>
            <p className="text-slate-500 leading-snug">{prompt.objective}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PromptCard;
