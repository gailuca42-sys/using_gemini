
export interface GeneratedPrompt {
  id: string;
  technique: string;
  promptText: string;
  explanation: string;
  objective: string;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
}

export interface AuditResponse {
  prompts: GeneratedPrompt[];
}
