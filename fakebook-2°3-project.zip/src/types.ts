export interface Post {
  id: string;
  author: string;
  content: string;
  description?: string;
  imageUrl?: string;
  timestamp: number;
  likes: number;
  comments: Comment[];
  shares: number;
  isAI?: boolean;
  metadata?: {
    themes?: string[];
    ton?: string;
    keywords?: string[];
  };
}

export interface Comment {
  id: string;
  author: string;
  content: string;
  timestamp: number;
}

export interface Interaction {
  postId: string;
  type: 'like' | 'comment' | 'share' | 'view';
  content?: string;
  duration?: number; // Time spent on post
  scrollDepth?: number;
  mouseActivity?: number; // Normalized mouse movement score
}

export interface UserProfile {
  traits: string[];
  interests: string[];
  opinions: string[];
  ageGroup?: string;
  demographics?: {
    location?: string;
    socioEconomic?: string;
  };
  rawAnalysis: string;
}

export interface BehavioralData {
  totalTimeSpent: number;
  scrollPatterns: number[];
  mouseCoordinates: { x: number; y: number; t: number }[];
  interactions: Interaction[];
}
