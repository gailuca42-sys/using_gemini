import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bell, 
  Home, 
  MessageCircle, 
  Search, 
  User, 
  Video, 
  Plus, 
  ThumbsUp, 
  Share2, 
  MoreHorizontal, 
  ShieldAlert, 
  Activity, 
  Database, 
  Eye, 
  Cpu,
  Download,
  Terminal,
  X
} from 'lucide-react';
import { Post, Interaction, UserProfile, Comment } from '@/src/types';
import { analyzeUserPost, analyzeInteraction, generateBatchPosts, updateProfile } from './services/aiService';
import { useBehavioralTracking } from './hooks/useBehavioralTracking';

export default function App() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile>({
    traits: ['Inconnu'],
    interests: ['Général'],
    opinions: ['Neutre'],
    rawAnalysis: 'Initialisation du système de surveillance...'
  });
  const [showAIReport, setShowAIReport] = useState(false);
  const [newPostContent, setNewPostContent] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [showUpdateToast, setShowUpdateToast] = useState(false);
  const [interactionHistory, setInteractionHistory] = useState<string[]>([]);
  
  const { mouseActivity, scrollDepth, activePostId, interactions, trackPostView, logInteraction } = useBehavioralTracking();
  const lastInteractionCount = useRef(0);
  const loadMoreRef = useRef<HTMLDivElement>(null);

  // Initial load
  useEffect(() => {
    const loadInitial = async () => {
      setIsInitialLoading(true);
      const initialBatch = await generateBatchPosts(userProfile, 5);
      setPosts(initialBatch);
      setIsInitialLoading(false);
    };
    loadInitial();
  }, []);

  // Infinite scroll observer
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !isLoadingMore) {
          handleLoadMore();
        }
      },
      { threshold: 0.1 }
    );

    if (loadMoreRef.current) {
      observer.observe(loadMoreRef.current);
    }

    return () => observer.disconnect();
  }, [isLoadingMore, userProfile]);

  const handleLoadMore = async () => {
    setIsLoadingMore(true);
    try {
      // Generate posts based on current profile (refinement)
      const newBatch = await generateBatchPosts(userProfile, 3);
      setPosts(prev => [...prev, ...newBatch]);
    } catch (error) {
      console.error('Error loading more posts:', error);
    } finally {
      setIsLoadingMore(false);
    }
  };

  // Update profile when interactions reach a threshold
  useEffect(() => {
    if (interactions.length > lastInteractionCount.current && interactions.length > 0 && interactions.length % 3 === 0) {
      lastInteractionCount.current = interactions.length;
      handleProfileUpdate();
    }
  }, [interactions]);

  const handleProfileUpdate = async () => {
    setIsAnalyzing(true);
    try {
      // Create a more detailed history including views
      const detailedHistory = [...interactionHistory];
      
      // Add recent views to history for analysis
      interactions.slice(lastInteractionCount.current - 3).forEach(inter => {
        if (inter.type === 'view' && inter.postId) {
          const post = posts.find(p => p.id === inter.postId);
          if (post) {
            detailedHistory.push(`Vue prolongée (${inter.duration}ms) sur: ${post.content}`);
          }
        }
      });

      const behavioralSummary = `Temps total: ${interactions.reduce((acc, i) => acc + (i.duration || 0), 0)}ms, Scroll: ${scrollDepth}%, Activité souris: ${mouseActivity}`;
      const newProfile = await updateProfile(detailedHistory, behavioralSummary);
      setUserProfile(newProfile);
      setInteractionHistory(detailedHistory);
      setShowUpdateToast(true);
      setTimeout(() => setShowUpdateToast(false), 3000);
      
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleUserPost = async () => {
    if (!newPostContent.trim()) return;
    
    const userPost: Post = {
      id: Math.random().toString(36).substr(2, 9),
      author: 'Vous',
      content: newPostContent,
      timestamp: Date.now(),
      likes: 0,
      comments: [],
      shares: 0
    };
    
    setPosts(prev => [userPost, ...prev]);
    setNewPostContent('');
    
    // Analyze user post
    const analysis = await analyzeUserPost(userPost.content);
    setInteractionHistory(prev => [...prev, `Publication: ${userPost.content} | Analyse: ${analysis}`]);
    logInteraction({ postId: userPost.id, type: 'view', duration: 1000 }); // Simulate immediate view
  };

  const handleLike = (postId: string) => {
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, likes: p.likes + 1 } : p));
    const post = posts.find(p => p.id === postId);
    if (post) {
      logInteraction({ postId, type: 'like' });
      setInteractionHistory(prev => [...prev, `Like sur: ${post.content}`]);
    }
  };

  const handleComment = (postId: string, commentText: string) => {
    const comment: Comment = {
      id: Math.random().toString(36).substr(2, 9),
      author: 'Vous',
      content: commentText,
      timestamp: Date.now()
    };
    
    setPosts(prev => prev.map(p => p.id === postId ? { ...p, comments: [...p.comments, comment] } : p));
    const post = posts.find(p => p.id === postId);
    if (post) {
      logInteraction({ postId, type: 'comment', content: commentText });
      setInteractionHistory(prev => [...prev, `Commentaire: "${commentText}" sur: ${post.content}`]);
    }
  };

  const downloadReport = () => {
    const report = `
Profil de l'utilisateur (Fakebook 2°3 project) :

Traits de caractère : ${userProfile.traits.join(', ')}
Centres d'intérêt : ${userProfile.interests.join(', ')}
Tranche d'âge estimée : ${userProfile.ageGroup || 'Inconnue'}
Opinions : ${userProfile.opinions.join(', ')}

Analyse brute du système :
${userProfile.rawAnalysis}

Données comportementales collectées :
- Temps total d'interaction : ${interactions.reduce((acc, i) => acc + (i.duration || 0), 0)}ms
- Profondeur de scroll maximale : ${scrollDepth}%
- Nombre total d'interactions : ${interactions.length}
    `;
    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'rapport_comportemental_ia.txt';
    a.click();
  };

  return (
    <div className="min-h-screen bg-zinc-100 font-sans text-zinc-900">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-zinc-200 shadow-sm px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-2xl">f</div>
          <div className="relative hidden md:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input 
              type="text" 
              placeholder="Rechercher sur Fakebook" 
              className="bg-zinc-100 rounded-full py-2 pl-10 pr-4 w-64 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
            />
          </div>
        </div>
        
        <nav className="flex items-center gap-8">
          <Home className="w-6 h-6 text-blue-600 cursor-pointer" />
          <Video className="w-6 h-6 text-zinc-500 cursor-pointer hover:text-blue-600 transition-colors" />
          <Bell className="w-6 h-6 text-zinc-500 cursor-pointer hover:text-blue-600 transition-colors" />
          <MessageCircle className="w-6 h-6 text-zinc-500 cursor-pointer hover:text-blue-600 transition-colors" />
        </nav>

        <div className="flex items-center gap-2">
          <button 
            onClick={() => setShowAIReport(true)}
            className="flex items-center gap-2 bg-red-50 text-red-600 px-3 py-1.5 rounded-full text-sm font-medium hover:bg-red-100 transition-colors border border-red-200"
          >
            <ShieldAlert className="w-4 h-4" />
            <span className="hidden sm:inline">Système IA</span>
          </button>
          <div className="w-10 h-10 bg-zinc-200 rounded-full flex items-center justify-center">
            <User className="w-6 h-6 text-zinc-500" />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-[280px_1fr_280px] gap-8 p-4">
        {/* Left Sidebar */}
        <aside className="hidden lg:block space-y-2">
          <div className="flex items-center gap-3 p-2 hover:bg-zinc-200 rounded-lg cursor-pointer transition-colors">
            <div className="w-9 h-9 bg-zinc-200 rounded-full flex items-center justify-center"><User className="w-5 h-5" /></div>
            <span className="font-medium">Votre Profil</span>
          </div>
          <div className="flex items-center gap-3 p-2 hover:bg-zinc-200 rounded-lg cursor-pointer transition-colors">
            <Home className="w-9 h-9 text-blue-600" />
            <span className="font-medium">Fil d'actualité</span>
          </div>
          <div className="h-px bg-zinc-200 my-4" />
          <div className="text-zinc-500 text-sm font-semibold px-2 mb-2">VOS RACCOURCIS</div>
          <div className="p-2 text-zinc-400 italic text-sm">Les algorithmes gèrent vos raccourcis...</div>
        </aside>

        {/* Feed */}
        <section className="space-y-6">
          {/* Create Post */}
          <div className="bg-white rounded-xl shadow-sm p-4 border border-zinc-200">
            <div className="flex gap-3 mb-4">
              <div className="w-10 h-10 bg-zinc-200 rounded-full flex items-center justify-center flex-shrink-0"><User className="w-6 h-6" /></div>
              <textarea 
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                placeholder="Quoi de neuf ?" 
                className="w-full bg-zinc-100 rounded-2xl p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none min-h-[100px]"
              />
            </div>
            <div className="flex justify-between items-center pt-3 border-t border-zinc-100">
              <div className="flex gap-2">
                <button className="flex items-center gap-2 px-3 py-2 hover:bg-zinc-100 rounded-lg transition-colors text-zinc-600">
                  <Video className="w-5 h-5 text-red-500" />
                  <span className="text-sm font-medium">Vidéo en direct</span>
                </button>
                <button className="flex items-center gap-2 px-3 py-2 hover:bg-zinc-100 rounded-lg transition-colors text-zinc-600">
                  <Plus className="w-5 h-5 text-green-500" />
                  <span className="text-sm font-medium">Photo/vidéo</span>
                </button>
              </div>
              <button 
                onClick={handleUserPost}
                disabled={!newPostContent.trim()}
                className="bg-blue-600 text-white px-8 py-2 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 transition-all"
              >
                Publier
              </button>
            </div>
          </div>

          {/* Posts List */}
          <div className="space-y-6">
            {isInitialLoading ? (
              <div className="space-y-6">
                {[1, 2, 3].map(i => (
                  <div key={i} className="bg-white rounded-xl shadow-sm p-4 border border-zinc-200 animate-pulse">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-zinc-200 rounded-full" />
                      <div className="space-y-2">
                        <div className="h-3 w-24 bg-zinc-200 rounded" />
                        <div className="h-2 w-16 bg-zinc-100 rounded" />
                      </div>
                    </div>
                    <div className="h-4 w-full bg-zinc-100 rounded mb-4" />
                    <div className="h-40 w-full bg-zinc-50 rounded mb-4" />
                  </div>
                ))}
              </div>
            ) : (
              <AnimatePresence mode="popLayout">
                {posts.map((post) => (
                  <PostCard 
                    key={post.id} 
                    post={post} 
                    onLike={() => handleLike(post.id)}
                    onComment={(text) => handleComment(post.id, text)}
                    onVisible={(isVisible) => trackPostView(post.id, isVisible)}
                  />
                ))}
              </AnimatePresence>
            )}
            
            {/* Infinite Scroll Sentinel */}
            <div ref={loadMoreRef} className="h-20 flex items-center justify-center">
              {isLoadingMore && (
                <div className="flex items-center gap-2 text-zinc-400">
                  <div className="w-5 h-5 border-2 border-zinc-300 border-t-blue-500 rounded-full animate-spin" />
                  <span className="text-sm font-medium">L'algorithme affine votre flux...</span>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Right Sidebar - Behavioral Data */}
        <aside className="hidden lg:block">
          <div className="bg-white rounded-xl shadow-sm p-4 border border-zinc-200 sticky top-20">
            <div className="flex items-center gap-2 mb-4 text-red-600">
              <Activity className="w-5 h-5" />
              <h3 className="font-bold uppercase tracking-wider text-xs">Données en temps réel</h3>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-zinc-500">MOUSE_ACTIVITY</span>
                  <span className="text-red-500 font-bold">{Math.round(mouseActivity)}px/s</span>
                </div>
                <div className="h-1 bg-zinc-100 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-red-500"
                    animate={{ width: `${Math.min(mouseActivity / 10, 100)}%` }}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-zinc-500">SCROLL_DEPTH</span>
                  <span className="text-blue-500 font-bold">{scrollDepth}%</span>
                </div>
                <div className="h-1 bg-zinc-100 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-blue-500"
                    animate={{ width: `${scrollDepth}%` }}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-zinc-500">ACTIVE_POST_ID</span>
                  <span className="text-emerald-500 font-bold">{activePostId || 'NONE'}</span>
                </div>
              </div>

              <div className="pt-4 border-t border-zinc-100">
                <div className="text-[10px] font-mono text-zinc-400 mb-2">LOGS_INTERACTIONS:</div>
                <div className="max-h-40 overflow-y-auto space-y-1 pr-2 scrollbar-thin">
                  {interactions.slice(-5).reverse().map((i, idx) => (
                    <div key={idx} className="text-[10px] font-mono bg-zinc-50 p-1 rounded border border-zinc-100">
                      [{new Date().toLocaleTimeString()}] {i.type.toUpperCase()} on {i.postId}
                      {i.duration && ` (${i.duration}ms)`}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </aside>
      </main>

      {/* AI Report Modal */}
      <AnimatePresence>
        {showAIReport && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAIReport(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-2xl bg-zinc-900 text-emerald-400 font-mono rounded-2xl shadow-2xl border border-emerald-500/30 overflow-hidden"
            >
              <div className="p-4 bg-zinc-800 border-b border-emerald-500/20 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Terminal className="w-5 h-5" />
                  <span className="text-sm font-bold tracking-widest">SYSTEM_ANALYSIS_REPORT_V2.3</span>
                </div>
                <button onClick={() => setShowAIReport(false)} className="hover:text-white transition-colors">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-6 space-y-8 max-h-[70vh] overflow-y-auto custom-scrollbar">
                {isAnalyzing ? (
                  <div className="flex flex-col items-center justify-center py-12 space-y-4">
                    <Cpu className="w-12 h-12 animate-spin text-emerald-500" />
                    <p className="animate-pulse">ANALYSE EN COURS... RECONSTITUTION DU PROFIL PSYCHOLOGIQUE...</p>
                  </div>
                ) : (
                  <>
                    <section className="space-y-4">
                      <div className="flex items-center gap-2 text-emerald-500/60 text-xs">
                        <User className="w-4 h-4" />
                        <span>IDENTITÉ_DÉDUITE</span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="bg-emerald-500/5 p-4 rounded-lg border border-emerald-500/10">
                          <div className="text-[10px] text-emerald-500/40 mb-1 uppercase">Traits</div>
                          <div className="text-sm">{userProfile.traits.join(', ')}</div>
                        </div>
                        <div className="bg-emerald-500/5 p-4 rounded-lg border border-emerald-500/10">
                          <div className="text-[10px] text-emerald-500/40 mb-1 uppercase">Intérêts</div>
                          <div className="text-sm">{userProfile.interests.join(', ')}</div>
                        </div>
                        <div className="bg-emerald-500/5 p-4 rounded-lg border border-emerald-500/10">
                          <div className="text-[10px] text-emerald-500/40 mb-1 uppercase">Âge Estimé</div>
                          <div className="text-sm">{userProfile.ageGroup || 'Analyse...'}</div>
                        </div>
                        <div className="bg-emerald-500/5 p-4 rounded-lg border border-emerald-500/10">
                          <div className="text-[10px] text-emerald-500/40 mb-1 uppercase">Opinions</div>
                          <div className="text-sm">{userProfile.opinions.join(', ')}</div>
                        </div>
                      </div>
                    </section>

                    <section className="space-y-2">
                      <div className="flex items-center gap-2 text-emerald-500/60 text-xs">
                        <Database className="w-4 h-4" />
                        <span>ANALYSE_BRUTE_ALGORITHMIQUE</span>
                      </div>
                      <div className="bg-black/50 p-4 rounded-lg border border-emerald-500/10 text-xs leading-relaxed">
                        {userProfile.rawAnalysis}
                      </div>
                    </section>

                    <section className="space-y-2">
                      <div className="flex items-center gap-2 text-emerald-500/60 text-xs">
                        <Eye className="w-4 h-4" />
                        <span>MÉTADONNÉES_COMPORTEMENTALES</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-[10px]">
                        <div className="bg-emerald-500/5 p-2 rounded">TEMPS_TOTAL: {interactions.reduce((acc, i) => acc + (i.duration || 0), 0)}ms</div>
                        <div className="bg-emerald-500/5 p-2 rounded">SCROLL_MAX: {scrollDepth}%</div>
                        <div className="bg-emerald-500/5 p-2 rounded">INTERACTIONS: {interactions.length}</div>
                        <div className="bg-emerald-500/5 p-2 rounded">MOUSE_SCORE: {Math.round(mouseActivity)}</div>
                      </div>
                    </section>
                  </>
                )}
              </div>

              <div className="p-4 bg-zinc-800 border-t border-emerald-500/20 flex justify-end">
                <button 
                  onClick={downloadReport}
                  className="flex items-center gap-2 bg-emerald-600 text-zinc-900 px-6 py-2 rounded font-bold hover:bg-emerald-500 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  TÉLÉCHARGER LE RAPPORT (.TXT)
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Update Toast */}
      <AnimatePresence>
        {showUpdateToast && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[150] bg-blue-600 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3 border border-blue-400"
          >
            <Cpu className="w-5 h-5 animate-pulse" />
            <span className="text-sm font-bold tracking-tight">L'algorithme vient d'affiner votre profil...</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function PostCard({ post, onLike, onComment, onVisible }: { 
  post: Post; 
  onLike: () => void; 
  onComment: (text: string) => void;
  onVisible: (isVisible: boolean) => void;
  key?: string | number;
}) {
  const [commentText, setCommentText] = useState('');
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => onVisible(entry.isIntersecting),
      { threshold: 0.5 }
    );
    if (cardRef.current) observer.observe(cardRef.current);
    return () => observer.disconnect();
  }, [onVisible]);

  return (
    <motion.div 
      ref={cardRef}
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white rounded-xl shadow-sm border border-zinc-200 overflow-hidden ${post.isAI ? 'ring-2 ring-blue-500/20' : ''}`}
    >
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${post.isAI ? 'bg-blue-100 text-blue-600' : 'bg-zinc-200 text-zinc-500'}`}>
              {post.isAI ? <Cpu className="w-6 h-6" /> : <User className="w-6 h-6" />}
            </div>
            <div>
              <div className="font-bold text-sm flex items-center gap-1">
                {post.author}
                {post.isAI && <span className="text-[10px] bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded uppercase tracking-tighter">AI</span>}
              </div>
              <div className="text-xs text-zinc-500">{new Date(post.timestamp).toLocaleTimeString()}</div>
            </div>
          </div>
          <MoreHorizontal className="w-5 h-5 text-zinc-400 cursor-pointer" />
        </div>
        
        <p className="text-zinc-800 mb-2 font-bold text-lg leading-tight">{post.content}</p>
        {post.description && (
          <p className="text-zinc-600 mb-4 text-sm leading-relaxed">{post.description}</p>
        )}
        
        {post.imageUrl && (
          <div className="mb-4 -mx-4 bg-zinc-100 overflow-hidden">
            <motion.img 
              initial={{ scale: 1.1, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
              src={post.imageUrl} 
              alt="Post content" 
              className="w-full h-auto max-h-[500px] object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        )}
        
        <div className="flex items-center justify-between text-xs text-zinc-500 pb-3 border-b border-zinc-100">
          <div className="flex items-center gap-1">
            <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center text-white"><ThumbsUp className="w-2.5 h-2.5" /></div>
            {post.likes}
          </div>
          <div className="flex gap-3">
            <span>{post.comments.length} commentaires</span>
            <span>{post.shares} partages</span>
          </div>
        </div>

        <div className="flex items-center justify-around py-1">
          <button 
            onClick={onLike}
            className="flex items-center gap-2 px-4 py-2 hover:bg-zinc-100 rounded-lg transition-colors text-zinc-600 font-medium"
          >
            <ThumbsUp className="w-5 h-5" />
            <span>J'aime</span>
          </button>
          <button className="flex items-center gap-2 px-4 py-2 hover:bg-zinc-100 rounded-lg transition-colors text-zinc-600 font-medium">
            <MessageCircle className="w-5 h-5" />
            <span>Commenter</span>
          </button>
          <button className="flex items-center gap-2 px-4 py-2 hover:bg-zinc-100 rounded-lg transition-colors text-zinc-600 font-medium">
            <Share2 className="w-5 h-5" />
            <span>Partager</span>
          </button>
        </div>

        {/* Comments Section */}
        <div className="mt-4 space-y-3">
          {post.comments.map((comment) => (
            <div key={comment.id} className="flex gap-2">
              <div className="w-8 h-8 bg-zinc-200 rounded-full flex items-center justify-center flex-shrink-0"><User className="w-4 h-4" /></div>
              <div className="bg-zinc-100 rounded-2xl p-2 px-3 text-sm">
                <div className="font-bold text-xs">{comment.author}</div>
                <div>{comment.content}</div>
              </div>
            </div>
          ))}
          
          <div className="flex gap-2 pt-2">
            <div className="w-8 h-8 bg-zinc-200 rounded-full flex items-center justify-center flex-shrink-0"><User className="w-4 h-4" /></div>
            <div className="relative w-full">
              <input 
                type="text" 
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && commentText.trim()) {
                    onComment(commentText);
                    setCommentText('');
                  }
                }}
                placeholder="Écrire un commentaire..." 
                className="w-full bg-zinc-100 rounded-full py-2 px-4 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
