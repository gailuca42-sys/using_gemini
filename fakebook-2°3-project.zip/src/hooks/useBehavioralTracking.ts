import { useEffect, useRef, useState } from 'react';
import { Interaction } from '@/src/types';

export function useBehavioralTracking() {
  const [mouseActivity, setMouseActivity] = useState(0);
  const [scrollDepth, setScrollDepth] = useState(0);
  const [activePostId, setActivePostId] = useState<string | null>(null);
  const [interactions, setInteractions] = useState<Interaction[]>([]);
  
  const mouseMoveCount = useRef(0);
  const lastMousePos = useRef({ x: 0, y: 0 });
  const postViewStartTime = useRef<Record<string, number>>({});
  const postViewDuration = useRef<Record<string, number>>({});

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const dist = Math.sqrt(
        Math.pow(e.clientX - lastMousePos.current.x, 2) + 
        Math.pow(e.clientY - lastMousePos.current.y, 2)
      );
      mouseMoveCount.current += dist;
      lastMousePos.current = { x: e.clientX, y: e.clientY };
    };

    const handleScroll = () => {
      const winHeight = window.innerHeight;
      const docHeight = document.documentElement.scrollHeight;
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const depth = Math.round((scrollTop / (docHeight - winHeight)) * 100);
      setScrollDepth(prev => Math.max(prev, depth));
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('scroll', handleScroll);

    const interval = setInterval(() => {
      setMouseActivity(mouseMoveCount.current);
      mouseMoveCount.current = 0; // Reset for next interval
    }, 1000);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
      clearInterval(interval);
    };
  }, []);

  const trackPostView = (postId: string, isVisible: boolean) => {
    if (isVisible) {
      postViewStartTime.current[postId] = Date.now();
      setActivePostId(postId);
    } else {
      if (postViewStartTime.current[postId]) {
        const duration = Date.now() - postViewStartTime.current[postId];
        postViewDuration.current[postId] = (postViewDuration.current[postId] || 0) + duration;
        
        // Log interaction if duration is significant
        if (duration > 500) {
          const interaction: Interaction = {
            postId,
            type: 'view',
            duration,
            mouseActivity: mouseActivity,
            scrollDepth: scrollDepth
          };
          setInteractions(prev => [...prev, interaction]);
        }
      }
    }
  };

  const logInteraction = (interaction: Interaction) => {
    setInteractions(prev => [...prev, interaction]);
  };

  return {
    mouseActivity,
    scrollDepth,
    activePostId,
    interactions,
    trackPostView,
    logInteraction
  };
}
