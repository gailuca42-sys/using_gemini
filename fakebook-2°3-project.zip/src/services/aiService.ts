import { Interaction, Post, UserProfile } from "@/src/types";

// Simulation locale sans API
const INTEREST_KEYWORDS: Record<string, string[]> = {
  "Technologie": ["ia", "algorithme", "numérique", "écran", "futur", "tech", "ordinateur", "robot", "code", "dev"],
  "Nature": ["montagne", "randonnée", "nature", "forêt", "écologie", "fleur", "animal", "climat", "océan"],
  "Cinéma": ["film", "sf", "cinéma", "acteur", "scénario", "série", "netflix", "hollywood"],
  "Politique": ["gouvernement", "loi", "société", "liberté", "surveillance", "droit", "élection", "débat"],
  "Sport": ["foot", "tennis", "course", "entraînement", "match", "score", "gym", "fitness"],
  "Gastronomie": ["cuisine", "recette", "plat", "restaurant", "chef", "vin", "food", "pâtisserie", "épice"],
  "Voyage": ["avion", "hôtel", "destination", "vacances", "tourisme", "paysage", "aventure", "sac à dos"],
  "Art": ["peinture", "musée", "galerie", "artiste", "sculpture", "expo", "design", "couleur"],
  "Musique": ["concert", "album", "chanson", "instrument", "rock", "rap", "jazz", "playlist"],
  "Espace": ["planète", "étoile", "galaxie", "nasa", "astronomie", "télescope", "univers", "mars"],
  "Histoire": ["passé", "guerre", "empire", "siècle", "archive", "monument", "archéologie", "antique"],
  "Niche": ["clavier", "urbex", "bonsaï", "calmar", "brutalisme", "levain", "mécanique", "exploration"],
  "Société": ["société", "école", "retraite", "bac", "pension", "jeune", "senior", "éducation"]
};

const TRAIT_KEYWORDS: Record<string, string[]> = {
  "Curieux": ["pourquoi", "comment", "futur", "nouveau", "découvrir", "apprendre", "science", "exploration", "recherche", "mystère"],
  "Sceptique": ["effrayant", "doute", "question", "pourquoi", "surveillance", "complot", "mensonge", "vérité", "manipulation", "censure"],
  "Optimiste": ["génial", "parfait", "révolutionnaire", "bien", "top", "espoir", "chance", "bonheur", "sourire", "merci"],
  "Introverti": ["seul", "déconnecter", "calme", "tranquille", "lecture", "solitude", "méditation", "silence", "paix"],
  "Engagé": ["doit", "important", "vrai", "liberté", "action", "combat", "justice", "cause", "manif", "pétition"],
  "Anxieux": ["peur", "stress", "inquiétude", "problème", "danger", "risque", "attention", "panique", "alerte"],
  "Créatif": ["art", "dessin", "musique", "création", "imagination", "idée", "projet", "peinture", "design"]
};

const AGE_KEYWORDS: Record<string, string[]> = {
  "12-14 ans": ["collège", "brevet", "fortnite", "roblox", "devoirs", "parents", "trottinette", "vlog"],
  "15-17 ans": ["lycée", "bac", "parcoursup", "soirée", "conduite accompagnée", "orientation", "tiktok", "snap"],
  "18-20 ans": ["fac", "université", "appart", "coloc", "partiels", "permis", "indépendance", "job étudiant"],
  "21-23 ans": ["master", "stage", "premier job", "alternance", "cv", "linkedin", "entrée vie active", "voyage sac à dos"],
  "24-26 ans": ["carrière", "impôts", "premier appart seul", "couple", "épargne", "série", "festival"],
  "27-29 ans": ["promotion", "mariage", "achat immobilier", "investissement", "développement personnel", "brunch"],
  "30-32 ans": ["bébé", "crèche", "maison", "travaux", "carrière", "fatigue", "organisation"],
  "33-35 ans": ["éducation", "famille", "équilibre vie pro", "vacances famille", "jardinage", "bricolage"],
  "36-38 ans": ["crise trentaine", "reconversion", "sport", "santé", "école primaire", "devoirs enfants"],
  "39-41 ans": ["adolescence enfants", "gestion stress", "vin", "gastronomie", "patrimoine"],
  "42-44 ans": ["carrière senior", "santé", "voyages", "confort", "politique locale"],
  "45-47 ans": ["études enfants", "financement fac", "maison campagne", "bien-être"],
  "48-50 ans": ["crise cinquantaine", "bilan vie", "sport intensif", "préparation retraite"],
  "51-53 ans": ["départ enfants", "nid vide", "loisirs", "culture", "investissement"],
  "54-56 ans": ["santé", "petits-enfants", "voyages organisés", "jardin"],
  "57-59 ans": ["fin de carrière", "transmission", "patrimoine", "randonnée"],
  "60-62 ans": ["départ retraite", "nouvelle vie", "voyages", "bénévolat"],
  "63-65 ans": ["pension", "santé", "famille", "histoire", "mémoire"],
  "66+ ans": ["petits-enfants", "souvenirs", "tradition", "santé", "calme", "lecture"]
};

interface PostTemplate {
  id: string;
  text: string;
  description: string;
  img: string;
}

const POST_TEMPLATES: Record<string, Record<string, PostTemplate[]>> = {
  "Technologie": {
    "12-14 ans": [
      { 
        id: "tech_12_14_1",
        text: "Mon premier serveur Discord est en ligne ! 🎮", 
        description: "J'ai passé tout le mercredi à configurer les bots pour qu'on puisse jouer à Roblox tranquillement. Venez faire un tour !",
        img: "discord,gaming,server" 
      },
      { 
        id: "tech_12_14_2",
        text: "Pourquoi mes parents veulent pas me laisser jouer après 21h ?", 
        description: "C'est trop injuste, c'est pile le moment où tous mes potes sont connectés sur Fortnite. Quelqu'un a une technique pour négocier ?",
        img: "angry,teenager,gaming" 
      },
      {
        id: "tech_12_14_3",
        text: "Le nouveau skin sur Fortnite est incroyable ! 🔥",
        description: "J'ai économisé tous mes V-Bucks pour celui-là. Il est trop stylé avec les effets de flammes.",
        img: "fortnite,skin,gaming"
      },
      {
        id: "tech_12_14_4",
        text: "TikTok ou YouTube Shorts ? 📱",
        description: "Je passe trop de temps sur les deux, mais je trouve que les montages sur TikTok sont plus drôles en ce moment.",
        img: "smartphone,tiktok,app"
      }
    ],
    "15-17 ans": [
      { 
        id: "tech_15_17_1",
        text: "Le nouveau setup gaming de @StreamerX est incroyable.", 
        description: "On parle d'une carte graphique qui pourrait faire tourner n'importe quoi en 8K. Le prix est indécent, mais le design est futuriste.",
        img: "gaming,pc,setup" 
      },
      { 
        id: "tech_15_17_2",
        text: "L'IA va-t-elle remplacer nos devoirs de philo ?", 
        description: "Entre ChatGPT et les nouveaux outils de rédaction, la frontière entre travail personnel et assistance numérique devient floue au lycée.",
        img: "robot,writing,homework" 
      },
      {
        id: "tech_15_17_3",
        text: "Comment j'ai monté mon premier PC solo. 🛠️",
        description: "C'était stressant au moment de mettre le processeur, mais quel plaisir quand ça a booté du premier coup !",
        img: "pc,building,hardware"
      }
    ],
    "18-20 ans": [
      { 
        id: "tech_18_20_1",
        text: "Premier appart, premier setup de dev. 💻", 
        description: "C'est petit mais c'est à moi. J'ai enfin pu installer mon double écran pour coder mes projets de fac toute la nuit.",
        img: "student,apartment,laptop" 
      },
      { 
        id: "tech_18_20_2",
        text: "Les meilleurs outils pour survivre à la L1 Info.", 
        description: "Si vous ne connaissez pas encore Notion ou StackOverflow, vous allez souffrir. Voici ma liste d'indispensables.",
        img: "computer,science,student" 
      },
      {
        id: "tech_18_20_3",
        text: "Passer de Windows à Linux : le choc. 🐧",
        description: "J'ai passé 3 heures à essayer d'installer mes drivers wifi, mais je me sens déjà comme un hacker.",
        img: "linux,terminal,code"
      }
    ],
    "21-23 ans": [
      { 
        id: "tech_21_23_1",
        text: "Mon stage de fin d'études en tant que Fullstack Dev.", 
        description: "C'est impressionnant de voir comment une vraie équipe de prod travaille. Le code de la fac c'est vraiment pas la même chose !",
        img: "office,developer,intern" 
      },
      {
        id: "tech_21_23_2",
        text: "Le syndrome de l'imposteur en premier job.",
        description: "Je regarde le code de mes collègues seniors et j'ai l'impression de ne rien savoir. Est-ce que ça s'arrête un jour ?",
        img: "stressed,developer,office"
      }
    ],
    "24-26 ans": [
      {
        id: "tech_24_26_1",
        text: "Gérer ses abonnements SaaS : le cauchemar.",
        description: "Entre Netflix, Spotify, Adobe et les outils de boulot, je perds le fil. Quelqu'un a une appli pour tout centraliser ?",
        img: "subscription,apps,management"
      }
    ],
    "27-29 ans": [
      {
        id: "tech_27_29_1",
        text: "L'investissement en crypto à 30 ans.",
        description: "Est-ce qu'on est déjà trop vieux pour le Web3 ? J'essaie de comprendre la DeFi mais ça bouge trop vite.",
        img: "crypto,bitcoin,trading"
      }
    ],
    "30-32 ans": [
      {
        id: "tech_30_32_1",
        text: "Domotique : ma maison est plus intelligente que moi.",
        description: "J'ai installé des ampoules connectées partout. C'est génial jusqu'à ce que le wifi tombe en panne et qu'on soit dans le noir.",
        img: "smart-home,automation,lights"
      }
    ],
    "33-35 ans": [
      {
        id: "tech_33_35_1",
        text: "Le télétravail avec des enfants en bas âge.",
        description: "Zoom avec un bébé qui pleure en fond, c'est le nouveau sport extrême. Merci aux casques à réduction de bruit.",
        img: "home-office,kids,laptop"
      }
    ],
    "36-38 ans": [
      {
        id: "tech_36_38_1",
        text: "Reconversion dans la tech à 35 ans+.",
        description: "J'ai quitté le marketing pour apprendre le Python. C'est dur mais passionnant. Jamais trop tard !",
        img: "coding,bootcamp,adult"
      }
    ],
    "39-41 ans": [
      {
        id: "tech_39_41_1",
        text: "Contrôle parental : la guerre des écrans.",
        description: "Mes ados sont plus malins que les filtres que j'installe. Comment vous gérez le temps d'écran à la maison ?",
        img: "parenting,tablet,security"
      }
    ],
    "42-44 ans": [
      {
        id: "tech_42_44_1",
        text: "La cybersécurité en entreprise.",
        description: "On ne réalise pas à quel point on est vulnérables avant d'avoir une formation sérieuse. Changez vos mots de passe !",
        img: "security,hacker,protection"
      }
    ],
    "45-47 ans": [
      {
        id: "tech_45_47_1",
        text: "L'évolution de l'informatique depuis les années 90.",
        description: "Quand je repense à mon premier modem 56k... On a fait un chemin incroyable en 30 ans.",
        img: "vintage,computer,modem"
      }
    ],
    "48-50 ans": [
      {
        id: "tech_48_50_1",
        text: "Le numérique au service de la santé.",
        description: "Les montres connectées pour suivre son rythme cardiaque, c'est quand même une sacrée avancée pour notre génération.",
        img: "smartwatch,health,heart"
      }
    ],
    "51-53 ans": [
      {
        id: "tech_51_53_1",
        text: "Organiser ses photos numériques.",
        description: "J'ai des milliers de photos sur mon téléphone et mon cloud. Comment vous faites pour les trier et les sauvegarder ?",
        img: "photos,cloud,storage"
      }
    ],
    "54-56 ans": [
      {
        id: "tech_54_56_1",
        text: "Les réseaux sociaux pour rester en contact.",
        description: "C'est quand même pratique pour voir les photos des vacances des enfants. Mais il y a trop de publicités maintenant.",
        img: "social-media,family,tablet"
      }
    ],
    "57-59 ans": [
      {
        id: "tech_57_59_1",
        text: "La technologie simplifiée.",
        description: "On n'a pas besoin de gadgets compliqués. Juste des outils qui fonctionnent et qui nous facilitent la vie.",
        img: "simple,technology,user"
      }
    ],
    "60-62 ans": [
      {
        id: "tech_60_62_1",
        text: "Découvrir les tablettes à la retraite.",
        description: "C'est beaucoup plus intuitif qu'un ordinateur. Je peux lire mon journal et appeler mes amis facilement.",
        img: "senior,tablet,reading"
      }
    ],
    "63-65 ans": [
      {
        id: "tech_63_65_1",
        text: "La sécurité en ligne pour les seniors.",
        description: "Il faut faire attention aux emails bizarres. Ma banque ne me demandera jamais mon code par message.",
        img: "security,online,warning"
      }
    ],
    "66+ ans": [
      { 
        id: "tech_66_1",
        text: "Apprendre à utiliser les nouveaux outils numériques.", 
        description: "Les appels vidéo et les réseaux sociaux sont des ponts précieux entre les générations. On vous explique simplement comment maîtriser ces outils.",
        img: "tablet,senior,family" 
      },
      {
        id: "tech_66_2",
        text: "Les arnaques par SMS : restez vigilants ! ⚠️",
        description: "On reçoit de plus en plus de messages frauduleux. Ne cliquez jamais sur un lien suspect, même s'il semble venir de votre banque.",
        img: "smartphone,warning,security"
      }
    ],
    "Général": [
      { 
        id: "tech_gen_1",
        text: "L'intelligence artificielle n'est plus de la science-fiction.", 
        description: "Elle trie vos emails, choisit vos films et conduit bientôt vos voitures. Elle est devenue l'infrastructure invisible de notre civilisation.",
        img: "ai,brain,circuit" 
      }
    ]
  },
  "Nature": {
    "12-14 ans": [
      { 
        id: "nat_12_14_1",
        text: "On a trouvé une cabane secrète dans la forêt ! 🌲", 
        description: "C'est le meilleur spot pour se retrouver après les cours. On va essayer de l'améliorer ce week-end avec des planches.",
        img: "kids,woods,cabin" 
      },
      {
        id: "nat_12_14_2",
        text: "Regardez ce que j'ai trouvé dans le jardin ! 🐜",
        description: "Une fourmilière géante. C'est fascinant de voir comment elles s'organisent pour transporter de la nourriture.",
        img: "ants,nature,garden"
      }
    ],
    "15-17 ans": [
      { 
        id: "nat_15_17_1",
        text: "Le camping sauvage, c'est l'aventure ultime.", 
        description: "Rien ne vaut le réveil au milieu de nulle part avec une vue imprenable. On cherche des compagnons pour un road trip cet été.",
        img: "tent,stars,camping" 
      },
      {
        id: "nat_15_17_2",
        text: "Coucher de soleil sur la plage. 🌅",
        description: "Le moment parfait pour déconnecter de tout et juste profiter du bruit des vagues.",
        img: "beach,sunset,ocean"
      }
    ],
    "18-20 ans": [
      { 
        id: "nat_18_20_1",
        text: "Road trip minimaliste en van. 🚐", 
        description: "On a aménagé un vieux van pour faire le tour de l'Europe. La liberté totale, loin du stress des examens.",
        img: "vanlife,adventure" 
      },
      {
        id: "nat_18_20_2",
        text: "Randonnée dans les Alpes. 🏔️",
        description: "Les jambes brûlent mais la vue au sommet en valait chaque effort. La nature est grandiose.",
        img: "mountains,hiking,view"
      }
    ],
    "24-26 ans": [
      {
        id: "nat_24_26_1",
        text: "Week-end déconnexion totale.",
        description: "Pas de wifi, pas de réseau, juste le bruit de la rivière. Le luxe ultime en 2024.",
        img: "river,forest,cabin"
      }
    ],
    "27-29 ans": [
      {
        id: "nat_27_29_1",
        text: "Le jardinage urbain : mes tomates poussent enfin !",
        description: "Qui aurait cru qu'un balcon au 4ème étage pouvait produire autant ? C'est magique.",
        img: "balcony,garden,tomatoes"
      }
    ],
    "30-32 ans": [
      {
        id: "nat_30_32_1",
        text: "Première rando avec le porte-bébé.",
        description: "C'est plus lourd que prévu, mais voir son émerveillement devant une cascade, ça n'a pas de prix.",
        img: "hiking,baby,waterfall"
      }
    ],
    "33-35 ans": [
      {
        id: "nat_33_35_1",
        text: "Installer un nichoir dans le jardin.",
        description: "On apprend aux enfants à reconnaître les oiseaux. Une mésange a déjà commencé son nid !",
        img: "birdhouse,garden,spring"
      }
    ],
    "36-38 ans": [
      {
        id: "nat_36_38_1",
        text: "Le compostage, c'est plus simple qu'on ne le pense.",
        description: "Réduire ses déchets tout en nourrissant ses plantes. Un petit geste pour la planète.",
        img: "compost,earth,green"
      }
    ],
    "39-41 ans": [
      {
        id: "nat_39_41_1",
        text: "Forêt domaniale : notre refuge du dimanche.",
        description: "Le rituel familial pour évacuer le stress de la semaine. Les arbres ont un pouvoir apaisant.",
        img: "forest,family,walk"
      }
    ],
    "42-44 ans": [
      {
        id: "nat_42_44_1",
        text: "Observer les étoiles loin des villes.",
        description: "On a sorti le télescope hier soir. La Voie Lactée était d'une clarté incroyable. On se sent tout petit.",
        img: "stars,telescope,night"
      }
    ],
    "45-47 ans": [
      {
        id: "nat_45_47_1",
        text: "Le retour au source : projet maison de campagne.",
        description: "On cherche un petit coin de verdure pour les week-ends. Besoin de terre et de calme.",
        img: "countryside,house,nature"
      }
    ],
    "48-50 ans": [
      {
        id: "nat_48_50_1",
        text: "La photo de nature : ma nouvelle passion.",
        description: "Prendre le temps d'attendre le bon moment pour capturer un oiseau ou un rayon de soleil.",
        img: "photography,nature,camera"
      }
    ],
    "51-53 ans": [
      {
        id: "nat_51_53_1",
        text: "Voyage naturaliste en Islande.",
        description: "Les paysages sont bruts, puissants. On se rend compte de la fragilité de notre écosystème.",
        img: "iceland,landscape,volcano"
      }
    ],
    "54-56 ans": [
      {
        id: "nat_54_56_1",
        text: "Le plaisir d'un jardin bien entretenu.",
        description: "Tailler les rosiers, tondre la pelouse... C'est ma méditation à moi.",
        img: "garden,roses,peace"
      }
    ],
    "57-59 ans": [
      {
        id: "nat_57_59_1",
        text: "Randonnée pédestre sur le GR20.",
        description: "Un défi physique et une immersion totale dans la montagne. La Corse est magnifique.",
        img: "hiking,mountains,corsica"
      }
    ],
    "60-62 ans": [
      {
        id: "nat_60_62_1",
        text: "Bénévolat pour la protection des oiseaux.",
        description: "Donner de son temps pour préserver la biodiversité locale. C'est gratifiant.",
        img: "birds,protection,volunteer"
      }
    ],
    "63-65 ans": [
      {
        id: "nat_63_65_1",
        text: "La beauté des saisons qui passent.",
        description: "Chaque période a son charme. L'automne et ses couleurs flamboyantes restent mes préférés.",
        img: "autumn,leaves,forest"
      }
    ],
    "Général": [
      { 
        id: "nat_gen_1",
        text: "Le silence de la forêt est le meilleur remède.", 
        description: "Une heure de marche sans téléphone permet de se reconnecter à ses sens. Écoutez le vent, observez la lumière.",
        img: "forest,sunlight,peace" 
      },
      {
        id: "nat_gen_2",
        text: "Cultiver son propre potager, même en ville.",
        description: "Quelques herbes aromatiques sur un balcon suffisent à changer votre cuisine. C'est gratifiant de voir pousser ce qu'on mange.",
        img: "garden,balcony,plants"
      },
      {
        id: "nat_gen_3",
        text: "La majesté des montagnes enneigées.",
        description: "Un spectacle dont on ne se lasse jamais. La pureté de l'air et le silence des sommets.",
        img: "mountains,snow,peak"
      }
    ]
  },
  "Politique": {
    "12-14 ans": [
      { 
        id: "pol_12_14_1",
        text: "Le brevet des collèges : pourquoi tant de stress ?", 
        description: "Les profs nous mettent une pression de dingue alors que c'est que le début. Est-ce que ça compte vraiment pour la suite ?",
        img: "school,exam,stress" 
      },
      {
        id: "pol_12_14_2",
        text: "Pourquoi on n'apprend pas des trucs utiles à l'école ?",
        description: "Genre comment payer ses impôts ou gérer un budget. Au lieu de ça, on apprend des dates de guerres par cœur.",
        img: "classroom,bored,student"
      }
    ],
    "15-17 ans": [
      { 
        id: "pol_15_17_1",
        text: "La nouvelle réforme du Bac est une catastrophe.", 
        description: "Le contrôle continu transforme chaque semaine en période d'examen. Le stress est permanent au lycée.",
        img: "high-school,exam,papers" 
      },
      { 
        id: "pol_15_17_2",
        text: "Parcoursup : le stress monte. Pourquoi c'est si opaque ?", 
        description: "Des milliers de lycéens attendent des réponses qui semblent aléatoires. L'avenir ne devrait pas dépendre d'un algorithme.",
        img: "student,waiting,laptop" 
      },
      {
        id: "pol_15_17_3",
        text: "Manif pour le climat : on était des milliers ! 🌍",
        description: "C'est notre avenir qui est en jeu. Les politiques doivent agir maintenant, pas dans 20 ans.",
        img: "protest,climate,youth"
      }
    ],
    "18-20 ans": [
      { 
        id: "pol_18_20_1",
        text: "La précarité étudiante : on n'en parle pas assez.", 
        description: "Entre le loyer, les courses et les frais d'inscription, beaucoup d'entre nous doivent travailler à côté. C'est dur de réussir dans ces conditions.",
        img: "student,empty,fridge" 
      },
      {
        id: "pol_18_20_2",
        text: "Le droit de vote à 16 ans : pour ou contre ?",
        description: "Si on est assez vieux pour travailler et payer des impôts, on devrait être assez vieux pour choisir nos représentants.",
        img: "vote,youth,politics"
      }
    ],
    "21-23 ans": [
      {
        id: "pol_21_23_1",
        text: "Premier vote, première déception ?",
        description: "On attendait du changement, mais on a l'impression que les promesses s'envolent vite après l'élection.",
        img: "vote,disappointed,youth"
      }
    ],
    "24-26 ans": [
      {
        id: "pol_24_26_1",
        text: "L'accès au logement pour les jeunes actifs.",
        description: "Des dossiers impossibles, des prix délirants... Comment on est censés construire notre vie dans ces conditions ?",
        img: "apartment,keys,city"
      }
    ],
    "27-29 ans": [
      {
        id: "pol_27_29_1",
        text: "La fiscalité quand on commence à gagner sa vie.",
        description: "Le choc de la première feuille d'impôts. On comprend enfin où part notre argent, mais c'est douloureux.",
        img: "taxes,money,papers"
      }
    ],
    "30-32 ans": [
      {
        id: "pol_30_32_1",
        text: "Politique familiale : les places en crèche.",
        description: "Un vrai parcours du combattant. Pourquoi est-ce si difficile d'avoir des services publics adaptés aux parents ?",
        img: "nursery,kids,waiting"
      }
    ],
    "33-35 ans": [
      {
        id: "pol_33_35_1",
        text: "Éducation nationale : quel avenir pour nos enfants ?",
        description: "On s'inquiète des classes surchargées et du manque de moyens. L'école devrait être la priorité absolue.",
        img: "school,classroom,students"
      }
    ],
    "36-38 ans": [
      {
        id: "pol_36_38_1",
        text: "La vie politique locale : engagez-vous !",
        description: "C'est au niveau de la commune qu'on peut vraiment changer les choses. Pourquoi ne pas se présenter aux prochaines élections ?",
        img: "town-hall,vote,local"
      }
    ],
    "39-41 ans": [
      {
        id: "pol_39_41_1",
        text: "Le pouvoir d'achat des familles moyennes.",
        description: "On a l'impression de travailler toujours plus pour le même résultat à la fin du mois. La classe moyenne est étouffée.",
        img: "shopping,cart,expensive"
      }
    ],
    "42-44 ans": [
      {
        id: "pol_42_44_1",
        text: "La réforme des retraites : on en reparle ?",
        description: "On commence à faire les calculs et ce n'est pas rassurant. Travailler plus longtemps pour gagner moins ?",
        img: "retirement,calculator,stress"
      }
    ],
    "45-47 ans": [
      {
        id: "pol_45_47_1",
        text: "L'écologie politique : au-delà des discours.",
        description: "On attend des mesures concrètes, pas juste des taxes. Comment concilier fin du monde et fin du mois ?",
        img: "ecology,politics,earth"
      }
    ],
    "48-50 ans": [
      {
        id: "pol_48_50_1",
        text: "La transmission du patrimoine : un sujet tabou.",
        description: "Comment aider ses enfants sans se ruiner ? Les droits de succession sont un vrai débat de société.",
        img: "inheritance,money,family"
      }
    ],
    "51-53 ans": [
      {
        id: "pol_51_53_1",
        text: "Le vote des seniors : un poids déterminant.",
        description: "Notre génération a le pouvoir de faire basculer les élections. Utilisons notre voix avec sagesse.",
        img: "vote,ballot,senior"
      }
    ],
    "54-56 ans": [
      {
        id: "pol_54_56_1",
        text: "La désertification médicale en province.",
        description: "Trouver un spécialiste devient impossible. C'est une rupture d'égalité inacceptable sur le territoire.",
        img: "doctor,waiting,rural"
      }
    ],
    "57-59 ans": [
      {
        id: "pol_57_59_1",
        text: "La défense des services publics.",
        description: "Poste, gares, hôpitaux... Tout ferme dans nos campagnes. Il faut se mobiliser pour garder nos villages vivants.",
        img: "village,station,closed"
      }
    ],
    "60-62 ans": [
      {
        id: "pol_60_62_1",
        text: "La vie associative : le moteur de la démocratie.",
        description: "S'engager dans une association, c'est aussi faire de la politique au sens noble du terme. Créer du lien.",
        img: "association,meeting,people"
      }
    ],
    "63-65 ans": [
      {
        id: "pol_63_65_1",
        text: "L'Europe : quel bilan pour notre génération ?",
        description: "On a connu les frontières, puis l'ouverture. Aujourd'hui, le projet européen semble fragile. Qu'en pensez-vous ?",
        img: "europe,flag,unity"
      }
    ],
    "60-65 ans": [
      { 
        id: "pol_60_65_1",
        text: "Encore une baisse des pensions de retraite annoncée...", 
        description: "Après une vie de travail, voir son pouvoir d'achat s'effriter est une insulte. Les seniors sont les oubliés.",
        img: "elderly,poverty,bills" 
      },
      {
        id: "pol_60_65_2",
        text: "Le système de santé se dégrade, c'est inquiétant.",
        description: "Trouver un médecin traitant devient un parcours du combattant. On paye toute notre vie pour un service qui disparaît.",
        img: "hospital,waiting,senior"
      }
    ]
  },
  "Meme": {
    "Général": [
      { 
        id: "meme_gen_1",
        text: "Monday morning mood.", 
        description: "Quand ton réveil sonne et que tu réalises que tu n'es pas encore millionnaire.",
        img: "grumpy,cat,morning" 
      },
      { 
        id: "meme_gen_2",
        text: "Me waiting for the weekend like...", 
        description: "On est seulement mardi et j'ai déjà l'impression d'avoir vécu trois semaines de stress.",
        img: "skeleton,bench,waiting" 
      },
      {
        id: "meme_gen_3",
        text: "Quand tu vois ton compte en banque après le week-end.",
        description: "Je pensais avoir été raisonnable, mais apparemment non.",
        img: "empty,wallet,funny"
      },
      {
        id: "meme_gen_4",
        text: "Moi essayant de comprendre les maths.",
        description: "C'est du chinois à ce niveau-là.",
        img: "confused,math,meme"
      },
      {
        id: "meme_gen_5",
        text: "Le café : mon seul ami le matin.",
        description: "Ne me parlez pas avant ma deuxième tasse.",
        img: "coffee,mug,tired"
      },
      {
        id: "meme_gen_6",
        text: "Quand tu réalises que Noël est dans 2 mois.",
        description: "Le temps passe trop vite, je n'ai pas encore de cadeaux !",
        img: "christmas,panic,time"
      },
      {
        id: "meme_gen_7",
        text: "Moi attendant que mon code compile.",
        description: "C'est le moment idéal pour aller faire une sieste.",
        img: "waiting,computer,developer"
      },
      {
        id: "meme_gen_8",
        text: "Quand tu trouves enfin le bug après 4 heures.",
        description: "C'était juste un point-virgule manquant. Je pleure.",
        img: "success,happy,coding"
      },
      {
        id: "meme_gen_9",
        text: "Ma motivation le lundi vs le vendredi.",
        description: "C'est le jour et la nuit, littéralement.",
        img: "comparison,funny,office"
      },
      {
        id: "meme_gen_10",
        text: "Quand tu dis 'je serai là dans 5 min' mais que tu es encore sous la douche.",
        description: "On connaît tous cette personne (c'est moi).",
        img: "shower,running,late"
      }
    ]
  },
  "Société": {
    "12-14 ans": [
      { 
        id: "soc_12_14_1",
        text: "Le harcèlement au collège : brisons le silence.", 
        description: "Ça commence par des moqueries et ça finit par détruire des vies. Si vous voyez quelque chose, parlez-en.",
        img: "school,bullying,sad" 
      },
      {
        id: "soc_12_14_2",
        text: "L'amitié, c'est ce qu'il y a de plus important.",
        description: "On se soutient dans les bons comme dans les mauvais moments. Tag ton meilleur pote !",
        img: "friends,laughing,teen"
      }
    ],
    "15-17 ans": [
      {
        id: "soc_15_17_1",
        text: "Le premier job d'été : une expérience formatrice.",
        description: "Travailler en tant que serveur ou animateur, ça apprend la valeur de l'argent et le respect du travail des autres.",
        img: "summer,job,working"
      },
      {
        id: "soc_15_17_2",
        text: "L'engagement associatif chez les jeunes.",
        description: "On peut tous agir à notre échelle, que ce soit pour l'environnement ou pour aider les plus démunis.",
        img: "volunteering,community,help"
      }
    ],
    "18-20 ans": [
      {
        id: "soc_18_20_1",
        text: "La vie en colocation : les joies et les galères.",
        description: "Partager son quotidien avec des amis, c'est génial, mais la vaisselle sale peut vite devenir un sujet de tension.",
        img: "roommates,kitchen,fun"
      }
    ],
    "21-23 ans": [
      {
        id: "soc_21_23_1",
        text: "L'entrée dans le monde du travail.",
        description: "On passe du statut d'étudiant à celui de salarié. Un grand changement de rythme et de responsabilités.",
        img: "office,suit,young"
      }
    ],
    "24-26 ans": [
      {
        id: "soc_24_26_1",
        text: "Le quart de vie : la crise des 25 ans.",
        description: "On se demande si on a fait les bons choix. C'est normal de douter, on a toute la vie devant nous.",
        img: "thinking,young,adult"
      }
    ],
    "27-29 ans": [
      {
        id: "soc_27_29_1",
        text: "Le mariage : une étape ou une tradition ?",
        description: "Beaucoup de mes amis se marient. C'est beau de voir l'engagement, mais c'est aussi beaucoup d'organisation !",
        img: "wedding,rings,celebration"
      }
    ],
    "30-32 ans": [
      {
        id: "soc_30_32_1",
        text: "Devenir parent : le plus grand défi.",
        description: "On ne dort plus, on s'inquiète pour tout, mais un sourire efface tout. La vie change radicalement.",
        img: "parent,baby,love"
      }
    ],
    "33-35 ans": [
      {
        id: "soc_33_35_1",
        text: "L'équilibre entre vie pro et vie perso.",
        description: "Apprendre à dire non au travail pour profiter de sa famille. C'est un combat de tous les jours.",
        img: "balance,work,life"
      }
    ],
    "36-38 ans": [
      {
        id: "soc_36_38_1",
        text: "La crise de la quarantaine approche ?",
        description: "On a envie de changer de vie, de faire un marathon ou de s'acheter une moto. Besoin de se sentir vivant.",
        img: "running,marathon,adult"
      }
    ],
    "39-41 ans": [
      {
        id: "soc_39_41_1",
        text: "Gérer l'adolescence de ses enfants.",
        description: "On ne les comprend plus, ils ne nous écoutent plus. C'est une période de transition pour tout le monde.",
        img: "teenager,parent,argument"
      }
    ],
    "42-44 ans": [
      {
        id: "soc_42_44_1",
        text: "Prendre soin de ses parents vieillissants.",
        description: "Les rôles s'inversent. C'est à notre tour de veiller sur eux. Une étape émouvante et parfois difficile.",
        img: "caring,elderly,hand"
      }
    ],
    "45-47 ans": [
      {
        id: "soc_45_47_1",
        text: "Le syndrome du nid vide.",
        description: "Les enfants partent faire leurs études. La maison semble bien grande et bien silencieuse d'un coup.",
        img: "empty,house,thinking"
      }
    ],
    "48-50 ans": [
      {
        id: "soc_48_50_1",
        text: "Le bilan de milieu de vie.",
        description: "On regarde en arrière avec fierté et en avant avec sérénité. L'essentiel est ailleurs.",
        img: "serenity,sunset,adult"
      }
    ],
    "51-53 ans": [
      {
        id: "soc_51_53_1",
        text: "Se redécouvrir en tant que couple.",
        description: "Maintenant que les enfants sont grands, on a enfin du temps pour nous deux. Redécouvrir ses passions communes.",
        img: "couple,travel,happy"
      }
    ],
    "54-56 ans": [
      {
        id: "soc_54_56_1",
        text: "La transmission intergénérationnelle.",
        description: "Passer du temps avec ses petits-enfants, c'est une cure de jouvence. Leur apprendre des choses simples.",
        img: "grandparent,child,playing"
      }
    ],
    "57-59 ans": [
      {
        id: "soc_57_59_1",
        text: "Préparer sa sortie de la vie active.",
        description: "On commence à ranger son bureau, à transmettre ses dossiers. Une page qui se tourne doucement.",
        img: "office,packing,retirement"
      }
    ],
    "60-62 ans": [
      {
        id: "soc_60_62_1",
        text: "La nouvelle liberté de la retraite.",
        description: "Plus d'horaires, plus de stress. Juste le plaisir de choisir ce qu'on veut faire de ses journées.",
        img: "freedom,beach,senior"
      }
    ],
    "63-65 ans": [
      {
        id: "soc_63_65_1",
        text: "L'importance du lien social à tout âge.",
        description: "Rester actif dans son quartier, voir ses amis, participer à des activités. C'est le secret de la longévité.",
        img: "friends,coffee,senior"
      }
    ],
    "66+ ans": [
      { 
        id: "soc_66_1",
        text: "La solitude des personnes âgées : un fléau invisible.", 
        description: "Des millions de seniors passent des journées entières sans parler à personne. Le lien social est vital.",
        img: "lonely,senior,window" 
      },
      {
        id: "soc_66_2",
        text: "Transmettre ses souvenirs aux plus jeunes.",
        description: "On a tant de choses à raconter. J'ai commencé à écrire mes mémoires pour que mes petits-enfants sachent d'où ils viennent.",
        img: "writing,old,hands"
      }
    ]
  },
  "Général": {
    "Général": [
      { 
        id: "gen_gen_1",
        text: "Une belle journée pour explorer de nouveaux horizons.", 
        description: "Parfois, il suffit de changer de rue pour découvrir un nouveau monde. Gardez les yeux ouverts.",
        img: "sunny,day,explorer" 
      },
      {
        id: "gen_gen_2",
        text: "La lecture est une fenêtre ouverte sur le monde.",
        description: "Prendre le temps de lire un livre, c'est s'offrir une pause dans le tumulte du quotidien. Quel est votre livre du moment ?",
        img: "book,reading,coffee"
      },
      {
        id: "gen_gen_3",
        text: "L'importance de la gratitude au quotidien.",
        description: "Noter trois choses positives chaque jour peut transformer votre vision de la vie. Essayez, c'est magique.",
        img: "journal,pen,flowers"
      },
      {
        id: "gen_gen_4",
        text: "Une recette simple pour un dîner réussi.",
        description: "Des pâtes fraîches, un peu de basilic et beaucoup d'amour. La simplicité est souvent la clé du bonheur.",
        img: "pasta,cooking,home"
      }
    ]
  },
  "Gastronomie": {
    "Général": [
      {
        id: "gast_gen_1",
        text: "Le secret d'une pizza maison réussie. 🍕",
        description: "Tout est dans la pâte et le temps de repos. On vous donne la recette de la mamma.",
        img: "pizza,homemade,flour"
      },
      {
        id: "gast_gen_2",
        text: "Dégustation de vins dans le Bordelais.",
        description: "Une expérience sensorielle unique au cœur des vignes. Le terroir a tant à nous dire.",
        img: "wine,vineyard,glass"
      }
    ]
  },
  "Voyage": {
    "Général": [
      {
        id: "voy_gen_1",
        text: "Top 5 des destinations secrètes en Europe.",
        description: "Loin de la foule, ces endroits vont vous couper le souffle. Préparez votre sac à dos !",
        img: "travel,hidden,europe"
      },
      {
        id: "voy_gen_2",
        text: "Le Japon : entre tradition et modernité.",
        description: "Un voyage qui change une vie. Des temples de Kyoto aux néons de Tokyo.",
        img: "japan,tokyo,temple"
      }
    ]
  },
  "Art": {
    "Général": [
      {
        id: "art_gen_1",
        text: "L'art abstrait : comment le comprendre ?",
        description: "Ce n'est pas juste des taches de couleur. C'est une émotion brute projetée sur la toile.",
        img: "abstract,painting,canvas"
      }
    ]
  },
  "Musique": {
    "Général": [
      {
        id: "mus_gen_1",
        text: "Le retour du vinyle : pourquoi on adore ?",
        description: "Le son chaud, l'objet, le rituel... Écouter un disque est une expérience à part entière.",
        img: "vinyl,record,player"
      }
    ]
  },
  "Espace": {
    "Général": [
      {
        id: "esp_gen_1",
        text: "James Webb : les nouvelles images sont folles.",
        description: "On remonte le temps jusqu'aux premières galaxies. L'univers est plus vaste qu'on ne l'imaginait.",
        img: "space,galaxy,telescope"
      }
    ]
  },
  "Histoire": {
    "Général": [
      {
        id: "hist_gen_1",
        text: "Les mystères de l'Égypte antique.",
        description: "Comment ont-ils construit les pyramides avec une telle précision ? Le débat reste ouvert.",
        img: "egypt,pyramids,ancient"
      }
    ]
  },
  "Niche": {
    "Général": [
      {
        id: "niche_gen_1",
        text: "L'art du bonsaï : patience et précision.",
        description: "Plus qu'un jardinage, c'est une philosophie de vie. Chaque branche raconte une histoire.",
        img: "bonsai,tree,zen"
      }
    ]
  },
  "Bait": {
    "Sceptique": [
      { 
        id: "bait_scep_1",
        text: "ALERTE : Les nouvelles conditions d'utilisation cachent quelque chose de grave.", 
        description: "Avez-vous vraiment lu les 50 pages du contrat ? Ils s'autorisent désormais à utiliser votre voix pour entraîner des IA sans votre consentement explicite.",
        img: "hidden,text" 
      },
      {
        id: "bait_scep_2",
        text: "Pourquoi on nous cache la vérité sur les pyramides ?",
        description: "De nouvelles découvertes suggèrent qu'elles n'ont pas été construites par les Égyptiens. Cliquez pour voir les preuves.",
        img: "pyramids,mystery,secret"
      }
    ],
    "Général": [
      {
        id: "bait_gen_1",
        text: "Cette astuce va changer votre vie ! 💡",
        description: "99% des gens ne connaissent pas cette méthode simple pour économiser 500€ par mois. Ne passez pas à côté.",
        img: "money,savings,hack"
      },
      {
        id: "bait_gen_2",
        text: "Vous ne devinerez jamais ce que cette star a fait.",
        description: "Une transformation incroyable qui laisse tout le monde sans voix. Les photos sont choquantes.",
        img: "celebrity,shocking,news"
      }
    ]
  }
};

const AUTHORS: Record<string, string[]> = {
  "Technologie": ["Tech Insider", "Cyber Pulse", "Future Watch", "Digital Nomad", "Silicon Valley News"],
  "Nature": ["Nature Explorer", "Green Spirit", "Wild Life", "Eco Warrior", "Earth Guardian"],
  "Cinéma": ["Cinema Fanatic", "Movie Buff", "Screen Weekly", "Film Critic", "Hollywood Reporter"],
  "Politique": ["Citizen Voice", "Global Observer", "Policy Lab", "Truth Seeker", "Democracy Watch"],
  "Sport": ["Sport Daily", "Athletic Mind", "Game On", "Pro Athlete", "Stadium Pulse"],
  "Meme": ["Meme Lord", "Internet Culture", "Gamer Humor", "Daily Laughs", "Viral Content"],
  "Bait": ["Viral Alert", "Truth Seeker", "Life Coach", "Community Hub", "Nostalgia Trip"],
  "Gastronomie": ["Foodie Guide", "Chef Talk", "Wine Enthusiast", "Kitchen Secrets", "Taste Explorer"],
  "Voyage": ["Globe Trotter", "Travel Diary", "Wanderlust", "Passport Ready", "Hidden Gems"],
  "Art": ["Art Gallery", "Creative Soul", "Museum Lover", "Design Daily", "Canvas & Color"],
  "Musique": ["Sound Wave", "Music Junkie", "Vinyl Collector", "Concert Goer", "Beat Master"],
  "Espace": ["Cosmos Today", "Star Gazer", "NASA Fan", "Space Explorer", "Galaxy News"],
  "Histoire": ["History Buff", "Past Tense", "Archive Room", "Ancient World", "Legacy Watch"],
  "Niche": ["Niche Explorer", "Specialist Hub", "Expert Corner", "Curious Mind", "Deep Dive"],
  "Société": ["Social Pulse", "Community Voice", "Modern Life", "Citizen News", "People Today"],
  "Général": ["Daily Life", "Human Touch", "World View", "Common Sense", "Street Journal"]
};

export async function analyzeUserPost(content: string) {
  const lowerContent = content.toLowerCase();
  const themes = Object.entries(INTEREST_KEYWORDS)
    .filter(([_, keywords]) => keywords.some(k => lowerContent.includes(k)))
    .map(([theme]) => theme);
  
  return `Analyse locale : Thèmes détectés : ${themes.join(', ') || 'Général'}. Ton : Neutre.`;
}

export async function analyzeInteraction(interaction: Interaction, postContent: string) {
  return `Interaction simulée : Type ${interaction.type}. Intérêt estimé : ${interaction.duration && interaction.duration > 2000 ? 'Élevé' : 'Moyen'}.`;
}

// Track used templates globally in this session
const usedTemplateIds = new Set<string>();

export async function generateBatchPosts(profile: UserProfile, count: number = 5): Promise<Post[]> {
  const posts: Post[] = [];
  const interests = profile.interests;
  const ageGroup = profile.ageGroup || "Général";
  const isInitial = interests.length === 1 && interests[0] === 'Général';
  
  for (let i = 0; i < count; i++) {
    let theme: string;
    const rand = Math.random();
    
    if (isInitial) {
      const allThemes = Object.keys(POST_TEMPLATES);
      theme = allThemes[Math.floor(Math.random() * allThemes.length)];
    } else {
      if (Math.random() < 0.25) {
        const allThemes = Object.keys(POST_TEMPLATES);
        theme = allThemes[Math.floor(Math.random() * allThemes.length)];
      } 
      else if (Math.random() < 0.2) {
        theme = "Meme";
      } else if (Math.random() < 0.1) {
        theme = "Bait";
      } else if (rand < 0.7) {
        theme = interests[Math.floor(Math.random() * interests.length)];
      } else {
        const allThemes = Object.keys(POST_TEMPLATES);
        theme = allThemes[Math.floor(Math.random() * allThemes.length)];
      }
    }
    
    const themeTemplates = POST_TEMPLATES[theme] || POST_TEMPLATES["Général"];
    
    const trait = profile.traits.find(t => themeTemplates[t]);
    let templates: PostTemplate[];
    
    if (trait && Math.random() < 0.6) {
      templates = themeTemplates[trait];
    } else if (profile.ageGroup && themeTemplates[profile.ageGroup]) {
      templates = themeTemplates[profile.ageGroup];
    } else {
      templates = themeTemplates[ageGroup] || themeTemplates["Général"] || POST_TEMPLATES["Général"]["Général"];
    }
    
    // Filter out used templates if possible
    let availableTemplates = templates.filter(t => !usedTemplateIds.has(t.id));
    
    // If no specific templates available, try to find ANY unused template in the same theme
    if (availableTemplates.length === 0) {
      const allThemeTemplates = Object.values(themeTemplates).flat();
      availableTemplates = allThemeTemplates.filter(t => !usedTemplateIds.has(t.id));
    }

    // If still nothing, try to find ANY unused template in Général
    if (availableTemplates.length === 0) {
      const generalTemplates = Object.values(POST_TEMPLATES["Général"]).flat();
      availableTemplates = generalTemplates.filter(t => !usedTemplateIds.has(t.id));
    }

    // Last resort: reset and pick from original pool
    if (availableTemplates.length === 0) {
      availableTemplates = templates;
    }
    
    const authors = AUTHORS[theme] || AUTHORS["Général"];
    const template = availableTemplates[Math.floor(Math.random() * availableTemplates.length)];
    
    // Mark as used
    usedTemplateIds.add(template.id);
    
    const hasImage = Math.random() < 0.9;
    // Use a combination of template ID, profile data and random to ensure uniqueness
    const seedBase = template.id.split('_').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const uniqueSeed = seedBase + Math.floor(Math.random() * 50000) + (profile.ageGroup?.length || 0) * 100;
    const imageUrl = hasImage ? `https://loremflickr.com/800/600/${template.img},photography,hd?lock=${uniqueSeed}` : undefined;

    posts.push({
      id: Math.random().toString(36).substr(2, 9),
      author: authors[Math.floor(Math.random() * authors.length)],
      content: template.text,
      description: template.description,
      imageUrl,
      timestamp: Date.now() - (i * 1000 * 60 * 10),
      likes: Math.floor(Math.random() * 200),
      comments: [],
      shares: Math.floor(Math.random() * 50),
      isAI: true
    });
  }
  
  return posts;
}

export async function updateProfile(history: string[], behavioralData: string): Promise<UserProfile> {
  const fullHistory = history.join(' ').toLowerCase();
  
  // Slower detection: require at least 2 occurrences of keywords for interests and traits
  const countOccurrences = (keywords: string[]) => {
    return keywords.reduce((acc, k) => {
      const regex = new RegExp(k, 'g');
      return acc + (fullHistory.match(regex) || []).length;
    }, 0);
  };

  const detectedInterests = Object.entries(INTEREST_KEYWORDS)
    .filter(([_, keywords]) => countOccurrences(keywords) >= 2)
    .map(([theme]) => theme);
  
  const detectedTraits = Object.entries(TRAIT_KEYWORDS)
    .filter(([_, keywords]) => countOccurrences(keywords) >= 2)
    .map(([trait]) => trait);

  const detectedAgeGroups = Object.entries(AGE_KEYWORDS)
    .filter(([_, keywords]) => countOccurrences(keywords) >= 2)
    .map(([age]) => age);

  const interests = detectedInterests.length > 0 ? detectedInterests : ["Général"];
  const traits = detectedTraits.length > 0 ? detectedTraits : ["Observateur"];
  const ageGroup = detectedAgeGroups.length > 0 ? detectedAgeGroups[0] : undefined;
  
  return {
    traits: traits,
    interests: interests,
    opinions: ["Analyse en cours..."],
    ageGroup: ageGroup,
    rawAnalysis: `SYSTÈME_HORS_LIGNE : Analyse comportementale profonde effectuée. 
    - Profil psychologique : ${traits.join(', ')}.
    - Centres d'intérêt dominants : ${interests.join(', ')}.
    - Tranche d'âge estimée : ${ageGroup || 'Inconnue'}.
    - Niveau d'engagement : ${behavioralData.includes('Like') ? 'Actif' : 'Passif'}.
    - Temps d'attention moyen : ${Math.round(parseInt(behavioralData.match(/Temps total: (\d+)/)?.[1] || '0') / history.length)}ms/post.
    - Patterns détectés : ${behavioralData}`
  };
}
