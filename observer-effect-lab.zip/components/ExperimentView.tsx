
import React from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { ExperimentResult } from '../types';

interface Props {
  control: ExperimentResult | null;
  observed: ExperimentResult | null;
}

const ExperimentView: React.FC<Props> = ({ control, observed }) => {
  if (!control || !observed) {
    return (
      <div className="flex flex-col items-center justify-center h-64 border-2 border-dashed border-zinc-800 rounded-lg text-zinc-500">
        <p>No experimental data available. Run simulation to generate.</p>
      </div>
    );
  }

  // Align snapshots for side-by-side comparison
  const combinedData = control.snapshots.map((s, idx) => {
    const o = observed.snapshots[idx];
    return {
      tick: s.tick,
      controlLatency: s.avgLatency,
      observedLatency: o?.avgLatency || 0,
      controlQueue: s.totalQueueDepth,
      observedQueue: o?.totalQueueDepth || 0,
      divergence: Math.abs(s.avgLatency - (o?.avgLatency || 0))
    };
  });

  return (
    <div className="space-y-12">
      {/* Metrics Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-4 bg-zinc-900 border border-zinc-800 rounded">
          <h3 className="text-xs uppercase text-zinc-500 mb-2 mono">Throughput Variation</h3>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold">{((observed.events.length / control.events.length) * 100 - 100).toFixed(2)}%</span>
            <span className="text-xs text-zinc-400">relative to control</span>
          </div>
        </div>
        <div className="p-4 bg-zinc-900 border border-zinc-800 rounded">
          <h3 className="text-xs uppercase text-zinc-500 mb-2 mono">Execution Overhead</h3>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold">{observed.totalExecutionTimeMs.toFixed(0)}ms</span>
            <span className="text-xs text-zinc-400">vs {control.totalExecutionTimeMs.toFixed(0)}ms</span>
          </div>
        </div>
        <div className="p-4 bg-zinc-900 border border-zinc-800 rounded">
          <h3 className="text-xs uppercase text-zinc-500 mb-2 mono">Divergence Score</h3>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-orange-500">
                {(combinedData.reduce((acc, d) => acc + d.divergence, 0) / combinedData.length).toFixed(2)}
            </span>
            <span className="text-xs text-zinc-400">avg latency delta</span>
          </div>
        </div>
      </div>

      {/* Latency Comparison */}
      <section>
        <h2 className="text-lg font-semibold mb-4 mono flex items-center gap-2">
          <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
          Latency Distribution (Moving Average)
        </h2>
        <div className="h-[300px] w-full bg-zinc-900/50 p-4 rounded-lg border border-zinc-800">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={combinedData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
              <XAxis dataKey="tick" stroke="#52525b" fontSize={10} />
              <YAxis stroke="#52525b" fontSize={10} label={{ value: 'Ticks', angle: -90, position: 'insideLeft', fill: '#52525b' }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', fontSize: '12px' }}
                itemStyle={{ color: '#d4d4d4' }}
              />
              <Legend verticalAlign="top" height={36}/>
              <Line type="monotone" dataKey="controlLatency" name="Control (Silent)" stroke="#3b82f6" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="observedLatency" name="Observed (Intrusive)" stroke="#ef4444" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Queue Depth Comparison */}
      <section>
        <h2 className="text-lg font-semibold mb-4 mono flex items-center gap-2">
          <span className="w-2 h-2 bg-green-500 rounded-full"></span>
          Aggregate Queue Depth
        </h2>
        <div className="h-[300px] w-full bg-zinc-900/50 p-4 rounded-lg border border-zinc-800">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={combinedData}>
              <defs>
                <linearGradient id="colorControl" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorObserved" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
              <XAxis dataKey="tick" stroke="#52525b" fontSize={10} />
              <YAxis stroke="#52525b" fontSize={10} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#18181b', border: '1px solid #3f3f46', fontSize: '12px' }}
              />
              <Area type="step" dataKey="controlQueue" name="Control Queue" stroke="#3b82f6" fillOpacity={1} fill="url(#colorControl)" />
              <Area type="step" dataKey="observedQueue" name="Observed Queue" stroke="#ef4444" fillOpacity={1} fill="url(#colorObserved)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Technical Log */}
      <section className="bg-zinc-900 border border-zinc-800 rounded p-6">
        <h2 className="text-xs uppercase text-zinc-500 mb-4 mono">Experimental Log</h2>
        <div className="space-y-2 text-xs mono text-zinc-400">
          <p>[INFO] INITIAL_SEED: {control.config.seed}</p>
          <p>[INFO] OBSERVER_INTENSITY: {observed.config.observerIntensity}</p>
          <p>[INFO] EVENTS_PROCESSED_CONTROL: {control.events.length}</p>
          <p>[INFO] EVENTS_PROCESSED_OBSERVED: {observed.events.length}</p>
          <p className={Math.abs(control.events.length - observed.events.length) > 0 ? "text-orange-400" : ""}>
            [RESULT] System divergence detected: {control.events.length !== observed.events.length ? "TRUE" : "FALSE (IDENTICAL LOGIC)"}
          </p>
          <p className="mt-4 italic opacity-60">Note: Even with identical logic and seeds, CPU scheduling contention from the observer alters the real-world processing window for subsequent events.</p>
        </div>
      </section>
    </div>
  );
};

export default ExperimentView;
