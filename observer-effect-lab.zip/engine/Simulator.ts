
import { PRNG } from './PRNG';
import { Observer } from './Observer';
import { 
  SimulationConfig, 
  EventRecord, 
  Snapshot, 
  ExperimentResult, 
  ObserverIntensity 
} from '../types';

interface Node {
  id: number;
  queue: { createdTick: number; id: string }[];
  busyUntil: number;
}

export class Simulator {
  private config: SimulationConfig;
  private prng: PRNG;
  private observer: Observer;
  private nodes: Node[];
  private events: EventRecord[] = [];
  private snapshots: Snapshot[] = [];
  private currentTick = 0;

  constructor(config: SimulationConfig) {
    this.config = config;
    this.prng = new PRNG(config.seed);
    this.observer = new Observer(config.observerIntensity);
    this.nodes = Array.from({ length: config.nodes }, (_, i) => ({
      id: i,
      queue: [],
      busyUntil: 0
    }));
  }

  run(): ExperimentResult {
    const startTime = performance.now();
    
    while (this.currentTick < this.config.totalTicks) {
      this.tick();
      
      // Snapshot every 50 ticks
      if (this.currentTick % 50 === 0) {
        this.takeSnapshot();
      }
      
      this.currentTick++;
    }

    const endTime = performance.now();

    return {
      config: this.config,
      events: this.events,
      snapshots: this.snapshots,
      divergenceDetected: false, // Calculated by comparing runs
      totalExecutionTimeMs: endTime - startTime
    };
  }

  private tick() {
    // 1. Traffic Generation
    const spawnChance = this.config.eventRate / 1000;
    const isBurst = this.prng.next() < this.config.burstiness;
    const eventsToSpawn = isBurst ? Math.ceil(spawnChance * 5) : (this.prng.next() < spawnChance ? 1 : 0);

    for (let i = 0; i < eventsToSpawn; i++) {
      const targetNodeId = this.prng.nextInt(0, this.nodes.length - 1);
      const event = { 
        id: `ev-${this.currentTick}-${i}`, 
        createdTick: this.currentTick 
      };
      
      this.nodes[targetNodeId].queue.push(event);
      
      // OBSERVE: Enqueue event
      this.observer.observe('ENQUEUE', { nodeId: targetNodeId, qSize: this.nodes[targetNodeId].queue.length });
    }

    // 2. Node Processing
    this.nodes.forEach(node => {
      if (this.currentTick >= node.busyUntil && node.queue.length > 0) {
        const event = node.queue.shift()!;
        
        // Processing time varies deterministically
        const procTime = this.prng.nextInt(2, 8);
        node.busyUntil = this.currentTick + procTime;

        this.events.push({
          id: event.id,
          createdTick: event.createdTick,
          completedTick: node.busyUntil,
          latency: node.busyUntil - event.createdTick,
          nodeId: node.id
        });

        // OBSERVE: Process event
        this.observer.observe('PROCESS', { 
            nodeId: node.id, 
            latency: node.busyUntil - event.createdTick 
        });
      }
    });
  }

  private takeSnapshot() {
    const totalQueueDepth = this.nodes.reduce((acc, n) => acc + n.queue.length, 0);
    const recentEvents = this.events.slice(-20);
    const avgLatency = recentEvents.length > 0 
      ? recentEvents.reduce((acc, e) => acc + e.latency, 0) / recentEvents.length 
      : 0;

    this.snapshots.push({
      tick: this.currentTick,
      avgLatency,
      totalQueueDepth,
      throughput: this.events.length / (this.currentTick + 1)
    });

    // OBSERVE: Snapshot metrics
    this.observer.observe('SNAPSHOT', { tick: this.currentTick, qDepth: totalQueueDepth });
  }
}
