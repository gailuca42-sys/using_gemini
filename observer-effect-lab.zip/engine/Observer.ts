
import { ObserverIntensity } from '../types';

/**
 * The Observer module mimics real-world instrumentation overhead.
 * It performs "useful" work (calculating stats) and introduces CPU/Memory pressure.
 */
export class Observer {
  private intensity: ObserverIntensity;
  private metricsBuffer: any[] = [];

  constructor(intensity: ObserverIntensity) {
    this.intensity = intensity;
  }

  /**
   * Intrusive observation hook.
   * Performs real computation proportional to intensity.
   */
  observe(context: string, data: any): void {
    if (this.intensity === ObserverIntensity.NONE) return;

    // Simulate metric serialization and memory pressure
    const payload = JSON.stringify({
      timestamp: Date.now(),
      context,
      data,
      entropy: Math.random()
    });
    
    // Store in buffer to simulate memory usage
    this.metricsBuffer.push(payload);
    if (this.metricsBuffer.length > 500) this.metricsBuffer.shift();

    // Intensive calculation: Simulated P99 or Digest calculation
    const loopCount = this.intensity * 25000; // Calibrated for noticeable browser impact
    let dummy = 0;
    for (let i = 0; i < loopCount; i++) {
      dummy += Math.sqrt(i) * Math.sin(i);
    }
    
    // Periodically 'flush' which adds a scheduling hiccup
    if (Math.random() < 0.05) {
      this.metricsBuffer.sort();
    }
  }
}
