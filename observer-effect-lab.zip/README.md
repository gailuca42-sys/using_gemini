
# Observer Effect Lab

## Hypothesis
The act of observing a distributed system introduces computational and memory pressure that alters the performance profile of the system being measured. Given identical workloads and initial state, an instrumented system will exhibit measurably higher latency and deeper queues compared to a silent one.

## Method
1. **System Model**: A discrete-event simulator with $N$ logical processing nodes.
2. **Traffic**: A deterministic event stream generated using a seeded Linear Congruential Generator (PRNG).
3. **Observability Layer**: A toggleable module that hooks into `enqueue` and `process` lifecycle events. 
   - **Workload**: On each hook, the observer performs a real computational loop (calculating digest statistics) and manages a local memory buffer (serialization).
4. **Comparison**: Two runs are executed. 
   - Run A (Control): Observer intensity = 0.
   - Run B (Experimental): Observer intensity > 0.

## Observations
- **Latency Bloat**: As observation intensity increases, the "Observed" system's latency diverges significantly from the control.
- **Queue Saturation**: Because the observer steals CPU cycles from the same event loop as the processing logic, nodes become "busy" for longer relative to clock time, leading to backpressure.
- **Resource Contention**: The divergence is non-linear; higher event rates amplify the cost of observation as the overhead becomes a larger percentage of the total processing budget.

## Conclusion
Observation is not a zero-cost operation. In high-throughput distributed systems, the instrumentation used to detect bottlenecks can itself become the primary bottleneck.
