
import React, { useState, useCallback } from 'react';
import { 
  SimulationConfig, 
  ObserverIntensity, 
  ExperimentResult 
} from './types';
import { Simulator } from './engine/Simulator';
import ExperimentView from './components/ExperimentView';

const App: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [config, setConfig] = useState<SimulationConfig>({
    nodes: 5,
    eventRate: 350,
    burstiness: 0.2,
    seed: 42,
    totalTicks: 5000,
    observerIntensity: ObserverIntensity.MEDIUM
  });

  const [results, setResults] = useState<{
    control: ExperimentResult | null;
    observed: ExperimentResult | null;
  }>({ control: null, observed: null });

  const runExperiment = useCallback(async () => {
    setIsRunning(true);
    
    // Use a small timeout to let the UI update before the heavy CPU task
    setTimeout(() => {
      // Run Control (No Observer)
      const controlSim = new Simulator({ 
        ...config, 
        observerIntensity: ObserverIntensity.NONE 
      });
      const controlResult = controlSim.run();

      // Run Observed
      const observedSim = new Simulator(config);
      const observedResult = observedSim.run();

      setResults({
        control: controlResult,
        observed: observedResult
      });
      setIsRunning(false);
    }, 100);
  }, [config]);

  return (
    <div className="min-h-screen p-6 md:p-12 max-w-7xl mx-auto">
      <header className="mb-12 border-l-4 border-orange-500 pl-6">
        <h1 className="text-4xl font-bold tracking-tighter mono text-white">Observer Effect Lab</h1>
        <p className="text-zinc-500 mt-2 max-w-2xl">
          Demonstrating that the act of measurement is not a neutral operation. 
          By introducing computational overhead and memory pressure, observability 
          directly influences the latency and scheduling of distributed services.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Controls Sidebar */}
        <aside className="lg:col-span-1 space-y-8">
          <section className="bg-zinc-900 border border-zinc-800 rounded-lg p-6">
            <h2 className="text-sm font-semibold mb-6 mono uppercase text-zinc-400">Experiment Parameters</h2>
            
            <div className="space-y-6">
              <div>
                <label className="block text-xs text-zinc-500 mb-2 mono">Observer Intensity</label>
                <select 
                  className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-orange-500"
                  value={config.observerIntensity}
                  onChange={(e) => setConfig({...config, observerIntensity: parseInt(e.target.value)})}
                >
                  <option value={ObserverIntensity.LOW}>Low (Light Metrics)</option>
                  <option value={ObserverIntensity.MEDIUM}>Medium (Aggregations)</option>
                  <option value={ObserverIntensity.HIGH}>High (Full Tracing)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs text-zinc-500 mb-2 mono">Service Nodes: {config.nodes}</label>
                <input 
                  type="range" min="1" max="10" 
                  className="w-full h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-orange-500"
                  value={config.nodes}
                  onChange={(e) => setConfig({...config, nodes: parseInt(e.target.value)})}
                />
              </div>

              <div>
                <label className="block text-xs text-zinc-500 mb-2 mono">Event Rate: {config.eventRate}</label>
                <input 
                  type="range" min="50" max="800" step="50"
                  className="w-full h-1 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-orange-500"
                  value={config.eventRate}
                  onChange={(e) => setConfig({...config, eventRate: parseInt(e.target.value)})}
                />
              </div>

              <div>
                <label className="block text-xs text-zinc-500 mb-2 mono">Reproduction Seed</label>
                <input 
                  type="number"
                  className="w-full bg-zinc-800 border border-zinc-700 rounded px-3 py-2 text-sm focus:outline-none"
                  value={config.seed}
                  onChange={(e) => setConfig({...config, seed: parseInt(e.target.value)})}
                />
              </div>

              <button 
                onClick={runExperiment}
                disabled={isRunning}
                className={`w-full py-4 rounded font-bold mono uppercase transition-all ${
                  isRunning 
                    ? "bg-zinc-800 text-zinc-600 cursor-not-allowed" 
                    : "bg-orange-600 hover:bg-orange-500 text-white shadow-lg shadow-orange-900/20"
                }`}
              >
                {isRunning ? "Simulating..." : "Execute Lab"}
              </button>
            </div>
          </section>

          <section className="text-xs text-zinc-600 space-y-4 px-2">
            <h3 className="font-bold text-zinc-500 uppercase">Scientific Method</h3>
            <p>1. <strong>Baseline:</strong> System runs with zero instrumentation. Throughput is limited only by hardware/runtime clock.</p>
            <p>2. <strong>Observation:</strong> Instrumentation hooks calculate moving averages and serialize JSON on every event.</p>
            <p>3. <strong>Hypothesis:</strong> Resource contention in the observer logic will delay event processing, leading to queue growth.</p>
          </section>
        </aside>

        {/* Results Main View */}
        <main className="lg:col-span-3">
          <div className="bg-black/40 border border-zinc-800 rounded-xl p-8 min-h-[600px]">
            {isRunning ? (
              <div className="flex flex-col items-center justify-center h-[500px] space-y-4">
                <div className="w-12 h-12 border-4 border-orange-500/20 border-t-orange-500 rounded-full animate-spin"></div>
                <p className="mono text-zinc-400 animate-pulse">Computing divergent paths...</p>
              </div>
            ) : (
              <ExperimentView control={results.control} observed={results.observed} />
            )}
          </div>
        </main>
      </div>

      <footer className="mt-12 pt-8 border-t border-zinc-900 text-zinc-700 text-[10px] mono uppercase flex justify-between">
        <span>Observer Effect Lab v1.0.4</span>
        <span>Deterministic Core: Pseudo-Random Clock Active</span>
      </footer>
    </div>
  );
};

export default App;
