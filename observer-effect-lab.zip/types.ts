
export enum ObserverIntensity {
  NONE = 0,
  LOW = 1,
  MEDIUM = 5,
  HIGH = 15
}

export interface SimulationConfig {
  nodes: number;
  eventRate: number; // events per 1000 ticks
  burstiness: number; // 0 to 1
  seed: number;
  totalTicks: number;
  observerIntensity: ObserverIntensity;
}

export interface EventRecord {
  id: string;
  createdTick: number;
  completedTick: number;
  latency: number;
  nodeId: number;
}

export interface Snapshot {
  tick: number;
  avgLatency: number;
  totalQueueDepth: number;
  throughput: number;
}

export interface ExperimentResult {
  config: SimulationConfig;
  events: EventRecord[];
  snapshots: Snapshot[];
  divergenceDetected: boolean;
  totalExecutionTimeMs: number;
}
