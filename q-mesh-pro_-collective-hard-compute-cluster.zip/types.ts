
export interface QubitState {
  alpha: { re: number; im: number };
  beta: { re: number; im: number };
}

export interface QuantumNode {
  id: string;
  alias: string;
  physicalQubits: number;
  logicalQubits: number;
  syndrome: number[];
  fidelity: number;
  lastUpdated: number;
  connections: string[];
  computePower: number; // Tflops/Gflops
  uptime: number; // Simulated hours
  circuitDepth: number;
  monteCarloShots: number;
}

export interface NetworkMessage {
  type: 'SYNC' | 'ALGO' | 'MEASURE' | 'TASK_SUBMIT' | 'RECORD_HEARTBEAT';
  senderId: string;
  payload: any;
  timestamp: number;
}

export enum AlgorithmType {
  SHOR = 'SHOR_RSA_1024_DISTRIBUTED',
  QAOA = 'QAOA_MAXCUT_P2P',
  VQE = 'COLLECTIVE_VQE_MOLECULAR',
  QMC = 'DISTRIBUTED_MONTE_CARLO_SLATER',
  BREAKTHROUGH = 'BREAKTHROUGH_MODE_612_Q'
}
