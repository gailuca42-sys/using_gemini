
import React from 'react';

interface TutorialOverlayProps {
  step: number;
  onNext: () => void;
  onSkip: () => void;
  t: any;
}

const TutorialOverlay: React.FC<TutorialOverlayProps> = ({ step, onNext, onSkip, t }) => {
  const steps = [
    { target: "network-viz", text: t.tutorial.step1 },
    { target: "metrics-panel", text: t.tutorial.step2 },
    { target: "qubit-dynamics", text: t.tutorial.step3 },
    { target: "algo-panel", text: t.tutorial.step4 },
  ];

  if (step >= steps.length) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm transition-all duration-500 pointer-events-auto">
      <div className="bg-[#1c1c1e] ios-shadow border border-white/10 p-8 rounded-[32px] max-w-sm w-full animate-in fade-in zoom-in duration-500 flex flex-col items-center text-center">
        <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center mb-4">
            <div className="w-6 h-6 bg-blue-500 rounded-full animate-pulse shadow-[0_0_15px_rgba(0,122,255,0.5)]" />
        </div>
        <h3 className="text-white text-xl font-semibold mb-2">Step {step + 1} of 4</h3>
        <p className="text-gray-400 text-sm leading-relaxed mb-8">
          {steps[step].text}
        </p>
        <div className="w-full space-y-3">
            <button 
                onClick={onNext}
                className="w-full bg-blue-500 hover:bg-blue-400 text-white font-medium py-3 rounded-2xl transition-all active:scale-95"
            >
                {step === 3 ? t.tutorial.finish : t.tutorial.next}
            </button>
            <button 
                onClick={onSkip} 
                className="w-full text-gray-500 hover:text-white text-xs font-medium py-2 transition-colors"
            >
                {t.tutorial.skip}
            </button>
        </div>
      </div>
    </div>
  );
};

export default TutorialOverlay;
