
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { QuantumNode } from '../types';

interface NetworkVizProps {
  nodes: QuantumNode[];
  localId: string;
}

const NetworkViz: React.FC<NetworkVizProps> = ({ nodes, localId }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || nodes.length === 0) return;

    const width = svgRef.current.clientWidth;
    const height = svgRef.current.clientHeight;
    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const simulation = d3.forceSimulation(nodes as any)
      .force("charge", d3.forceManyBody().strength(-400))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collision", d3.forceCollide().radius(80));

    // Links as subtle glow paths
    const links: any[] = [];
    nodes.forEach(node => {
      node.connections.forEach(targetId => {
        const targetNode = nodes.find(n => n.id === targetId);
        if (targetNode) links.push({ source: node, target: targetNode });
      });
    });

    const link = svg.append("g")
      .selectAll("path")
      .data(links)
      .join("path")
      .attr("fill", "none")
      .attr("stroke", "rgba(0, 122, 255, 0.08)")
      .attr("stroke-width", 1);

    const nodeGroup = svg.append("g")
      .selectAll("g")
      .data(nodes)
      .join("g");

    // Dynamic glow for nodes
    nodeGroup.append("circle")
      .attr("r", d => d.id === localId ? 25 : 18)
      .attr("fill", d => d.id === localId ? "rgba(0, 122, 255, 0.15)" : "rgba(255, 255, 255, 0.03)")
      .style("filter", "blur(12px)");

    nodeGroup.append("circle")
      .attr("r", d => d.id === localId ? 4 : 3)
      .attr("fill", d => d.id === localId ? "#fff" : "rgba(255, 255, 255, 0.4)");

    simulation.on("tick", () => {
      link.attr("d", (d: any) => {
        return `M${d.source.x},${d.source.y} Q${(d.source.x + d.target.x)/2 + 20},${(d.source.y + d.target.y)/2 - 20} ${d.target.x},${d.target.y}`;
      });
      nodeGroup.attr("transform", (d: any) => `translate(${d.x},${d.y})`);
    });

    return () => simulation.stop();
  }, [nodes, localId]);

  return <svg ref={svgRef} className="w-full h-full opacity-60" />;
};

export default NetworkViz;
