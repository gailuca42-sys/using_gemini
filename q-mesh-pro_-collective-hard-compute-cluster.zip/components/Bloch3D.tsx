
import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { QubitState } from '../types';

interface Bloch3DProps {
  state: QubitState;
}

const Bloch3D: React.FC<Bloch3DProps> = ({ state }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const width = 100;
    const height = 100;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 100);
    
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    const sphere = new THREE.Mesh(
      new THREE.SphereGeometry(1, 16, 16),
      new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true, transparent: true, opacity: 0.05 })
    );
    scene.add(sphere);

    const vector = new THREE.Group();
    const line = new THREE.Mesh(
      new THREE.CylinderGeometry(0.02, 0.02, 1.2),
      new THREE.MeshBasicMaterial({ color: 0x007AFF })
    );
    line.position.y = 0.6;
    vector.add(line);
    scene.add(vector);

    camera.position.set(1.5, 1.5, 2.5);
    camera.lookAt(0, 0, 0);

    const animate = () => {
      const theta = 2 * Math.acos(Math.sqrt(state.alpha.re**2 + state.alpha.im**2));
      const phi = Math.atan2(state.beta.im, state.beta.re);
      vector.rotation.z = -theta;
      vector.rotation.y = phi;
      renderer.render(scene, camera);
    };

    const interval = setInterval(animate, 50); // Lower update rate for smoothness/CPU

    return () => {
      clearInterval(interval);
      renderer.dispose();
      containerRef.current?.removeChild(renderer.domElement);
    };
  }, [state]);

  return <div ref={containerRef} className="w-[100px] h-[100px] pointer-events-none" />;
};

export default Bloch3D;
