
export const translations = {
  en: {
    welcome: "Q-Mesh",
    subWelcome: "Quantum Computing for Everyone",
    init: "Connectivity",
    networkId: "Network ID",
    networkHint: "Type 'Yes' to authorize",
    alias: "Your Name",
    join: "Join",
    globalQubits: "Total Capacity",
    clusterFidelity: "Precision",
    activeNodes: "Nodes",
    localDynamics: "Node Status",
    algorithms: "Calculations",
    console: "Activity",
    synced: "Connected",
    tutorial: {
      next: "Continue",
      skip: "Dismiss",
      finish: "Start",
      step1: "Visual Network: See how your computer links with others in the mesh.",
      step2: "Efficiency: Monitor the collective power and accuracy of the cluster.",
      step3: "Quantum State: View the real-time physical status of your local qubits.",
      step4: "Deploy: Run advanced quantum tasks distributed across all connected nodes."
    }
  },
  fr: {
    welcome: "Q-Mesh",
    subWelcome: "Le Calcul Quantique pour Tous",
    init: "Connectivité",
    networkId: "ID Réseau",
    networkHint: "Écrivez 'Yes' pour autoriser",
    alias: "Votre Nom",
    join: "Rejoindre",
    globalQubits: "Capacité Totale",
    clusterFidelity: "Précision",
    activeNodes: "Nœuds",
    localDynamics: "État du Nœud",
    algorithms: "Calculs",
    console: "Activité",
    synced: "Connecté",
    tutorial: {
      next: "Continuer",
      skip: "Ignorer",
      finish: "Démarrer",
      step1: "Réseau Visuel : Voyez comment votre ordinateur se lie aux autres.",
      step2: "Efficacité : Surveillez la puissance collective et la précision du cluster.",
      step3: "État Quantique : Observez l'état physique de vos qubits locaux.",
      step4: "Déployer : Lancez des tâches quantiques distribuées sur tous les nœuds."
    }
  }
};
