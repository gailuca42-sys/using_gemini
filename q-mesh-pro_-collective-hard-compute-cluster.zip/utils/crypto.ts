
export async function generateNodeId(alias: string, passphrase: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(alias + passphrase + "quantum-p2p-cluster-v1");
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return `q-node-${hashHex.substring(0, 16)}`;
}

export function formatHash(hash: string): string {
  return hash.substring(0, 8) + '...' + hash.substring(hash.length - 4);
}
