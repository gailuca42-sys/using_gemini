
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { GoogleGenAI } from "@google/genai";
import { QuantumNode, NetworkMessage, AlgorithmType, QubitState } from './types';
import { QuantumEngine } from './services/quantumEngine';
import NetworkViz from './components/NetworkViz';
import Bloch3D from './components/Bloch3D';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const PEER_SLOTS = 15;
const engine = new QuantumEngine();

const App: React.FC = () => {
  const [isJoined, setIsJoined] = useState(false);
  const [nodes, setNodes] = useState<QuantumNode[]>([]);
  const [localQubits, setLocalQubits] = useState<QubitState[]>(Array(4).fill(null).map(() => QuantumEngine.getRandomState()));
  const [entropy, setEntropy] = useState(0);
  const [activeTask, setActiveTask] = useState<string | null>(null);
  const [uptime, setUptime] = useState(720);

  const peerRef = useRef<any>(null);
  const connectionsRef = useRef<{ [id: string]: any }>({});
  const audioCtxRef = useRef<AudioContext | null>(null);
  const [localId, setLocalId] = useState<string>('');

  const collectiveMetrics = useMemo(() => {
    const totalLogical = nodes.reduce((acc, n) => acc + n.logicalQubits, 0);
    const avgFid = nodes.reduce((acc, n) => acc + n.fidelity, 0) / (nodes.length || 1);
    return { totalLogical, avgFid };
  }, [nodes]);

  const initCluster = async () => {
    if (!audioCtxRef.current) audioCtxRef.current = new AudioContext();
    for (let i = 1; i <= PEER_SLOTS; i++) {
      const targetId = `q-mesh-vision-${i}`;
      // @ts-ignore
      const peer = new window.Peer(targetId, { debug: 0 });
      const success = await new Promise((resolve) => {
        peer.on('open', (id) => {
          setLocalId(id);
          peerRef.current = peer;
          setIsJoined(true);
          for (let j = 1; j <= PEER_SLOTS; j++) {
            if (i !== j) {
              const conn = peer.connect(`q-mesh-vision-${j}`);
              handleConn(conn);
            }
          }
          resolve(true);
        });
        peer.on('error', () => resolve(false));
        setTimeout(() => resolve(false), 600);
      });
      if (success) {
        peer.on('connection', handleConn);
        break;
      }
    }
  };

  const handleConn = (conn: any) => {
    conn.on('open', () => {
      connectionsRef.current[conn.peer] = conn;
    });
    conn.on('data', (msg: NetworkMessage) => {
      if (msg.type === 'SYNC') {
        setNodes(prev => {
          const others = prev.filter(n => n.id !== msg.senderId);
          return [...others, msg.payload];
        });
      } else if (msg.type === 'TASK_SUBMIT') {
        setActiveTask(msg.payload.algo);
        setTimeout(() => setActiveTask(null), 3000);
      }
    });
    conn.on('close', () => {
      delete connectionsRef.current[conn.peer];
      setNodes(prev => prev.filter(n => n.id !== conn.peer));
    });
  };

  const runTask = (type: AlgorithmType) => {
    setActiveTask(type);
    Object.values(connectionsRef.current).forEach((c: any) => {
      if (c.open) c.send({ type: 'TASK_SUBMIT', senderId: localId, payload: { algo: type } });
    });
    setTimeout(() => setActiveTask(null), 3000);
  };

  useEffect(() => {
    if (!isJoined) return;
    const interval = setInterval(async () => {
      const ent = audioCtxRef.current ? await QuantumEngine.getHardwareEntropy(audioCtxRef.current) : 0;
      setEntropy(ent);
      setLocalQubits(prev => prev.map(q => engine.applyCompute(q, ent, nodes.length)));
      
      const node: QuantumNode = {
        id: localId, alias: 'Core', physicalQubits: 128, logicalQubits: 4,
        syndrome: [], fidelity: QuantumEngine.solveSurfaceCode(nodes.length, ent),
        lastUpdated: Date.now(), connections: Object.keys(connectionsRef.current),
        computePower: 1, uptime: uptime, circuitDepth: 0, monteCarloShots: 1000
      };
      setNodes(prev => [...prev.filter(n => n.id !== localId), node]);
      Object.values(connectionsRef.current).forEach((c: any) => {
        if (c.open) c.send({ type: 'SYNC', senderId: localId, payload: node });
      });
    }, 2000); // Reduced update frequency for performance
    return () => clearInterval(interval);
  }, [isJoined, localId, nodes.length]);

  if (!isJoined) {
    return (
      <div className="h-screen flex items-center justify-center p-6 bg-black">
        <div className="text-center space-y-12 animate-in fade-in zoom-in duration-1000">
          <div className="space-y-4">
            <h1 className="text-7xl font-light tracking-tight text-white/90">Q-Mesh <span className="font-semibold text-white">Pro</span></h1>
            <p className="text-white/40 text-lg tracking-widest uppercase">Collective Intelligence Fabric</p>
          </div>
          <button onClick={initCluster} className="ios-button px-14 py-6 rounded-full text-lg shadow-2xl">
            Join Cluster
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col p-8 max-w-[1400px] mx-auto space-y-8 animate-in fade-in duration-700">
      <header className="flex justify-between items-center">
        <div className="flex items-center gap-6">
          <div className="vision-glass px-6 py-3 flex items-center gap-3">
             <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_10px_#007AFF]" />
             <span className="text-sm font-medium text-white/80">Active Mesh</span>
          </div>
          <div className="text-white/30 font-mono text-xs uppercase tracking-widest">{localId}</div>
        </div>

        <div className="flex gap-10 items-center vision-glass px-10 py-5">
           <HeaderStat label="Logical Qubits" value={collectiveMetrics.totalLogical} color="text-blue-500" />
           <div className="w-px h-8 bg-white/10" />
           <HeaderStat label="Precision" value={`${(collectiveMetrics.avgFid * 100).toFixed(3)}%`} />
           <div className="w-px h-8 bg-white/10" />
           <HeaderStat label="Nodes" value={nodes.length} />
        </div>
      </header>

      <main className="grid grid-cols-12 gap-8 flex-grow overflow-hidden">
        {/* NETWORK VISUALIZER */}
        <div className="col-span-8 flex flex-col gap-8">
          <div className="flex-grow vision-glass relative overflow-hidden group">
             <NetworkViz nodes={nodes} localId={localId} />
             <div className="absolute top-8 left-8">
                <h3 className="text-xs font-semibold uppercase tracking-widest text-white/40">Collective Topology</h3>
             </div>
             {activeTask && (
                <div className="absolute inset-0 bg-white/5 backdrop-blur-md flex items-center justify-center animate-in fade-in duration-500">
                    <div className="text-center space-y-2">
                        <div className="text-4xl font-light italic text-white">{activeTask.split('_')[0]}</div>
                        <div className="text-[10px] font-bold tracking-[0.4em] text-blue-500 uppercase">Synchronizing Shards</div>
                    </div>
                </div>
             )}
          </div>

          <div className="h-[200px] grid grid-cols-4 gap-6">
            {localQubits.map((q, i) => (
              <div key={i} className="vision-glass flex flex-col items-center justify-center p-4">
                <Bloch3D state={q} />
              </div>
            ))}
          </div>
        </div>

        {/* CONTROLS */}
        <div className="col-span-4 flex flex-col gap-8">
          <div className="flex-grow vision-glass p-10 flex flex-col gap-10">
             <div className="space-y-2">
                <h3 className="text-xl font-semibold text-white/90">Algorithms</h3>
                <p className="text-xs text-white/30 uppercase tracking-widest">Execute distributed gate sets</p>
             </div>
             
             <div className="flex flex-col gap-4">
                <TaskBtn label="Shor Factorization" onClick={() => runTask(AlgorithmType.SHOR)} />
                <TaskBtn label="Molecular VQE" onClick={() => runTask(AlgorithmType.VQE)} />
                <TaskBtn label="Max-Cut QAOA" onClick={() => runTask(AlgorithmType.QAOA)} />
             </div>

             <div className="mt-auto pt-8 border-t border-white/10">
                <div className="flex justify-between items-center mb-6">
                    <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Hardware Entropy</span>
                    <span className="text-xs font-bold text-blue-500">{(entropy * 100).toFixed(1)}%</span>
                </div>
                <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 transition-all duration-1000" style={{ width: `${entropy * 100}%` }} />
                </div>
             </div>
          </div>

          <div className="vision-glass p-8 flex justify-between items-center group cursor-pointer hover:bg-white/5 transition-colors">
             <div className="flex flex-col">
                <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Stability</span>
                <span className="text-sm font-semibold text-emerald-500 tracking-tight">Coherent Flow</span>
             </div>
             <div className="flex -space-x-2">
                {nodes.slice(0, 5).map(n => (
                    <div key={n.id} className="w-8 h-8 rounded-full border border-black bg-white/10 backdrop-blur-sm flex items-center justify-center text-[8px] font-bold">
                        {n.id.slice(-1)}
                    </div>
                ))}
                {nodes.length > 5 && <div className="w-8 h-8 rounded-full bg-white/5 border border-black flex items-center justify-center text-[8px] font-bold">+{nodes.length-5}</div>}
             </div>
          </div>
        </div>
      </main>
    </div>
  );
};

const HeaderStat = ({ label, value, color = "text-white" }: any) => (
  <div className="flex flex-col items-center">
    <span className="text-[9px] font-bold text-white/30 uppercase tracking-widest mb-1">{label}</span>
    <span className={`text-2xl font-semibold tracking-tight ${color}`}>{value}</span>
  </div>
);

const TaskBtn = ({ label, onClick }: any) => (
  <button 
    onClick={onClick}
    className="w-full text-left px-6 py-5 rounded-[24px] bg-white/5 hover:bg-white/10 border border-transparent hover:border-white/10 transition-all active:scale-98"
  >
    <span className="text-sm font-medium text-white/80">{label}</span>
  </button>
);

export default App;
