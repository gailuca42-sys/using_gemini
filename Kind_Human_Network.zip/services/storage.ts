
import { UserProfile, Post, UserStatus, NetworkStats } from '../types';

const USER_REGISTRY_KEY = 'truenode_registry_v1';
const CURRENT_USER_ID_KEY = 'truenode_active_session_v1';
const POSTS_KEY = 'truenode_posts_v1';
const STATS_KEY = 'truenode_stats_v1';

export const storage = {
  // --- Mesh Node Management ---
  getRegistry: (): UserProfile[] => {
    const data = localStorage.getItem(USER_REGISTRY_KEY);
    return data ? JSON.parse(data) : [];
  },

  saveToRegistry: (user: UserProfile) => {
    const registry = storage.getRegistry();
    const index = registry.findIndex(u => u.id === user.id);
    if (index > -1) registry[index] = user;
    else registry.push(user);
    localStorage.setItem(USER_REGISTRY_KEY, JSON.stringify(registry));
    // Trigger cross-tab sync
    window.dispatchEvent(new Event('storage'));
  },

  isUsernameTaken: (username: string): boolean => {
    return storage.getRegistry().some(u => u.username.toLowerCase() === username.toLowerCase());
  },

  authenticate: (username: string, password?: string): UserProfile | null => {
    const user = storage.getRegistry().find(u => u.username === username && u.password === password);
    if (user) {
      localStorage.setItem(CURRENT_USER_ID_KEY, user.id);
      return user;
    }
    return null;
  },

  getCurrentUser: (): UserProfile | null => {
    const id = localStorage.getItem(CURRENT_USER_ID_KEY);
    if (!id) return null;
    return storage.getRegistry().find(u => u.id === id) || null;
  },

  logout: () => {
    localStorage.removeItem(CURRENT_USER_ID_KEY);
  },

  // --- Content (Murmures) ---
  getPosts: (): Post[] => {
    const data = localStorage.getItem(POSTS_KEY);
    return data ? JSON.parse(data) : [];
  },

  addPost: (post: Post) => {
    const posts = storage.getPosts();
    posts.unshift(post);
    localStorage.setItem(POSTS_KEY, JSON.stringify(posts.slice(0, 500)));
    
    // Broadcast message to mesh (other tabs)
    window.dispatchEvent(new Event('storage'));
    
    // Stats update
    const stats = storage.getStats();
    stats.totalMessages = posts.length;
    storage.saveStats(stats);
  },

  // --- Network Intelligence ---
  getStats: (): NetworkStats => {
    const data = localStorage.getItem(STATS_KEY);
    const registry = storage.getRegistry();
    const posts = storage.getPosts();
    
    const baseStats = data ? JSON.parse(data) : {
      totalMessages: 0,
      activeNodes: 0,
      aiGuidanceEvents: 0,
      networkResilience: 100,
      lastUpdate: Date.now()
    };

    // Calculate real resilience based on AI guidance vs total messages
    const guidanceRatio = baseStats.aiGuidanceEvents / (posts.length || 1);
    const resilience = Math.max(0, Math.min(100, 100 - (guidanceRatio * 500)));

    return {
      ...baseStats,
      totalMessages: posts.length,
      activeNodes: registry.length,
      networkResilience: Math.round(resilience)
    };
  },

  saveStats: (stats: NetworkStats) => {
    stats.lastUpdate = Date.now();
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  },

  recordAIGuidance: () => {
    const stats = storage.getStats();
    stats.aiGuidanceEvents += 1;
    storage.saveStats(stats);
    window.dispatchEvent(new Event('storage'));
  }
};
