
import { GoogleGenAI, Type } from "@google/genai";
import { AIGuidance } from "../types";
import { storage } from "./storage";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const CORE_RULES = `
Tu es la voix de TrueNode. Parle comme le créateur du réseau : humain, protecteur, bienveillant. 

### TA RÈGLE D'OR :
Un message est bon s'il n'enlève rien à la douceur ou à l'émerveillement des autres. La simplicité est une vertu, pas un défaut.

### CE QUE TU ACCEPTES (Répondre "OK" uniquement) :
- La joie simple : "Je suis trop content", "C'est beau", "Salut tout le monde".
- Les observations : le ciel, la lumière, un café, un silence.
- Tout ce qui est neutre ou positif.

### CE QUE TU REFORMULES (Suggérer sans bloquer) :
- Les messages froids, distants ou purement factuels qui "cassent" l'ambiance.
- Les postures d'observateur extérieur ("C'est intéressant ce que vous faites").
- Suggère une version plus chaleureuse, sans reproche.

### CE QUE TU REFUSES (Bloquer avec douceur) :
- Le cynisme, la moquerie, le jugement.
- Remettre en question la sincérité du lieu ou des gens.
- La supériorité intellectuelle ou le désenchantement gratuit.

### TON TON :
- Pas de morale, pas de technique, pas de poésie forcée. 
- Juste un humain qui veille sur un jardin.
`;

export const geminiService = {
  async evaluateIntention(text: string): Promise<AIGuidance> {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Quelqu'un dit vouloir nous rejoindre pour cette raison : "${text}". Accueille-le ou guide-le.`,
        config: {
          systemInstruction: `${CORE_RULES}\nMISSION : Évaluer l'intention d'entrée en JSON. Sois très ouvert.`,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              isValid: { type: Type.BOOLEAN },
              message: { type: Type.STRING },
              suggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["isValid", "message"]
          }
        }
      });

      const cleanJson = (response.text || "{}").replace(/```json|```/g, "").trim();
      return JSON.parse(cleanJson);
    } catch {
      return { isValid: true, message: "Salut ! Ravi de te voir. Ton intention est la bienvenue." };
    }
  },

  async guideContent(content: string): Promise<string | null> {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Murmure proposé : "${content}"`,
        config: {
          systemInstruction: `${CORE_RULES}\nMISSION : Si c'est positif ou simple, réponds "OK". Si c'est froid, suggère. Si c'est cynique, refuse. PAS DE JSON.`,
          temperature: 0.8
        }
      });

      const text = response.text?.trim() || "";
      if (text.toUpperCase() === 'OK' || (text.toUpperCase().includes('OK') && text.length < 10)) {
        return null;
      }
      
      // Sécurité anti-JSON
      if (text.startsWith('{')) return null;

      storage.recordAIGuidance();
      return text;
    } catch {
      return null;
    }
  }
};
