
export enum UserStatus {
  VISITOR = 'VISITOR',
  PENDING = 'PENDING',
  ACCEPTED = 'ACCEPTED'
}

export interface UserProfile {
  id: string; // Internal ID
  nodeId: string; // Mesh Network ID
  username: string;
  password?: string;
  displayName: string;
  intention: string;
  joinedAt: number;
  status: UserStatus;
  isDevModeEnabled: boolean;
}

export interface Post {
  id: string;
  nodeId: string; // ID of the originating node
  authorName: string;
  content: string;
  timestamp: number;
}

export interface NetworkStats {
  totalMessages: number;
  activeNodes: number;
  aiGuidanceEvents: number;
  networkResilience: number;
  lastUpdate: number;
}

export interface AIGuidance {
  isValid: boolean;
  message: string;
  suggestions?: string[];
}
