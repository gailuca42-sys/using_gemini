
import React, { useState, useEffect } from 'react';
import { UserProfile, UserStatus } from './types';
import { storage } from './services/storage';
import Welcome from './components/Welcome';
import EntryGate from './components/EntryGate';
import MainFeed from './components/MainFeed';
import DevDashboard from './components/DevDashboard';
import { Layout } from './components/Layout';

const App: React.FC = () => {
  const [user, setUser] = useState<UserProfile | null>(storage.getCurrentUser());
  const [view, setView] = useState<'welcome' | 'gate' | 'feed' | 'dev'>('welcome');

  useEffect(() => {
    if (!user) {
      setView('welcome');
    } else if (view !== 'dev') {
      if (user.status === UserStatus.PENDING) setView('gate');
      else if (user.status === UserStatus.ACCEPTED) setView('feed');
    }
  }, [user]);

  const handleLogin = (u: UserProfile) => {
    setUser(u);
    if (u.status === UserStatus.ACCEPTED) setView('feed');
    else setView('gate');
  };

  const handleAcceptance = (intention: string) => {
    if (user) {
      const updatedUser = { ...user, intention, status: UserStatus.ACCEPTED };
      setUser(updatedUser);
      storage.saveToRegistry(updatedUser);
      setView('feed');
    }
  };

  const handleLogout = () => {
    storage.logout();
    setUser(null);
    setView('welcome');
  };

  const renderView = () => {
    if (!user) {
      return <Welcome onLoginSuccess={handleLogin} />;
    }

    switch (view) {
      case 'gate':
        return <EntryGate user={user} onAccepted={handleAcceptance} />;
      case 'feed':
        return (
          <MainFeed 
            user={user} 
            onOpenDev={() => setView('dev')} 
            onLogout={handleLogout}
          />
        );
      case 'dev':
        return <DevDashboard onClose={() => setView('feed')} />;
      default:
        return <Welcome onLoginSuccess={handleLogin} />;
    }
  };

  return (
    <Layout>
      {renderView()}
    </Layout>
  );
};

export default App;
