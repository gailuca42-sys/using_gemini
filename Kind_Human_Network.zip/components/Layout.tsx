
import React from 'react';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col items-center p-6 md:p-12 overflow-x-hidden">
      <div className="w-full max-w-2xl flex-1 flex flex-col">
        {children}
      </div>
      <footer className="mt-20 py-10 text-stone-200 text-xs uppercase tracking-[0.4em] font-bold opacity-50 flex flex-col items-center space-y-4">
        <div className="w-8 h-px bg-stone-100" />
        <span>TrueNode — L'existence par la présence</span>
      </footer>
    </div>
  );
};
