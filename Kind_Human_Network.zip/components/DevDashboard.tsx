
import React, { useMemo, useState, useEffect } from 'react';
import { storage } from '../services/storage';
import { ArrowLeft, Activity, Users, MessageSquare, Zap, Clock, Maximize2 } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface DevDashboardProps {
  onClose: () => void;
}

type TimeScale = 'minute' | 'hour' | 'day' | 'month';

const DevDashboard: React.FC<DevDashboardProps> = ({ onClose }) => {
  const [scale, setScale] = useState<TimeScale>('hour');
  const [stats, setStats] = useState(storage.getStats());
  const registry = storage.getRegistry();
  const posts = storage.getPosts();

  useEffect(() => {
    const handleSync = () => setStats(storage.getStats());
    window.addEventListener('storage', handleSync);
    return () => window.removeEventListener('storage', handleSync);
  }, []);

  const chartData = useMemo(() => {
    const now = Date.now();
    const dataPoints: { name: string, val: number, timestamp: number }[] = [];
    let count = 0;
    let step = 0;
    let labelFormat: Intl.DateTimeFormatOptions = {};

    switch (scale) {
      case 'minute': count = 30; step = 60 * 1000; labelFormat = { minute: '2-digit' }; break;
      case 'hour': count = 24; step = 60 * 60 * 1000; labelFormat = { hour: '2-digit' }; break;
      case 'day': count = 7; step = 24 * 60 * 60 * 1000; labelFormat = { weekday: 'short' }; break;
      case 'month': count = 12; step = 30 * 24 * 60 * 60 * 1000; labelFormat = { month: 'short' }; break;
    }

    for (let i = count - 1; i >= 0; i--) {
      const time = now - (i * step);
      const date = new Date(time);
      const val = posts.filter(p => p.timestamp <= time && p.timestamp > (time - step)).length;
      dataPoints.push({
        name: new Intl.DateTimeFormat('fr-FR', labelFormat).format(date),
        val,
        timestamp: time
      });
    }
    return dataPoints;
  }, [posts, scale]);

  return (
    <div className="animate-in fade-in zoom-in-95 duration-500 flex flex-col space-y-10 py-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button onClick={onClose} className="p-2 hover:bg-stone-100 rounded-full transition-colors">
            <ArrowLeft size={20} />
          </button>
          <h2 className="text-3xl font-semibold text-stone-800">Cœur de TrueNode</h2>
        </div>
        <div className="text-[10px] bg-stone-900 text-stone-50 px-3 py-1 rounded-full uppercase tracking-widest font-mono">
          Live Nodes: {registry.length}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon={<Users size={18}/>} label="Nodes" value={stats.activeNodes} />
        <StatCard icon={<MessageSquare size={18}/>} label="Murmures" value={stats.totalMessages} />
        <StatCard icon={<Zap size={18}/>} label="Guidances IA" value={stats.aiGuidanceEvents} />
        <StatCard icon={<Activity size={18}/>} label="Résilience" value={`${stats.networkResilience}%`} />
      </div>

      <div className="bg-white p-8 rounded-[2rem] soft-shadow border border-stone-50">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h3 className="text-xs font-bold text-stone-800 uppercase tracking-widest">Activité Décentralisée</h3>
            <p className="text-[10px] text-stone-400 uppercase font-bold tracking-tighter">Données agrégées du node local</p>
          </div>
          
          <div className="flex bg-stone-50 p-1 rounded-xl border border-stone-100">
            {(['minute', 'hour', 'day', 'month'] as TimeScale[]).map((s) => (
              <button
                key={s}
                onClick={() => setScale(s)}
                className={`px-3 py-1.5 text-[9px] uppercase tracking-tighter rounded-lg transition-all font-bold ${
                  scale === s ? 'bg-white text-stone-900 shadow-sm' : 'text-stone-400 hover:text-stone-600'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2d2a26" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#2d2a26" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f5f5f5" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#a8a29e', fontSize: 10}} />
              <YAxis hide domain={[0, 'auto']} />
              <Tooltip 
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 8px 32px rgba(0,0,0,0.05)', fontSize: '11px' }}
                cursor={{ stroke: '#e7e5e4', strokeWidth: 1 }}
              />
              <Area type="monotone" dataKey="val" stroke="#2d2a26" fillOpacity={1} fill="url(#colorVal)" strokeWidth={1.5} dot={{ r: 3, fill: '#2d2a26' }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-xs font-bold text-stone-400 uppercase tracking-widest px-2">Répertoire des Nœuds</h3>
        <div className="bg-white rounded-[2rem] border border-stone-50 soft-shadow overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-stone-50 text-stone-400 text-[10px] uppercase font-bold">
                <th className="px-6 py-4">Node / Nom</th>
                <th className="px-6 py-4 text-center">Statut</th>
                <th className="px-6 py-4 text-right">Instant de connexion</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-50">
              {registry.map(u => (
                <tr key={u.id} className="text-stone-600 hover:bg-stone-50/50 transition-colors">
                  <td className="px-6 py-4 font-medium">
                    <div className="flex flex-col">
                      <span className="text-stone-900 font-bold">{u.displayName}</span>
                      <span className="text-[10px] text-stone-300 font-mono">{u.nodeId}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${u.status === 'ACCEPTED' ? 'bg-stone-100 text-stone-600' : 'bg-amber-50 text-amber-600'}`}>
                      {u.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right text-stone-400 font-mono text-xs">
                    {new Date(u.joinedAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ icon: React.ReactNode, label: string, value: string | number }> = ({ icon, label, value }) => (
  <div className="bg-white p-5 rounded-3xl soft-shadow border border-stone-50 flex flex-col items-center text-center space-y-1">
    <div className="text-stone-300">{icon}</div>
    <div className="text-2xl font-light text-stone-800">{value}</div>
    <div className="text-[9px] text-stone-400 uppercase tracking-widest font-bold">{label}</div>
  </div>
);

export default DevDashboard;
