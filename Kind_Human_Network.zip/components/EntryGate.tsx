
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { geminiService } from '../services/gemini';
import { Sparkles, Loader2, ArrowRight, Wind } from 'lucide-react';

interface EntryGateProps {
  user: UserProfile;
  onAccepted: (intention: string) => void;
}

const EntryGate: React.FC<EntryGateProps> = ({ user, onAccepted }) => {
  const [intention, setIntention] = useState('');
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ isValid: boolean; message: string; suggestions?: string[] } | null>(null);

  const handleSubmit = async () => {
    if (!intention.trim()) return;
    setLoading(true);
    const guidance = await geminiService.evaluateIntention(intention);
    setLoading(false);
    setFeedback(guidance);
  };

  const handleFinalEntry = () => {
    if (feedback?.isValid) {
      onAccepted(intention);
    }
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-8 duration-1000 flex flex-col space-y-12 py-12 max-w-xl mx-auto">
      <div className="space-y-6 text-center">
        <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-stone-200 mx-auto mb-4 soft-shadow border border-stone-50">
          <Wind size={32} />
        </div>
        <h2 className="text-4xl font-semibold text-stone-800 serif italic">Bonjour, {user?.displayName}.</h2>
        <p className="text-stone-400 leading-relaxed text-lg serif px-8">
          Avant d'écouter les autres, écoutez votre propre silence. 
          Quelle intention déposez-vous ici pour que ce lieu reste un refuge ?
        </p>
      </div>

      <div className="relative group">
        <textarea
          value={intention}
          onChange={(e) => {
            setIntention(e.target.value);
            if (feedback) setFeedback(null);
          }}
          disabled={!!feedback?.isValid}
          placeholder="Déposez ici votre quête de sincérité..."
          className={`w-full h-64 p-10 bg-white border border-stone-50 rounded-[3rem] soft-shadow outline-none focus:ring-1 focus:ring-stone-200 resize-none text-stone-700 leading-relaxed serif text-2xl placeholder:text-stone-100 transition-all text-center ${feedback?.isValid ? 'opacity-50' : ''}`}
        />
        
        {loading && (
          <div className="absolute inset-0 bg-white/90 backdrop-blur-md flex flex-col items-center justify-center rounded-[3rem] z-10 animate-in fade-in duration-300">
            <Loader2 className="animate-spin text-stone-200 mb-4" size={32} />
            <span className="text-stone-400 text-sm italic serif tracking-widest">L'âme du réseau écoute...</span>
          </div>
        )}
      </div>

      {feedback && (
        <div className="p-10 bg-white rounded-[3rem] border border-stone-100 soft-shadow animate-in zoom-in-95 duration-700">
          <div className="flex flex-col items-center text-center space-y-6">
            <Sparkles className={feedback.isValid ? "text-stone-900" : "text-amber-300"} size={28} />
            <div className="space-y-6">
              <p className="text-stone-800 leading-relaxed italic serif text-2xl max-w-md mx-auto">
                {feedback.message}
              </p>
              
              {feedback.suggestions && feedback.suggestions.length > 0 && (
                <div className="flex flex-wrap justify-center gap-4 pt-4">
                  {feedback.suggestions.map((s, i) => (
                    <span key={i} className="text-[10px] uppercase tracking-widest bg-stone-50 text-stone-400 px-4 py-2 rounded-full border border-stone-100 font-bold italic">
                      "{s}"
                    </span>
                  ))}
                </div>
              )}
            </div>

            {feedback.isValid && (
              <button
                onClick={handleFinalEntry}
                className="mt-8 px-12 py-5 bg-stone-900 text-white rounded-full flex items-center space-x-3 hover:bg-stone-800 transition-all soft-shadow transform hover:-translate-y-1 font-bold uppercase tracking-widest text-xs"
              >
                <span>Franchir le seuil</span>
                <ArrowRight size={18} />
              </button>
            )}
          </div>
        </div>
      )}

      {!feedback && (
        <button
          onClick={handleSubmit}
          disabled={!intention.trim() || loading}
          className={`flex items-center justify-center space-x-3 w-full py-6 rounded-full transition-all duration-700 font-bold uppercase tracking-widest text-xs ${
            intention.trim() && !loading
            ? 'bg-stone-900 text-stone-50 hover:bg-stone-800 soft-shadow transform hover:-translate-y-1'
            : 'bg-stone-50 text-stone-200 cursor-not-allowed'
          }`}
        >
          <span>Confier mon intention au souffle</span>
          <ArrowRight size={18} />
        </button>
      )}

      <p className="text-center text-[10px] text-stone-300 uppercase tracking-widest font-bold">
        Ce seuil est la garantie de notre tranquillité commune.
      </p>
    </div>
  );
};

export default EntryGate;
