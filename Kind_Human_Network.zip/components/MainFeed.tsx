
import React, { useState, useEffect, useCallback } from 'react';
import { UserProfile, Post } from '../types';
import { storage } from '../services/storage';
import { geminiService } from '../services/gemini';
import { Send, User, Sparkles, LogOut, ChartBar, Clock, Globe, Feather, RefreshCw } from 'lucide-react';

interface MainFeedProps {
  user: UserProfile;
  onOpenDev: () => void;
  onLogout: () => void;
}

const MainFeed: React.FC<MainFeedProps> = ({ user, onOpenDev, onLogout }) => {
  const [displayedPosts, setDisplayedPosts] = useState<Post[]>(storage.getPosts());
  const [newPostsAvailable, setNewPostsAvailable] = useState(false);
  const [newContent, setNewContent] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [aiNote, setAiNote] = useState<string | null>(null);

  const checkUpdates = useCallback(() => {
    const allPosts = storage.getPosts();
    if (allPosts.length > displayedPosts.length) {
      setNewPostsAvailable(true);
    } else if (allPosts.length > 0 && displayedPosts.length > 0 && allPosts[0].id !== displayedPosts[0].id) {
      setNewPostsAvailable(true);
    }
  }, [displayedPosts]);

  useEffect(() => {
    window.addEventListener('storage', checkUpdates);
    return () => window.removeEventListener('storage', checkUpdates);
  }, [checkUpdates]);

  const handleRefresh = () => {
    setDisplayedPosts(storage.getPosts());
    setNewPostsAvailable(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSend = async () => {
    if (!newContent.trim()) return;
    setIsSending(true);
    setAiNote(null);

    const guidance = await geminiService.guideContent(newContent);
    
    if (guidance) {
      setAiNote(guidance);
      setIsSending(false);
      return;
    }

    const post: Post = {
      id: Math.random().toString(36).substr(2, 9),
      nodeId: user.nodeId,
      authorName: user.displayName,
      content: newContent.trim(),
      timestamp: Date.now()
    };

    storage.addPost(post);
    setDisplayedPosts(storage.getPosts());
    setNewContent('');
    setIsSending(false);
    setNewPostsAvailable(false);
  };

  return (
    <div className="flex flex-col space-y-12 animate-in fade-in duration-1000 pb-20">
      <header className="flex items-center justify-between py-6 border-b border-stone-100">
        <div className="flex items-center space-x-4">
          <div className="w-10 h-10 bg-stone-900 rounded-xl rotate-2 flex items-center justify-center text-white soft-shadow">
            <span className="font-bold text-base tracking-tighter">TN</span>
          </div>
          <div>
            <h2 className="font-semibold text-stone-800 text-lg serif">TrueNode</h2>
            <div className="flex items-center space-x-2">
              <span className="text-[8px] text-stone-300 uppercase tracking-[0.2em] font-bold">Node local actif</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-1">
          <button onClick={onOpenDev} className="p-2 text-stone-200 hover:text-stone-800 transition-all">
            <ChartBar size={18} />
          </button>
          <button onClick={onLogout} className="p-2 text-stone-200 hover:text-red-300 transition-all">
            <LogOut size={18} />
          </button>
        </div>
      </header>

      {/* Composer */}
      <div className="bg-white p-8 rounded-[2.5rem] soft-shadow border border-stone-100/50 space-y-4">
        <div className="flex items-start space-x-4">
           <textarea
            value={newContent}
            onChange={(e) => {
              setNewContent(e.target.value);
              if (aiNote) setAiNote(null);
            }}
            placeholder="Partagez un instant, une joie..."
            className="w-full min-h-[100px] appearance-none outline-none border-none focus:ring-0 resize-none placeholder:text-stone-200 leading-relaxed serif text-xl !bg-white !text-stone-800"
          />
        </div>
        
        {aiNote && (
          <div className="p-6 bg-stone-50 rounded-3xl border border-stone-100 flex items-start space-x-4 animate-in slide-in-from-top-2 duration-300">
            <Sparkles size={18} className="text-stone-800 mt-1 flex-shrink-0" />
            <p className="text-sm text-stone-600 leading-relaxed italic serif">{aiNote}</p>
          </div>
        )}

        <div className="flex items-center justify-between pt-4 border-t border-stone-50">
          <div className="text-stone-200">
             <Feather size={14} />
          </div>
          <button
            onClick={handleSend}
            disabled={!newContent.trim() || isSending}
            className={`px-8 py-3 rounded-full flex items-center space-x-2 transition-all duration-300 ${
              newContent.trim() && !isSending
              ? 'bg-stone-900 text-white hover:bg-stone-800 soft-shadow'
              : 'bg-stone-50 text-stone-200 cursor-not-allowed'
            }`}
          >
            {isSending ? (
              <span className="w-4 h-4 border-2 border-stone-300 border-t-stone-800 rounded-full animate-spin" />
            ) : (
              <span className="text-xs font-bold uppercase tracking-widest">Partager</span>
            )}
          </button>
        </div>
      </div>

      {/* Bouton Refresh Minimaliste */}
      {newPostsAvailable && (
        <div className="flex justify-center sticky top-6 z-30 pointer-events-none">
          <button 
            onClick={handleRefresh}
            className="pointer-events-auto bg-white/80 backdrop-blur-md text-stone-800 px-5 py-2.5 rounded-full shadow-lg border border-stone-100 flex items-center space-x-2 animate-in slide-in-from-top-4 duration-500 hover:bg-white transition-all group"
          >
            <RefreshCw size={12} className="group-hover:rotate-180 transition-transform duration-700" />
            <span className="text-[9px] font-bold uppercase tracking-widest">Voir les nouveaux murmures</span>
          </button>
        </div>
      )}

      {/* Feed */}
      <div className="space-y-12">
        {displayedPosts.map((post) => (
          <div key={post.id} className="group flex flex-col items-center animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="w-px h-8 bg-stone-100 mb-6" />
            <div className="w-full bg-white p-10 md:p-12 rounded-[3.5rem] soft-shadow border border-transparent hover:border-stone-50 transition-all duration-500">
              <div className="flex items-center justify-between mb-8 opacity-40 group-hover:opacity-100 transition-opacity">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-stone-50 rounded-full flex items-center justify-center text-stone-300">
                    <User size={14} />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-stone-800 uppercase tracking-widest">{post.authorName}</span>
                    <span className="text-[8px] text-stone-300 font-mono">{post.nodeId}</span>
                  </div>
                </div>
                <div className="flex items-center text-[9px] text-stone-300 space-x-1 font-bold">
                  <Clock size={10} />
                  <span>{new Date(post.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              </div>
              <p className="text-stone-800 leading-[1.6] serif text-2xl md:text-3xl whitespace-pre-wrap text-center max-w-lg mx-auto italic">
                "{post.content}"
              </p>
            </div>
          </div>
        ))}
        {displayedPosts.length === 0 && (
          <div className="py-24 text-center space-y-4">
            <Sparkles size={24} className="text-stone-100 mx-auto animate-pulse" />
            <p className="text-stone-300 italic serif">Le silence est paisible ici.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MainFeed;
