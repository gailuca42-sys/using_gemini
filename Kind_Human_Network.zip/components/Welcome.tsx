
import React, { useState } from 'react';
import { User, Lock, ArrowRight, UserPlus } from 'lucide-react';
import { storage } from '../services/storage';
import { UserProfile, UserStatus } from '../types';

interface WelcomeProps {
  onLoginSuccess: (user: UserProfile) => void;
}

const Welcome: React.FC<WelcomeProps> = ({ onLoginSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [error, setError] = useState('');

  const generateNodeId = () => {
    return 'node_' + Math.random().toString(36).substr(2, 6).toUpperCase();
  };

  const handleAction = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isLogin) {
      const user = storage.authenticate(username, password);
      if (user) {
        onLoginSuccess(user);
      } else {
        setError('Identifiants inconnus. Peut-être un murmure mal entendu ?');
      }
    } else {
      if (!username || !password || !displayName) {
        setError('Tous les champs sont nécessaires pour naître ici.');
        return;
      }
      if (storage.isUsernameTaken(username)) {
        setError('Cet identifiant est déjà porté par une autre âme.');
        return;
      }

      const newUser: UserProfile = {
        id: Math.random().toString(36).substr(2, 9),
        nodeId: generateNodeId(),
        username,
        password,
        displayName,
        intention: '',
        joinedAt: Date.now(),
        status: UserStatus.PENDING,
        isDevModeEnabled: false
      };
      
      storage.saveToRegistry(newUser);
      onLoginSuccess(newUser);
    }
  };

  return (
    <div className="animate-in fade-in duration-1000 flex flex-col items-center py-8 space-y-8">
      <div className="w-16 h-16 bg-stone-900 rounded-2xl rotate-3 flex items-center justify-center text-white mb-2 soft-shadow">
        <span className="font-bold text-2xl tracking-tighter">TN</span>
      </div>
      
      <div className="space-y-4 max-w-lg text-center">
        <h1 className="text-4xl font-semibold text-stone-800">TrueNode</h1>
        <p className="text-stone-500 leading-relaxed italic text-lg px-4">
          "Un lieu qui existe parce que vous y êtes. Sincèrement."
        </p>
      </div>

      <div className="w-full max-w-sm bg-white p-8 rounded-3xl soft-shadow border border-stone-50">
        <form onSubmit={handleAction} className="space-y-5">
          <div className="flex justify-center space-x-6 mb-4 text-sm uppercase tracking-widest">
            <button 
              type="button"
              onClick={() => { setIsLogin(true); setError(''); }}
              className={`pb-2 border-b-2 transition-all ${isLogin ? 'border-stone-800 text-stone-800' : 'border-transparent text-stone-300'}`}
            >
              Connexion
            </button>
            <button 
              type="button"
              onClick={() => { setIsLogin(false); setError(''); }}
              className={`pb-2 border-b-2 transition-all ${!isLogin ? 'border-stone-800 text-stone-800' : 'border-transparent text-stone-300'}`}
            >
              Rejoindre
            </button>
          </div>

          {!isLogin && (
            <div className="space-y-2">
              <label className="text-xs text-stone-400 font-medium ml-1 uppercase">Nom d'affichage</label>
              <div className="relative">
                <UserPlus size={16} className="absolute left-3 top-3.5 text-stone-300" />
                <input 
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Ex: Clara"
                  className="w-full pl-10 pr-4 py-3 bg-stone-50 rounded-xl outline-none focus:ring-1 focus:ring-stone-200"
                />
              </div>
            </div>
          )}

          <div className="space-y-2">
            <label className="text-xs text-stone-400 font-medium ml-1 uppercase">Identifiant unique</label>
            <div className="relative">
              <User size={16} className="absolute left-3 top-3.5 text-stone-300" />
              <input 
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="pseudo"
                className="w-full pl-10 pr-4 py-3 bg-stone-50 rounded-xl outline-none focus:ring-1 focus:ring-stone-200"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs text-stone-400 font-medium ml-1 uppercase">Mot de passe</label>
            <div className="relative">
              <Lock size={16} className="absolute left-3 top-3.5 text-stone-300" />
              <input 
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-3 bg-stone-50 rounded-xl outline-none focus:ring-1 focus:ring-stone-200"
              />
            </div>
          </div>

          {error && <p className="text-xs text-red-400 text-center animate-pulse">{error}</p>}

          <button
            type="submit"
            className="w-full py-4 bg-stone-800 text-stone-50 rounded-xl hover:bg-stone-700 transition-all flex items-center justify-center space-x-2 group"
          >
            <span>{isLogin ? 'Entrer dans le Node' : 'Activer mon Node'}</span>
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </form>
      </div>

      <div className="text-stone-300 text-xs text-center max-w-xs leading-relaxed uppercase tracking-tighter">
        Chaque node est une voix. Chaque voix est un monde.
      </div>
    </div>
  );
};

export default Welcome;
