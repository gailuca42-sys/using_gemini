
import React, { useState, useEffect, useRef } from 'react';
import { solveMathProblem } from './services/geminiService';
import { MathResponse, HistoryItem } from './types';
import { 
  PlusCircle, 
  History, 
  Binary, 
  Sigma, 
  Cpu, 
  ArrowRight, 
  AlertCircle,
  Lightbulb,
  Search,
  BookOpen,
  Send,
  User
} from 'lucide-react';

const App: React.FC = () => {
  const [query, setQuery] = useState('');
  const [targetAge, setTargetAge] = useState(25);
  const [isSearching, setIsSearching] = useState(false);
  const [result, setResult] = useState<MathResponse | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || isSearching) return;

    setIsSearching(true);
    setError(null);
    setResult(null);

    try {
      const response = await solveMathProblem(query, targetAge);
      setResult(response);
      const newItem: HistoryItem = {
        id: Date.now().toString(),
        query,
        response,
        timestamp: Date.now()
      };
      setHistory(prev => [newItem, ...prev.slice(0, 9)]);
    } catch (err: any) {
      setError(err.message || 'An unexpected mathematical error occurred.');
    } finally {
      setIsSearching(false);
    }
  };

  const getAgeLabel = (age: number) => {
    if (age < 10) return "Enfant (Exploration ludique)";
    if (age < 15) return "Collégien (Intuition & Bases)";
    if (age < 20) return "Étudiant (Rigueur académique)";
    return "Expert (Recherche avancée)";
  };

  useEffect(() => {
    if (result && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [result]);

  return (
    <div className="min-h-screen flex flex-col md:flex-row overflow-hidden bg-[#0f172a]">
      {/* Sidebar - Desktop */}
      <aside className="hidden md:flex flex-col w-80 border-r border-slate-800 bg-slate-900/50 p-6 space-y-8">
        <div className="flex items-center space-x-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <Sigma className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-xl font-bold tracking-tight">Archimede AI</h1>
        </div>

        <div className="flex-1 space-y-6">
          {/* Age Selector */}
          <div className="space-y-4">
            <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center">
              <User className="w-3 h-3 mr-2" /> Niveau d'explication
            </h2>
            <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-700/50">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-medium text-blue-400">{targetAge} ans</span>
                <span className="text-[10px] text-slate-500 uppercase font-bold tracking-tighter">Cible</span>
              </div>
              <input 
                type="range" 
                min="6" 
                max="60" 
                value={targetAge} 
                onChange={(e) => setTargetAge(parseInt(e.target.value))}
                className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500 mb-3"
              />
              <p className="text-[11px] text-slate-300 leading-tight">
                {getAgeLabel(targetAge)}
              </p>
            </div>
          </div>

          <div>
            <h2 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4 flex items-center">
              <History className="w-3 h-3 mr-2" /> Recent Labs
            </h2>
            <div className="space-y-2 overflow-y-auto max-h-[40vh] custom-scrollbar">
              {history.length === 0 ? (
                <p className="text-sm text-slate-600 italic">No recent explorations...</p>
              ) : (
                history.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setResult(item.response);
                      setQuery(item.query);
                    }}
                    className="w-full text-left p-3 rounded-lg bg-slate-800/40 hover:bg-slate-800 border border-slate-700/50 hover:border-blue-500/30 transition-all group"
                  >
                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mb-1">{item.query}</p>
                    <span className="text-[10px] text-slate-600 group-hover:text-blue-400">
                      {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>

        <div className="bg-blue-900/10 rounded-xl p-4 border border-blue-500/20">
          <p className="text-xs leading-relaxed text-blue-200">
            <strong>Mode: Researcher</strong><br />
            L'IA adapte son vocabulaire et sa profondeur à l'âge sélectionné.
          </p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto custom-scrollbar flex flex-col items-center">
        {/* Header - Mobile */}
        <div className="md:hidden w-full p-4 border-b border-slate-800 flex flex-col space-y-4 bg-slate-900/80 backdrop-blur sticky top-0 z-50">
          <div className="flex justify-between items-center w-full">
            <div className="flex items-center space-x-2">
              <Sigma className="w-5 h-5 text-blue-500" />
              <span className="font-bold">Archimede AI</span>
            </div>
            <button onClick={() => window.location.reload()} className="p-2 bg-slate-800 rounded-full">
              <PlusCircle className="w-4 h-4" />
            </button>
          </div>
          <div className="flex items-center space-x-4 bg-slate-800/50 p-2 rounded-lg border border-slate-700">
            <span className="text-xs font-bold text-blue-400 whitespace-nowrap">{targetAge} ans</span>
            <input 
              type="range" 
              min="6" 
              max="60" 
              value={targetAge} 
              onChange={(e) => setTargetAge(parseInt(e.target.value))}
              className="flex-1 h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
          </div>
        </div>

        <div className="w-full max-w-4xl p-6 md:p-12 space-y-12">
          {/* Hero / Intro */}
          {!result && !isSearching && !error && (
            <div className="text-center space-y-6 pt-12 md:pt-24 animate-in fade-in slide-in-from-bottom-4 duration-700">
              <div className="inline-block p-3 bg-blue-500/10 rounded-2xl border border-blue-500/20 mb-4">
                <Binary className="w-12 h-12 text-blue-400" />
              </div>
              <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight bg-gradient-to-r from-white via-blue-100 to-blue-400 bg-clip-text text-transparent">
                Labo de Recherche Mathématique
              </h1>
              <p className="text-slate-400 text-lg max-w-2xl mx-auto leading-relaxed">
                Posez un problème, une conjecture ou un théorème. 
                J'explorerai chaque chemin logique, en adaptant mes explications pour un public de <span className="text-blue-400 font-bold">{targetAge} ans</span>.
              </p>
            </div>
          )}

          {/* Input Section */}
          <section className={`w-full transition-all duration-500 ${result || isSearching ? 'mt-4' : 'pt-4'}`}>
            <form onSubmit={handleSubmit} className="relative group">
              <div className={`absolute -inset-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl blur opacity-25 group-focus-within:opacity-50 transition duration-1000 group-hover:duration-200 ${isSearching ? 'animate-pulse' : ''}`}></div>
              <div className="relative flex items-center">
                <textarea
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Posez votre problème (ex: Pourquoi 1+1=2 ?, Explique le théorème de Pythagore, etc.)"
                  className="w-full min-h-[120px] bg-slate-900 border border-slate-700 rounded-2xl p-5 pr-16 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all shadow-2xl resize-none custom-scrollbar"
                  disabled={isSearching}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSubmit(e);
                    }
                  }}
                />
                <button
                  type="submit"
                  disabled={isSearching || !query.trim()}
                  className={`absolute right-4 bottom-4 p-3 rounded-xl transition-all ${
                    isSearching || !query.trim() 
                      ? 'bg-slate-800 text-slate-600 cursor-not-allowed' 
                      : 'bg-blue-600 text-white hover:bg-blue-500 shadow-lg shadow-blue-500/20'
                  }`}
                >
                  {isSearching ? <Cpu className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                </button>
              </div>
            </form>
          </section>

          {/* Error Display */}
          {error && (
            <div className="p-4 bg-red-900/20 border border-red-500/30 rounded-xl flex items-start space-x-3 animate-in fade-in duration-300">
              <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
              <p className="text-sm text-red-200">{error}</p>
            </div>
          )}

          {/* Loading / Thinking State */}
          {isSearching && (
            <div className="space-y-8 animate-in fade-in duration-500">
              <div className="flex items-center space-x-3 text-blue-400">
                <Search className="w-5 h-5 animate-pulse" />
                <span className="text-sm font-medium tracking-wide uppercase">Adaptation pédagogique en cours ({targetAge} ans)...</span>
              </div>
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-24 glass-effect rounded-2xl animate-pulse flex items-center px-6">
                    <div className="space-y-2 w-full">
                      <div className="h-4 bg-slate-700/50 rounded-full w-1/4"></div>
                      <div className="h-3 bg-slate-800/50 rounded-full w-3/4"></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Results Section */}
          {result && (
            <div ref={resultRef} className="space-y-10 animate-in fade-in slide-in-from-bottom-8 duration-1000">
              {/* Problem Statement */}
              <div className="border-l-4 border-blue-500 pl-6 py-2">
                <div className="flex items-center space-x-2 mb-1">
                  <h3 className="text-xs font-bold text-blue-500 uppercase tracking-widest">Analyse du problème</h3>
                  <span className="text-[10px] bg-slate-800 text-slate-400 px-2 rounded-full border border-slate-700">Niveau {targetAge} ans</span>
                </div>
                <p className="text-xl font-medium text-slate-200 leading-relaxed">{result.problemSummary}</p>
              </div>

              {/* Research Steps */}
              <div className="space-y-6">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center">
                  <BookOpen className="w-4 h-4 mr-2" /> Cheminement de pensée
                </h3>
                {result.steps.map((step, idx) => (
                  <div 
                    key={idx} 
                    className={`glass-effect rounded-2xl p-6 transition-all hover:border-slate-600 group relative overflow-hidden ${step.isConjecture ? 'border-amber-500/30' : ''}`}
                  >
                    {step.isConjecture && (
                      <div className="absolute top-0 right-0 px-3 py-1 bg-amber-500 text-[10px] font-bold text-slate-950 uppercase tracking-tighter">
                        Hypothèse
                      </div>
                    )}
                    <div className="flex items-center space-x-3 mb-4">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                        step.type === 'exploration' ? 'bg-indigo-500/20 text-indigo-400' :
                        step.type === 'demonstration' ? 'bg-emerald-500/20 text-emerald-400' :
                        step.type === 'verification' ? 'bg-sky-500/20 text-sky-400' :
                        'bg-slate-700/50 text-slate-300'
                      }`}>
                        {step.type}
                      </span>
                      <h4 className="text-md font-semibold text-slate-100">{step.title}</h4>
                    </div>
                    <div className="text-slate-300 leading-relaxed whitespace-pre-wrap math-font text-sm">
                      {step.content}
                    </div>
                  </div>
                ))}
              </div>

              {/* Final Synthesis */}
              <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-8 shadow-2xl shadow-blue-900/40 relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-700">
                  <Sigma className="w-48 h-48 text-white rotate-12" />
                </div>
                <div className="relative">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-sm font-bold text-blue-100 uppercase tracking-widest flex items-center">
                      <Lightbulb className="w-4 h-4 mr-2" /> Conclusion simplifiée
                    </h3>
                    <div className="flex items-center space-x-2 bg-white/10 px-3 py-1 rounded-full">
                      <span className="text-[10px] font-bold text-blue-100">Certitude:</span>
                      <div className="w-12 h-1.5 bg-white/20 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-blue-300" 
                          style={{ width: `${result.confidence * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                  <div className="text-white text-xl md:text-2xl font-bold leading-snug math-font">
                    {result.finalSolution}
                  </div>
                </div>
              </div>

              {/* Open Questions */}
              {result.openQuestions && result.openQuestions.length > 0 && (
                <div className="p-6 bg-slate-900/50 border border-slate-800 rounded-2xl">
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Pour aller plus loin...</h3>
                  <ul className="space-y-3">
                    {result.openQuestions.map((q, i) => (
                      <li key={i} className="flex items-start text-sm text-slate-400">
                        <ArrowRight className="w-3 h-3 text-blue-500 mt-1 mr-2 shrink-0" />
                        {q}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
        
        {/* Footer */}
        <footer className="w-full p-8 mt-auto border-t border-slate-900 text-center">
          <p className="text-slate-600 text-[10px] tracking-widest uppercase">
            Powered by Archimede AI Reasoning Engine & Gemini 3 Pro
          </p>
        </footer>
      </main>
    </div>
  );
};

export default App;
