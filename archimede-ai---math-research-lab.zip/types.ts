
export interface MathStep {
  type: 'exploration' | 'demonstration' | 'verification' | 'heuristic';
  title: string;
  content: string;
  isConjecture?: boolean;
}

export interface MathResponse {
  problemSummary: string;
  steps: MathStep[];
  finalSolution: string;
  confidence: number;
  openQuestions?: string[];
}

export interface HistoryItem {
  id: string;
  query: string;
  response: MathResponse;
  timestamp: number;
}
