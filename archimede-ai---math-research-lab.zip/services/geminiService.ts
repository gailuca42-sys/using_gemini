
import { GoogleGenAI, Type } from "@google/genai";
import { MathResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getSystemInstruction = (age: number) => {
  let pedagogicalContext = "";
  if (age < 10) {
    pedagogicalContext = "Your target audience is a young child (under 10). Use very simple analogies, avoid complex notation where possible, and explain every concept like a fun story or a physical game. Be extremely encouraging.";
  } else if (age < 15) {
    pedagogicalContext = "Your target audience is a middle schooler. Use relatable examples from daily life, clear step-by-step logic, and define any technical terms simply. Avoid advanced calculus or abstract algebra unless strictly necessary, and explain the 'why' behind formulas.";
  } else if (age < 20) {
    pedagogicalContext = "Your target audience is a high school or early college student. Use formal mathematical language but provide strong intuition. Focus on the logical flow and the elegance of the proof.";
  } else {
    pedagogicalContext = "Your target audience is a professional researcher or advanced university student. Use rigorous formal logic, technical notation, and refer to advanced theorems without over-simplifying. Focus on depth and exhaustivity.";
  }

  return `You are "Archimede AI", a world-class senior research mathematician specialized in deep problem-solving and pedagogy.
${pedagogicalContext}

Your core philosophy:
1. EXPLORATION: Always explore multiple mathematical paths (algebraic, geometric, numerical, logical).
2. NO LAZINESS: Never claim "no solution exists" without a rigorous logical proof or exhaustive search demonstration.
3. CONJECTURES: If a problem touches on open conjectures (Lychrel numbers, Collatz, P vs NP), do not stall. Instead, provide rational hypotheses, computational simulations (describe them), or exploratory reasoning.
4. DETAIL: Break down every thought. Be pedantic about proofs and intuitive about explanations.
5. MULTI-DISCIPLINARY: Combine heuristics and formal logic.

RESPONSE FORMAT: You must return valid JSON. Use the provided schema.`;
};

const MATH_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    problemSummary: {
      type: Type.STRING,
      description: "A refined restatement of the mathematical problem."
    },
    steps: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          type: {
            type: Type.STRING,
            description: "Category: exploration, demonstration, verification, or heuristic."
          },
          title: { type: Type.STRING },
          content: { type: Type.STRING },
          isConjecture: { type: Type.BOOLEAN }
        },
        required: ["type", "title", "content"]
      }
    },
    finalSolution: {
      type: Type.STRING,
      description: "The conclusive answer, proof, or heuristic finding."
    },
    confidence: {
      type: Type.NUMBER,
      description: "A score from 0 to 1 representing the mathematical certainty."
    },
    openQuestions: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Remaining areas of exploration or related open problems discovered."
    }
  },
  required: ["problemSummary", "steps", "finalSolution", "confidence"]
};

export const solveMathProblem = async (problem: string, age: number): Promise<MathResponse> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `[Target Audience Age: ${age}] Problem: ${problem}`,
      config: {
        systemInstruction: getSystemInstruction(age),
        responseMimeType: "application/json",
        responseSchema: MATH_SCHEMA,
        thinkingConfig: { thinkingBudget: 32768 },
        temperature: 0.2,
      },
    });

    const resultText = response.text;
    if (!resultText) throw new Error("No response from Archimede AI");
    
    return JSON.parse(resultText) as MathResponse;
  } catch (error) {
    console.error("Math API Error:", error);
    throw error;
  }
};
