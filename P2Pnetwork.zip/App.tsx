
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { NodeIdentity, DataBlock, PeerNode, SystemLog, SitePayload } from './types';
import { storageService } from './services/storage';
import { cryptoService } from './services/crypto';
import { p2pService } from './services/p2p';
import NetworkVisualizer from './components/NetworkVisualizer';
import { 
  Zap, Globe, Search, Server, MessageSquare, Info, Lock, 
  Loader2, Activity, UserPlus, LogOut, Copy, ExternalLink,
  TriangleAlert, ShieldCheck, Plus, X, Share2, FlaskConical,
  Send, QrCode, Cpu, Fingerprint, Sun, Moon, MousePointer2, Ghost, LineChart, Code2
} from 'lucide-react';
import QRCode from 'qrcode';
import { Html5QrcodeScanner } from 'html5-qrcode';

export default function App() {
  const [identity, setIdentity] = useState<NodeIdentity | null>(null);
  const [view, setView] = useState<'topology' | 'discovery' | 'hosting' | 'lab' | 'chat' | 'specs'>('topology');
  const [activeLabModule, setActiveLabModule] = useState<string | null>(null);

  const [ledger, setLedger] = useState<DataBlock[]>([]);
  const [peers, setPeers] = useState<PeerNode[]>([]);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [myPeerId, setMyPeerId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  
  const [preInit, setPreInit] = useState(true);
  const [loginMode, setLoginMode] = useState<'access' | 'unlock' | null>(null);
  const [alias, setAlias] = useState('');
  const [passphrase, setPassphrase] = useState('');
  const [selectedLocalNode, setSelectedLocalNode] = useState<NodeIdentity | null>(null);
  const [targetPeerId, setTargetPeerId] = useState('');

  const [searchQuery, setSearchQuery] = useState('');
  const [viewingSite, setViewingSite] = useState<SitePayload | null>(null);

  // Hosting States
  const [hostTitle, setHostTitle] = useState('');
  const [hostContent, setHostContent] = useState('<h1>Hello Swarm!</h1>\n<p>Mon premier site décentralisé.</p>\n<style>body { font-family: sans-serif; text-align: center; padding-top: 50px; background: #fafafa; color: #111; }</style>');

  // Lab States
  const [pulseActive, setPulseActive] = useState(false);
  const [shadowText, setShadowText] = useState('');
  const [latencies, setLatencies] = useState<Record<string, number>>({});

  // QR Logic
  const [showQrModal, setShowQrModal] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [showScanner, setShowScanner] = useState(false);
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);

  const localNodes = useMemo(() => storageService.getAllIdentities(), [preInit, identity]);

  // Lab Computations
  const collectiveCount = useMemo(() => {
    return ledger.filter(b => b.tag === 'GAME_ACTION' && b.payload === 'LAB_CLICK').length;
  }, [ledger]);

  const shadowTyping = useMemo(() => {
    const typing: Record<string, {text: string, timestamp: number, alias: string}> = {};
    ledger.filter(b => b.tag === 'GAME_ACTION' && b.payload.startsWith('SHADOW_LIVE:'))
      .forEach(b => {
        const text = b.payload.replace('SHADOW_LIVE:', '');
        if (!typing[b.nodeId] || b.timestamp > typing[b.nodeId].timestamp) {
          typing[b.nodeId] = { text, timestamp: b.timestamp, alias: b.nodeAlias };
        }
      });
    return typing;
  }, [ledger]);

  useEffect(() => {
    p2pService.onLog((msg, type) => {
      setLogs(prev => [{ id: Math.random().toString(36), timestamp: Date.now(), message: msg, type }, ...prev].slice(0, 1));
    });

    const existingId = storageService.getActiveSessionId();
    if (existingId) {
      const id = storageService.getIdentity(existingId);
      if (id) {
        setPreInit(false);
        completeLogin(id);
      }
    }
  }, []);

  useEffect(() => {
    if (showScanner) {
      scannerRef.current = new Html5QrcodeScanner("qr-reader", { fps: 10, qrbox: 250 }, false);
      scannerRef.current.render((decodedText) => {
        setTargetPeerId(decodedText);
        setShowScanner(false);
        scannerRef.current?.clear();
      }, (error) => {});
    }
    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear();
      }
    };
  }, [showScanner]);

  const generateMyQr = async () => {
    if (myPeerId) {
      try {
        const url = await QRCode.toDataURL(myPeerId);
        setQrDataUrl(url);
        setShowQrModal(true);
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleMessage = (msg: any) => {
    if (msg.type === 'Data/NEW_BLOCK') {
      const block = msg.block as DataBlock;
      
      // Calculate Drift/Latency
      const lat = Date.now() - block.timestamp;
      setLatencies(prev => ({ ...prev, [block.nodeId]: lat }));

      // Handle Sync Pulse
      if (block.tag === 'GAME_ACTION' && block.payload === 'LAB_PULSE') {
        setPulseActive(true);
        setTimeout(() => setPulseActive(false), 1500);
      }

      setLedger(prev => {
        if (prev.some(b => b.id === block.id)) return prev;
        // Don't save transient "LIVE" blocks to local storage long-term
        if (!block.payload.startsWith('SHADOW_LIVE:')) {
          storageService.appendBlock(block);
        }
        return [block, ...prev];
      });
    } else if (msg.type === 'Sync/RESPONSE') {
      const blocks = msg.blocks as DataBlock[];
      setLedger(prev => {
        let next = [...prev];
        blocks.forEach(b => {
          if (!next.some(x => x.id === b.id)) {
            next.push(b);
            storageService.appendBlock(b);
          }
        });
        return next.sort((a,b) => b.timestamp - a.timestamp);
      });
    } else if (msg.type === 'Signal/HELLO') {
      setPeers(prev => prev.find(p => p.id === msg.sender.id) ? prev : [...prev, { ...msg.sender, lastSeen: Date.now() }]);
    }
  };

  const completeLogin = async (id: NodeIdentity) => {
    setIsLoading(true);
    setIdentity(id);
    storageService.setActiveSession(id.id);
    const savedLedger = storageService.getLedger();
    setLedger(savedLedger.sort((a,b) => b.timestamp - a.timestamp));
    
    p2pService.init(id, (peerId) => {
        setMyPeerId(peerId);
        p2pService.onMessage(handleMessage);
        setIsLoading(false);
    });
  };

  const sendLabAction = async (actionPayload: string, silent = false) => {
    if (!identity) return;
    const block: DataBlock = {
      id: Math.random().toString(36),
      nodeId: identity.id,
      nodeAlias: identity.alias,
      tag: 'GAME_ACTION',
      payload: actionPayload,
      timestamp: Date.now(),
      signature: 'sim',
      size: actionPayload.length,
      seeds: 1
    };
    if (!silent) {
      setLedger(prev => [block, ...prev]);
    }
    p2pService.propagateBlock(block);
  };

  const handlePublishSite = () => {
    if (!identity || !hostTitle.trim()) return;
    const siteData: SitePayload = {
      id: Math.random().toString(36),
      title: hostTitle,
      files: [{ name: 'index.html', content: hostContent, type: 'text/html' }],
      entry: 'index.html',
      type: 'html',
      updatedAt: Date.now()
    };
    const block: DataBlock = {
      id: `site-${siteData.id}`,
      nodeId: identity.id,
      nodeAlias: identity.alias,
      tag: 'SITE_ANNOUNCEMENT',
      payload: JSON.stringify(siteData),
      timestamp: Date.now(),
      signature: 'sim',
      size: hostContent.length,
      seeds: 1
    };
    setLedger(prev => [block, ...prev]);
    storageService.appendBlock(block);
    p2pService.propagateBlock(block);
    p2pService.log("SITE PUBLIÉ SUR LE SWARM", "success");
    setHostTitle('');
    setView('discovery');
  };

  const handleAccess = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!alias.trim() || !passphrase) return;
    setIsLoading(true);
    const id = await cryptoService.createNodeId(alias, passphrase);
    const hash = await cryptoService.generateHash(passphrase);
    const newUser: NodeIdentity = {
        id, alias: alias.trim(), passphraseHash: hash,
        createdAt: Date.now(), integrityScore: 100, contributionScore: 100
    };
    storageService.saveIdentity(newUser);
    completeLogin(newUser);
  };

  const handleUnlock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLocalNode || !passphrase) return;
    setIsLoading(true);
    const hash = await cryptoService.generateHash(passphrase);
    if (hash === selectedLocalNode.passphraseHash) {
        completeLogin(selectedLocalNode);
    } else {
        alert("Mot de passe incorrect.");
        setIsLoading(false);
    }
  };

  if (!identity) {
    return (
      <div className={`min-h-screen ${isDarkMode ? 'bg-black text-white' : 'bg-slate-50 text-slate-900'} flex items-center justify-center p-6 font-sans transition-colors duration-500`}>
        <div className="max-w-[340px] w-full text-center space-y-12">
          {isLoading ? (
            <div className="space-y-6 fade-in flex flex-col items-center">
              <Loader2 className="w-12 h-12 text-cyan-500 animate-spin" />
              <p className={`text-[10px] font-bold uppercase tracking-[0.4em] ${isDarkMode ? 'text-zinc-500' : 'text-slate-400'}`}>Connexion Swarm...</p>
            </div>
          ) : preInit ? (
            <div className="space-y-12 fade-in flex flex-col items-center">
              <div className={`w-16 h-16 ${isDarkMode ? 'bg-white text-black' : 'bg-black text-white'} rounded-2xl flex items-center justify-center shadow-2xl transition-all`}>
                <Zap className="w-8 h-8 fill-current text-cyan-500" />
              </div>
              <div className="space-y-2">
                <h1 className={`text-4xl font-black tracking-tighter uppercase italic ${isDarkMode ? 'text-white' : 'text-black'}`}>TrueNode</h1>
                <p className={`${isDarkMode ? 'text-zinc-600' : 'text-slate-400'} text-[10px] font-bold tracking-[0.2em] uppercase`}>P2P Mesh Protocol</p>
              </div>
              <button onClick={() => setPreInit(false)} className={`w-full h-14 ${isDarkMode ? 'bg-white text-black hover:bg-zinc-200' : 'bg-black text-white hover:bg-zinc-800'} font-black rounded-2xl transition-all text-xs tracking-widest uppercase`}>ENTRER</button>
            </div>
          ) : !loginMode ? (
            <div className="space-y-8 fade-in w-full">
              <div className="space-y-1 text-left">
                <h2 className={`text-lg font-black uppercase tracking-widest italic ${isDarkMode ? 'text-white' : 'text-black'}`}>Comptes locaux</h2>
                <p className={`${isDarkMode ? 'text-zinc-600' : 'text-slate-400'} text-[10px] font-bold uppercase`}>Sélectionnez votre nœud</p>
              </div>
              <div className="space-y-3">
                {localNodes.map(node => (
                  <button key={node.id} onClick={() => { setSelectedLocalNode(node); setLoginMode('unlock'); }} className={`w-full h-16 px-6 ${isDarkMode ? 'bg-zinc-900/50 hover:bg-zinc-800 border-zinc-800' : 'bg-white hover:bg-slate-50 border-slate-200'} rounded-2xl flex justify-between items-center border transition-all shadow-sm`}>
                    <span className={`font-bold text-sm ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>{node.alias}</span>
                    <Lock className={`w-4 h-4 ${isDarkMode ? 'text-zinc-700' : 'text-slate-300'}`} />
                  </button>
                ))}
                <button onClick={() => setLoginMode('access')} className={`w-full h-14 text-[9px] ${isDarkMode ? 'text-zinc-500 hover:text-white border-zinc-800' : 'text-slate-400 hover:text-black border-slate-200'} font-bold flex items-center justify-center gap-2 border border-dashed rounded-2xl mt-4 uppercase tracking-widest transition-all`}>
                  <Plus className="w-3 h-3"/> Créer / Récupérer un compte
                </button>
              </div>
            </div>
          ) : (
            <div className="w-full space-y-8 fade-in flex flex-col items-center">
              <button onClick={() => { setLoginMode(null); setAlias(''); setPassphrase(''); setSelectedLocalNode(null); }} className={`text-[9px] uppercase font-bold ${isDarkMode ? 'text-zinc-600 hover:text-white' : 'text-slate-400 hover:text-black'} flex items-center gap-2 tracking-widest`}>
                <X className="w-3 h-3"/> Revenir
              </button>
              <div className="w-full space-y-6 text-left">
                <h2 className={`text-xl font-black uppercase tracking-widest italic ${isDarkMode ? 'text-white' : 'text-black'}`}>
                  {loginMode === 'unlock' ? `Accès : ${selectedLocalNode?.alias}` : 'Nouvelle Identité'}
                </h2>
                <form onSubmit={loginMode === 'unlock' ? handleUnlock : handleAccess} className="space-y-4">
                  {loginMode === 'access' && (
                    <input placeholder="Nom du nœud (Alias)" className={`w-full h-14 ${isDarkMode ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-white border-slate-200 text-black'} border rounded-2xl px-5 outline-none focus:border-cyan-500 font-bold`} value={alias} onChange={e=>setAlias(e.target.value)} autoFocus />
                  )}
                  <input type="password" placeholder="Phrase secrète" className={`w-full h-14 ${isDarkMode ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-white border-slate-200 text-black'} border rounded-2xl px-5 outline-none focus:border-cyan-500`} value={passphrase} onChange={e=>setPassphrase(e.target.value)} autoFocus={loginMode === 'unlock'} />
                  <button type="submit" className={`w-full h-14 ${isDarkMode ? 'bg-white text-black hover:bg-zinc-200' : 'bg-black text-white hover:bg-zinc-800'} rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl transition-all`}>
                    {loginMode === 'unlock' ? 'DÉVERROUILLER' : 'REJOINDRE'}
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-[#050505] text-white' : 'bg-slate-50 text-slate-900'} flex flex-col md:flex-row font-sans selection:bg-cyan-500/30 transition-colors duration-500`}>
      {/* Modals QR */}
      {showQrModal && (
        <div className="fixed inset-0 z-[1000] bg-black/90 flex items-center justify-center p-6 backdrop-blur-md" onClick={() => setShowQrModal(false)}>
          <div className="bg-white p-8 rounded-[40px] flex flex-col items-center gap-6" onClick={e => e.stopPropagation()}>
            <img src={qrDataUrl} alt="My QR Code" className="w-64 h-64" />
            <div className="text-center space-y-2">
              <h3 className="text-black font-black uppercase italic">Votre Peer ID</h3>
              <p className="text-zinc-400 text-[10px] font-bold max-w-[200px] break-all uppercase">{myPeerId}</p>
            </div>
            <button onClick={() => setShowQrModal(false)} className="w-full py-4 bg-black text-white rounded-2xl font-black uppercase text-[10px] tracking-widest">Fermer</button>
          </div>
        </div>
      )}

      {showScanner && (
        <div className="fixed inset-0 z-[1000] bg-black/95 flex items-center justify-center p-6 backdrop-blur-md">
          <div className="w-full max-w-md bg-zinc-900 rounded-[40px] p-8 space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-white font-black uppercase italic">Scanner un Peer ID</h3>
              <button onClick={() => setShowScanner(false)} className="p-2 bg-white/10 rounded-full"><X className="w-4 h-4"/></button>
            </div>
            <div id="qr-reader" className="w-full overflow-hidden rounded-2xl border border-zinc-800"></div>
            <p className="text-zinc-500 text-[9px] font-bold uppercase tracking-widest text-center">Placez le QR code dans le cadre</p>
          </div>
        </div>
      )}

      {/* Sidebar */}
      <aside className={`w-full md:w-72 ${isDarkMode ? 'bg-black border-zinc-900' : 'bg-white border-slate-200'} border-r flex flex-col p-6 shrink-0 z-50 transition-all`}>
        <div className="flex items-center gap-3 mb-10 pl-2">
          <Zap className="w-5 h-5 text-cyan-500 fill-current" />
          <span className={`text-xl font-black tracking-tighter uppercase italic ${isDarkMode ? 'text-white' : 'text-black'}`}>TrueNode</span>
        </div>

        <nav className="flex-1 space-y-1.5">
          <SideLink isDarkMode={isDarkMode} active={view==='topology'} icon={<Globe/>} label="Exploration" onClick={()=>setView('topology')} />
          <SideLink isDarkMode={isDarkMode} active={view==='discovery'} icon={<Search/>} label="Recherche" onClick={()=>setView('discovery')} />
          <SideLink isDarkMode={isDarkMode} active={view==='hosting'} icon={<Server/>} label="Node Hosting" onClick={()=>setView('hosting')} />
          <SideLink isDarkMode={isDarkMode} active={view==='lab'} icon={<FlaskConical/>} label="Swarm Lab" onClick={()=>setView('lab')} />
          <SideLink isDarkMode={isDarkMode} active={view==='chat'} icon={<MessageSquare/>} label="Comms" onClick={()=>setView('chat')} />
          <SideLink isDarkMode={isDarkMode} active={view==='specs'} icon={<Info/>} label="Specs" onClick={()=>setView('specs')} />
        </nav>

        <div className={`mt-8 pt-8 border-t ${isDarkMode ? 'border-zinc-900' : 'border-slate-100'} space-y-6`}>
           <div className="space-y-2">
              <div className={`text-[8px] font-bold uppercase tracking-[0.2em] pl-3 mb-2 ${isDarkMode ? 'text-zinc-600' : 'text-slate-400'}`}>Connexion Peer</div>
              <div className="relative group">
                 <input 
                    placeholder="Peer ID..." 
                    className={`w-full ${isDarkMode ? 'bg-zinc-900/50 border-zinc-800 text-white placeholder:text-zinc-700 focus:border-zinc-700' : 'bg-slate-50 border-slate-200 text-slate-800 placeholder:text-slate-300 focus:border-slate-300'} border rounded-xl h-10 px-4 text-[10px] outline-none transition-all`} 
                    value={targetPeerId} onChange={e=>setTargetPeerId(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && (p2pService.connectToPeer(targetPeerId), setTargetPeerId(''))}
                 />
                 <button onClick={() => setShowScanner(true)} className="absolute right-3 top-1/2 -translate-y-1/2 text-cyan-500/50 hover:text-cyan-400 transition-colors">
                    <QrCode className="w-3.5 h-3.5" />
                 </button>
              </div>
           </div>
           
           <div className="space-y-1">
              <button onClick={() => { storageService.clearSession(); window.location.reload(); }} className={`w-full text-left px-3 py-2 text-[10px] font-bold uppercase tracking-widest transition-all ${isDarkMode ? 'text-zinc-600 hover:text-zinc-400' : 'text-slate-400 hover:text-slate-600'}`}>Se déconnecter</button>
              <button onClick={() => { if(confirm("Supprimer définitivement ce nœud ?")) storageService.wipeNode(identity!.id); }} className={`w-full text-left px-3 py-2 text-[10px] font-bold uppercase tracking-widest transition-all ${isDarkMode ? 'text-rose-800 hover:text-rose-600' : 'text-rose-700 hover:text-rose-500'}`}>Supprimer le nœud</button>
           </div>

           <button onClick={() => setIsDarkMode(!isDarkMode)} className={`w-full flex items-center gap-3 px-3 py-2 text-[9px] font-bold uppercase tracking-widest ${isDarkMode ? 'text-zinc-700 hover:text-zinc-400' : 'text-slate-300 hover:text-slate-500'} transition-all`}>
              {isDarkMode ? <Sun className="w-3 h-3" /> : <Moon className="w-3 h-3" />}
              <span>{isDarkMode ? 'Mode Claire' : 'Mode Sombre'}</span>
           </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 h-screen overflow-y-auto relative custom-scrollbar ${isDarkMode ? 'bg-black' : 'bg-[#fafafa]'}`}>
        {viewingSite && (
          <div className={`fixed inset-0 z-[200] ${isDarkMode ? 'bg-black' : 'bg-white'} flex flex-col fade-in`}>
            <div className={`p-4 border-b ${isDarkMode ? 'border-zinc-900 bg-zinc-950' : 'border-slate-100 bg-white'} flex justify-between items-center shadow-md`}>
              <div className="flex items-center gap-4">
                <Globe className="text-cyan-500 w-4 h-4" />
                <h3 className={`font-bold text-xs uppercase tracking-widest italic ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>{viewingSite.title}</h3>
              </div>
              <button onClick={()=>setViewingSite(null)} className={`p-2 rounded-lg transition-colors ${isDarkMode ? 'hover:bg-zinc-800' : 'hover:bg-slate-50'}`}><X className="w-4 h-4"/></button>
            </div>
            <iframe srcDoc={viewingSite.files.find(f=>f.name===viewingSite.entry)?.content} className="flex-1 w-full border-none bg-white" />
          </div>
        )}

        <div className="p-12 md:p-16 max-w-6xl mx-auto space-y-12">
          
          {/* VUE : EXPLORATION */}
          {view === 'topology' && (
            <div className="space-y-12 fade-in">
              <header className="flex flex-col md:flex-row justify-between items-start gap-6">
                <div className="space-y-3">
                  <h2 className={`text-6xl font-black tracking-tighter uppercase italic ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Mesh Explorer</h2>
                  <p className={`${isDarkMode ? 'text-zinc-500' : 'text-slate-400'} text-sm font-medium`}>Visualisation dynamique du réseau décentralisé.</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className={`border ${isDarkMode ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-slate-200'} px-5 h-10 rounded-full flex items-center gap-3 shadow-sm`}>
                    <Activity className="w-3 h-3 text-cyan-500 animate-pulse" />
                    <span className={`text-[9px] font-bold uppercase tracking-widest ${isDarkMode ? 'text-zinc-400' : 'text-slate-500'}`}>Pairs Actifs: {peers.length}</span>
                  </div>
                  <button onClick={generateMyQr} className={`h-10 px-5 ${isDarkMode ? 'bg-zinc-900 hover:bg-zinc-800 border-zinc-800' : 'bg-white hover:bg-slate-50 border-slate-200'} border rounded-full transition-all text-[9px] font-bold uppercase tracking-widest flex items-center gap-2 shadow-sm`}>
                    <Share2 className="w-3.5 h-3.5 text-cyan-500"/> Copier mon ID
                  </button>
                </div>
              </header>
              <div className={`h-[550px] rounded-[40px] border ${isDarkMode ? 'border-zinc-900 bg-zinc-950/20' : 'border-slate-100 bg-white shadow-sm'} overflow-hidden relative group`}>
                 <NetworkVisualizer peers={peers} localStatus="Active" />
              </div>
            </div>
          )}

          {/* VUE : RECHERCHE */}
          {view === 'discovery' && (
            <div className="space-y-12 fade-in text-center pt-10">
              <div className="space-y-4">
                <h2 className={`text-7xl font-black tracking-tighter uppercase italic ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Discovery Engine</h2>
                <p className={`${isDarkMode ? 'text-zinc-600' : 'text-slate-300'} text-[10px] font-bold uppercase tracking-[0.4em]`}>Chercher des ressources distribuées</p>
              </div>
              <div className="max-w-2xl mx-auto relative group">
                <Search className={`absolute right-8 top-1/2 -translate-y-1/2 w-5 h-5 ${isDarkMode ? 'text-zinc-700' : 'text-slate-300'} group-focus-within:text-cyan-500 transition-colors`} />
                <input 
                  className={`w-full h-20 ${isDarkMode ? 'bg-zinc-900/40 border-zinc-800 text-white placeholder:text-zinc-800 focus:border-zinc-700' : 'bg-white border-slate-200 text-slate-800 placeholder:text-slate-200 focus:border-slate-300'} border rounded-full px-10 outline-none transition-all text-lg font-medium shadow-sm`}
                  placeholder="Entrez un titre de site..."
                  value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-16 text-left">
                 {ledger.filter(b => b.tag === 'SITE_ANNOUNCEMENT').map(block => {
                    const payload = JSON.parse(block.payload) as SitePayload;
                    if (searchQuery && !payload.title.toLowerCase().includes(searchQuery.toLowerCase())) return null;
                    return (
                      <div key={block.id} className={`p-10 rounded-[40px] ${isDarkMode ? 'bg-zinc-900/30 border-zinc-800 hover:border-cyan-500/30' : 'bg-white border-slate-100 hover:border-cyan-500/30 shadow-sm'} border transition-all group cursor-pointer`} onClick={() => setViewingSite(payload)}>
                        <div className="flex justify-between items-start mb-6">
                          <span className="text-[8px] font-bold uppercase tracking-widest px-3 py-1 bg-cyan-500/10 text-cyan-500 border border-cyan-500/20 rounded-full">D-Web</span>
                          <span className={`text-[9px] font-bold uppercase ${isDarkMode ? 'text-zinc-700' : 'text-slate-300'}`}>{block.nodeAlias}</span>
                        </div>
                        <h4 className={`text-2xl font-black group-hover:text-cyan-400 transition-colors mb-4 ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>{payload.title}</h4>
                      </div>
                    );
                 })}
              </div>
            </div>
          )}

          {/* VUE : NODE HOSTING */}
          {view === 'hosting' && (
             <div className="space-y-12 fade-in">
                <div className="space-y-4">
                  <h2 className={`text-6xl font-black tracking-tighter uppercase italic ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Node Hosting</h2>
                  <p className={`${isDarkMode ? 'text-zinc-500' : 'text-slate-400'} text-sm`}>Déployez vos propres ressources HTML sur le Swarm.</p>
                </div>
                <div className="flex flex-col lg:flex-row gap-8">
                   <div className={`flex-1 ${isDarkMode ? 'bg-zinc-900/30 border-zinc-800' : 'bg-white border-slate-100 shadow-sm'} border rounded-[50px] p-12 space-y-10`}>
                      <div className="space-y-4">
                         <label className={`text-[10px] font-bold uppercase tracking-widest ml-4 ${isDarkMode ? 'text-zinc-600' : 'text-slate-400'}`}>Titre du site</label>
                         <input 
                            className={`w-full h-16 ${isDarkMode ? 'bg-zinc-950 border-zinc-800 text-white focus:border-cyan-500/50' : 'bg-slate-50 border-slate-100 text-black focus:border-cyan-500/50'} border rounded-3xl px-8 text-lg font-bold outline-none transition-all`} 
                            placeholder="Mon Super Portfolio..." 
                            value={hostTitle} onChange={e=>setHostTitle(e.target.value)}
                         />
                      </div>
                      <div className="space-y-4">
                         <label className={`text-[10px] font-bold uppercase tracking-widest ml-4 ${isDarkMode ? 'text-zinc-600' : 'text-slate-400'}`}>Code HTML (index.html)</label>
                         <textarea 
                            className={`w-full h-64 ${isDarkMode ? 'bg-zinc-950 border-zinc-800 text-cyan-500 font-mono focus:border-cyan-500/50' : 'bg-slate-50 border-slate-100 text-cyan-700 font-mono focus:border-cyan-500/50'} border rounded-3xl p-8 text-sm outline-none resize-none transition-all`} 
                            value={hostContent} onChange={e=>setHostContent(e.target.value)}
                         />
                      </div>
                   </div>
                   <div className={`w-full lg:w-80 ${isDarkMode ? 'bg-zinc-900/30 border-zinc-800' : 'bg-white border-slate-100 shadow-sm'} border rounded-[50px] p-10 flex flex-col items-center justify-center text-center gap-8`}>
                      <div className="w-20 h-20 bg-cyan-500/10 border border-cyan-500/20 rounded-full flex items-center justify-center">
                         <ShieldCheck className="w-10 h-10 text-cyan-500" />
                      </div>
                      <h4 className={`text-xl font-black uppercase italic ${isDarkMode ? 'text-white' : 'text-slate-800'}`}>Déploiement Swarm</h4>
                      <p className={`${isDarkMode ? 'text-zinc-600' : 'text-slate-400'} text-[10px] font-bold uppercase leading-relaxed tracking-widest`}>Une fois publié, ce site est gravé dans un bloc P2P et propagé à tous vos pairs connectés.</p>
                      <button 
                        onClick={handlePublishSite}
                        disabled={!hostTitle.trim()}
                        className={`w-full py-6 rounded-2xl font-black uppercase tracking-widest text-[9px] transition-all shadow-xl ${hostTitle.trim() ? (isDarkMode ? 'bg-white text-black hover:bg-zinc-200' : 'bg-black text-white hover:bg-zinc-800') : (isDarkMode ? 'bg-zinc-800/50 text-zinc-600 cursor-not-allowed' : 'bg-slate-100 text-slate-300 cursor-not-allowed')}`}
                      >
                        PUBLIER MAINTENANT
                      </button>
                   </div>
                </div>
             </div>
          )}

          {/* VUE : COMMS */}
          {view === 'chat' && (
             <div className="fade-in flex flex-col h-[75vh] space-y-12">
                <h2 className={`text-6xl font-black tracking-tighter uppercase italic ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Broadcast Comms</h2>
                <div className="flex-1 overflow-y-auto space-y-6 pr-4 custom-scrollbar">
                   {ledger.filter(b => b.tag === 'CHAT').map(msg => (
                      <div key={msg.id} className={`flex flex-col ${msg.nodeId === identity?.id ? 'items-end' : 'items-start'}`}>
                         <div className={`max-w-[70%] p-5 rounded-3xl text-sm font-medium ${msg.nodeId === identity?.id ? (isDarkMode ? 'bg-zinc-800 text-white' : 'bg-black text-white') : (isDarkMode ? 'bg-zinc-900/40 text-zinc-400 border-zinc-800 shadow-sm' : 'bg-white text-slate-600 border-slate-100 shadow-sm')} border whitespace-pre-wrap`}>
                            {msg.payload}
                         </div>
                         <div className={`text-[8px] font-black uppercase mt-2 px-3 tracking-widest ${isDarkMode ? 'text-zinc-700' : 'text-slate-300'}`}>{msg.nodeAlias}</div>
                      </div>
                   ))}
                </div>
                <div className="relative">
                   <input 
                     className={`w-full h-20 border rounded-full px-10 outline-none font-medium transition-all ${isDarkMode ? 'bg-zinc-900/30 border-zinc-800 text-white placeholder:text-zinc-800 focus:border-zinc-700' : 'bg-white border-slate-100 text-black placeholder:text-slate-200 shadow-sm focus:border-slate-200'}`} 
                     placeholder="Message global..."
                     onKeyDown={e => {
                        if (e.key === 'Enter' && (e.target as any).value) {
                           const val = (e.target as any).value;
                           (e.target as any).value = '';
                           const block: DataBlock = {
                              id: Math.random().toString(36), nodeId: identity!.id, nodeAlias: identity!.alias,
                              tag: 'CHAT', payload: val, timestamp: Date.now(), signature: 'sim', size: val.length, seeds: 1
                           };
                           setLedger(p => [block, ...p]);
                           storageService.appendBlock(block);
                           p2pService.propagateBlock(block);
                        }
                     }}
                   />
                   <button className={`absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full flex items-center justify-center hover:scale-105 transition-all shadow-xl ${isDarkMode ? 'bg-white text-black' : 'bg-black text-white'}`}>
                      <Send className="w-5 h-5" />
                   </button>
                </div>
             </div>
          )}

          {/* VUE : SWARM LAB */}
          {view === 'lab' && (
            <div className="space-y-12 fade-in">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
                <div className="space-y-4">
                  <h2 className={`text-6xl font-black tracking-tighter uppercase italic ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Swarm Lab</h2>
                  <p className={`${isDarkMode ? 'text-zinc-600' : 'text-slate-300'} text-[10px] font-bold uppercase tracking-[0.4em]`}>Synchronisation d'états collectifs.</p>
                </div>
                {activeLabModule && (
                  <button onClick={() => setActiveLabModule(null)} className={`px-6 h-10 border rounded-full text-[9px] font-bold uppercase tracking-widest transition-all ${isDarkMode ? 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white' : 'bg-white border-slate-200 text-slate-400 hover:text-black'}`}>&larr; Quitter le module</button>
                )}
              </div>

              {!activeLabModule ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
                  <LabModule isDarkMode={isDarkMode} icon={<Activity/>} label="Swarm Pulse" onClick={() => setActiveLabModule('pulse')} />
                  <LabModule isDarkMode={isDarkMode} icon={<MousePointer2/>} label="Collective Click" onClick={() => setActiveLabModule('clicker')} />
                  <LabModule isDarkMode={isDarkMode} icon={<Ghost/>} label="Shadows" onClick={() => setActiveLabModule('shadows')} />
                  <LabModule isDarkMode={isDarkMode} icon={<LineChart/>} label="Drift Monitor" onClick={() => setActiveLabModule('drift')} />
                </div>
              ) : (
                <div className={`fade-in rounded-[50px] border p-12 flex flex-col items-center justify-center min-h-[500px] overflow-hidden relative transition-all ${isDarkMode ? 'bg-zinc-950/20 border-zinc-900' : 'bg-white border-slate-100 shadow-sm'}`}>
                  
                  {/* PULSE MODULE */}
                  {activeLabModule === 'pulse' && (
                    <div className="flex flex-col items-center gap-12 relative">
                       {pulseActive && (
                         <div className="absolute inset-0 flex items-center justify-center -z-10">
                            <div className="w-1 h-1 rounded-full bg-cyan-500 animate-[ping_1.5s_cubic-bezier(0,0,0.2,1)_infinite]" style={{ width: '800px', height: '800px' }} />
                         </div>
                       )}
                       <Activity className={`w-24 h-24 ${pulseActive ? 'text-cyan-400 scale-125' : 'text-zinc-800'} transition-all duration-300`} />
                       <h3 className={`text-xl font-black uppercase italic ${isDarkMode ? 'text-white' : 'text-black'}`}>Réseau : Pulsation {pulseActive ? 'SYNCHRONISÉE' : 'Prête'}</h3>
                       <button 
                         onClick={() => { sendLabAction('LAB_PULSE', true); setPulseActive(true); setTimeout(() => setPulseActive(false), 1500); }}
                         className={`w-32 h-32 rounded-full border-4 flex items-center justify-center transition-all active:scale-90 ${isDarkMode ? 'bg-white text-black border-cyan-500 shadow-2xl' : 'bg-black text-white border-cyan-500 shadow-2xl'}`}
                       >
                         <Zap className="w-10 h-10 fill-current" />
                       </button>
                       <p className={`text-[9px] font-bold uppercase tracking-[0.2em] ${isDarkMode ? 'text-zinc-600' : 'text-slate-400'}`}>Tous les pairs recevront l'impulsion</p>
                    </div>
                  )}

                  {/* SHADOWS MODULE */}
                  {activeLabModule === 'shadows' && (
                    <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
                      <div className="space-y-8">
                         <div className="space-y-2">
                            <h4 className={`text-xs font-black uppercase tracking-widest ${isDarkMode ? 'text-zinc-500' : 'text-slate-400'}`}>Votre entrée (Temps réel)</h4>
                            <textarea 
                              className={`w-full h-32 border rounded-3xl p-6 outline-none text-sm transition-all resize-none ${isDarkMode ? 'bg-zinc-900 border-zinc-800 text-white focus:border-cyan-500/50' : 'bg-slate-50 border-slate-100 text-black focus:border-cyan-500/50'}`} 
                              placeholder="Écrivez n'importe quoi, c'est partagé instantanément..."
                              value={shadowText}
                              onChange={e => {
                                setShadowText(e.target.value);
                                sendLabAction(`SHADOW_LIVE:${e.target.value}`, true);
                              }}
                            />
                         </div>
                      </div>
                      <div className="space-y-6">
                         <h4 className={`text-xs font-black uppercase tracking-widest ${isDarkMode ? 'text-zinc-500' : 'text-slate-400'}`}>Activité des pairs</h4>
                         <div className="grid grid-cols-1 gap-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                           {/* Fix: Cast 'data' from Object.entries to the expected type to resolve TypeScript 'unknown' errors (line 605, 608) */}
                           {Object.entries(shadowTyping).map(([nodeId, data]) => {
                             const shadowData = data as {text: string, timestamp: number, alias: string};
                             if (nodeId === identity?.id) return null;
                             return (
                               <div key={nodeId} className={`p-6 rounded-3xl border animate-pulse ${isDarkMode ? 'bg-zinc-900/40 border-zinc-800' : 'bg-white border-slate-100 shadow-sm'}`}>
                                 <div className="flex justify-between items-center mb-2">
                                    <span className="text-[8px] font-black uppercase tracking-widest text-cyan-500">{shadowData.alias}</span>
                                    <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full animate-pulse" />
                                 </div>
                                 <p className={`text-sm italic ${isDarkMode ? 'text-zinc-400' : 'text-slate-600'}`}>"{shadowData.text || '...'}"</p>
                               </div>
                             );
                           })}
                           {Object.keys(shadowTyping).length <= 1 && (
                             <div className={`p-10 text-center border-2 border-dashed rounded-3xl ${isDarkMode ? 'border-zinc-900 text-zinc-800' : 'border-slate-50 text-slate-200'} font-bold uppercase text-[9px] tracking-widest`}>
                               Attente d'activité P2P...
                             </div>
                           )}
                         </div>
                      </div>
                    </div>
                  )}

                  {/* DRIFT MONITOR */}
                  {activeLabModule === 'drift' && (
                    <div className="w-full space-y-12">
                      <div className="text-center space-y-4">
                         <h3 className={`text-2xl font-black uppercase italic ${isDarkMode ? 'text-white' : 'text-black'}`}>Dérive Temporelle du Swarm</h3>
                         <p className={`${isDarkMode ? 'text-zinc-600' : 'text-slate-400'} text-[10px] font-bold uppercase tracking-[0.4em]`}>Latence réelle calculée sur les derniers blocs</p>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {peers.map(p => {
                          const lat = latencies[p.id] || 0;
                          const status = lat < 100 ? 'OPTIMAL' : lat < 500 ? 'NOMINAL' : 'DELAYED';
                          const color = lat < 100 ? 'text-green-500' : lat < 500 ? 'text-amber-500' : 'text-rose-500';
                          return (
                            <div key={p.id} className={`p-8 rounded-[40px] border ${isDarkMode ? 'bg-zinc-900/40 border-zinc-800' : 'bg-white border-slate-100 shadow-sm'} transition-all hover:scale-105`}>
                              <div className="flex justify-between items-center mb-6">
                                <span className={`text-[10px] font-black uppercase tracking-widest ${isDarkMode ? 'text-zinc-500' : 'text-slate-400'}`}>{p.alias}</span>
                                <Cpu className={`w-4 h-4 ${color}`} />
                              </div>
                              <div className="space-y-4">
                                 <div className="flex items-end gap-2">
                                    <span className={`text-5xl font-black italic tracking-tighter ${isDarkMode ? 'text-white' : 'text-black'}`}>{lat}</span>
                                    <span className="text-[10px] font-bold text-zinc-600 mb-2">ms</span>
                                 </div>
                                 <div className={`text-[9px] font-black uppercase tracking-widest p-2 rounded-xl bg-zinc-950/40 border border-zinc-900/50 text-center ${color}`}>
                                    {status}
                                 </div>
                                 <div className="h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                                    <div className={`h-full transition-all duration-1000 ${lat < 100 ? 'bg-green-500' : lat < 500 ? 'bg-amber-500' : 'bg-rose-500'}`} style={{ width: `${Math.min(lat / 10, 100)}%` }} />
                                 </div>
                              </div>
                            </div>
                          );
                        })}
                        {peers.length === 0 && (
                          <div className={`col-span-full p-20 text-center ${isDarkMode ? 'text-zinc-800' : 'text-slate-300'} font-bold uppercase italic text-sm tracking-widest`}>
                            Aucun pair détecté pour l'analyse de latence.
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* CLICKER MODULE */}
                  {activeLabModule === 'clicker' && (
                    <div className="text-center space-y-10">
                      <div className="space-y-2">
                        <h3 className={`text-8xl font-black italic tracking-tighter ${isDarkMode ? 'text-white' : 'text-black'}`}>{collectiveCount}</h3>
                        <p className={`text-[10px] font-bold uppercase tracking-[0.4em] ${isDarkMode ? 'text-cyan-500' : 'text-cyan-600'}`}>Clicks sur le Swarm</p>
                      </div>
                      <button 
                        onClick={() => sendLabAction('LAB_CLICK')}
                        className={`w-32 h-32 rounded-full border-4 flex items-center justify-center transition-all active:scale-95 ${isDarkMode ? 'bg-white text-black border-cyan-500/20 shadow-[0_0_30px_rgba(6,182,212,0.2)]' : 'bg-black text-white border-cyan-500/10 shadow-xl'}`}
                      >
                        <Plus className="w-10 h-10" />
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* VUE : SPECS */}
          {view === 'specs' && (
            <div className="space-y-16 fade-in">
              <div className="space-y-6">
                <h2 className={`text-7xl font-black tracking-tighter uppercase italic leading-none ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>Protocol Specs</h2>
                <div className="w-32 h-2 bg-cyan-500 rounded-full" />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-20 gap-y-16">
                 <SpecItem isDarkMode={isDarkMode} icon={<ShieldCheck/>} title="Cryptographic ID" text="Identités générées localement par hachage SHA-256. Pas de base de données centrale." />
                 <SpecItem isDarkMode={isDarkMode} icon={<Cpu/>} title="Mesh Ledger" text="Chaque action est un bloc propagé à travers le réseau P2P et validé localement." />
                 <SpecItem isDarkMode={isDarkMode} icon={<Server/>} title="Distributed Web" text="Hébergez vos propres ressources. La découverte est automatique via l'exploration du réseau." />
                 <SpecItem isDarkMode={isDarkMode} icon={<Fingerprint/>} title="Merit System" text="Gagnez en réputation en participant à la propagation et en publiant du contenu." />
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Notification */}
      <div className="fixed bottom-8 right-8 pointer-events-none z-[300]">
        {logs.map(log => (
          <div key={log.id} className={`fade-in px-6 py-4 rounded-full border shadow-2xl backdrop-blur-md transition-all ${isDarkMode ? 'bg-zinc-900/60 border-zinc-800/50' : 'bg-white/80 border-slate-100'} text-[10px] font-bold uppercase tracking-widest flex items-center gap-4`}>
            <div className={`w-2 h-2 rounded-full ${log.type==='success'?'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.6)] animate-pulse':'bg-zinc-700'}`} />
            <span className={`italic font-mono ${isDarkMode ? 'text-zinc-400' : 'text-slate-500'}`}>{log.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

const SideLink = ({ active, icon, label, onClick, isDarkMode }: any) => (
  <button onClick={onClick} className={`w-full flex items-center gap-5 p-3.5 rounded-2xl transition-all group ${active ? (isDarkMode ? 'bg-zinc-900 text-white' : 'bg-slate-50 text-black shadow-sm') : (isDarkMode ? 'text-zinc-600 hover:text-zinc-400' : 'text-slate-400 hover:text-slate-600')}`}>
    <div className={`transition-colors ${active ? 'text-cyan-500' : (isDarkMode ? 'text-zinc-800 group-hover:text-zinc-600' : 'text-slate-200 group-hover:text-slate-400')}`}>{React.cloneElement(icon, { className: "w-4 h-4" })}</div>
    <span className={`text-[10px] uppercase font-bold tracking-widest transition-all ${active ? 'translate-x-1' : ''}`}>{label}</span>
  </button>
);

const SpecItem = ({ icon, title, text, isDarkMode }: any) => (
  <div className="space-y-6">
    <div className={`w-16 h-16 rounded-full flex items-center justify-center text-cyan-500 border ${isDarkMode ? 'bg-zinc-900/30 border-zinc-900' : 'bg-white border-slate-100 shadow-sm'}`}>
      {React.cloneElement(icon, { className: "w-6 h-6" })}
    </div>
    <div className="space-y-2">
      <h3 className={`text-3xl font-black uppercase italic ${isDarkMode ? 'text-white' : 'text-slate-900'}`}>{title}</h3>
      <p className={`text-sm leading-relaxed max-w-sm ${isDarkMode ? 'text-zinc-500' : 'text-slate-400'}`}>{text}</p>
    </div>
  </div>
);

const LabModule = ({ icon, label, isDarkMode, onClick }: any) => (
  <div 
    onClick={onClick}
    className={`aspect-square border rounded-[35px] flex flex-col items-center justify-center gap-4 cursor-pointer transition-all ${isDarkMode ? 'bg-zinc-900/30 border-zinc-900 text-zinc-800 hover:bg-zinc-900/50 hover:border-cyan-500/30' : 'bg-white border-slate-50 text-slate-200 hover:bg-slate-50 shadow-sm hover:border-cyan-500/30'}`}
  >
    {React.cloneElement(icon, { className: "w-6 h-6" })}
    <span className={`text-[8px] font-bold uppercase tracking-widest text-center px-4 ${isDarkMode ? 'text-zinc-800' : 'text-slate-300'}`}>{label}</span>
  </div>
);
