
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { PeerNode } from '../types';

interface SimulationNode extends d3.SimulationNodeDatum {
  id: string;
  label: string;
  status?: string;
  group: number;
  radius: number;
  x?: number;
  y?: number;
  // Added vx and vy explicitly to ensure TypeScript recognizes them as part of the node structure
  vx?: number;
  vy?: number;
}

interface NetworkVisualizerProps {
  peers: PeerNode[];
  localStatus?: string;
}

const NetworkVisualizer: React.FC<NetworkVisualizerProps> = ({ peers, localStatus }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const prevNodesRef = useRef<SimulationNode[]>([]);
  const simulationRef = useRef<d3.Simulation<SimulationNode, undefined> | null>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const width = svgRef.current.clientWidth;
    const height = svgRef.current.clientHeight || 400;

    d3.select(svgRef.current).selectAll("*").remove();

    const svg = d3.select(svgRef.current)
      .attr("viewBox", [0, 0, width, height] as any)
      .style("background-color", "transparent");

    const targetNodes: SimulationNode[] = [
      { id: 'me', label: 'LOCAL NODE', status: localStatus, group: 1, radius: 14 },
      ...peers.map(p => ({ id: p.id, label: p.alias, status: p.status, group: 2, radius: 10 }))
    ];

    const prevNodeMap = new Map<string, SimulationNode>(prevNodesRef.current.map(n => [n.id, n]));
    const d3Nodes: SimulationNode[] = targetNodes.map(node => {
        const prev = prevNodeMap.get(node.id);
        // Fix: copying x, y, vx, vy from previous nodes to maintain simulation continuity
        return prev ? { ...node, x: prev.x, y: prev.y, vx: prev.vx, vy: prev.vy } : node; 
    });
    prevNodesRef.current = d3Nodes;

    const links: any[] = [];
    d3Nodes.forEach((s, i) => d3Nodes.forEach((t, j) => { if (i < j) links.push({ source: s.id, target: t.id }); }));

    const simulation = d3.forceSimulation(d3Nodes)
      .force("link", d3.forceLink(links).id((d: any) => d.id).distance(140))
      .force("charge", d3.forceManyBody().strength(-600))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collide", d3.forceCollide().radius(70))
      .alphaDecay(0.05); // Adjust for smoother stabilization

    simulationRef.current = simulation;

    const link = svg.append("g")
      .attr("stroke", "rgba(6, 182, 212, 0.1)")
      .selectAll("line").data(links).join("line").attr("stroke-width", 1);

    const nodeGroup = svg.append("g")
      .selectAll("g").data(d3Nodes).join("g")
      .call(d3.drag<any, SimulationNode>()
        .on("start", (event, d) => {
          if (!event.active) simulation.alphaTarget(0.3).restart();
          d.fx = d.x;
          d.fy = d.y;
        })
        .on("drag", (event, d) => {
          d.fx = event.x;
          d.fy = event.y;
        })
        .on("end", (event, d) => {
          if (!event.active) simulation.alphaTarget(0);
          // Gently release - setting fx/fy to null allows the simulation to take over again
          // and pull the node back to its natural place slowly.
          d.fx = null;
          d.fy = null;
        }) as any
      );

    // Node body
    nodeGroup.append("circle")
      .attr("r", d => d.radius)
      .attr("fill", d => d.group === 1 ? "#fff" : "#0a0a0a")
      .attr("stroke", d => d.group === 1 ? "#06b6d4" : "#1e293b")
      .attr("stroke-width", 2)
      .attr("class", "transition-colors duration-300")
      .style("cursor", "grab");

    // Inner glow
    nodeGroup.filter(d => d.group === 1).append("circle")
      .attr("r", 20)
      .attr("fill", "rgba(6,182,212,0.15)")
      .attr("class", "animate-pulse")
      .style("pointer-events", "none");

    nodeGroup.append("text")
      .text(d => d.label)
      .attr("y", 32).attr("text-anchor", "middle")
      .attr("fill", d => d.group === 1 ? "#fff" : "#64748b")
      .style("font-size", "10px")
      .style("font-weight", "bold")
      .style("font-family", "monospace")
      .style("pointer-events", "none");

    simulation.on("tick", () => {
      link.attr("x1", (d: any) => d.source.x).attr("y1", (d: any) => d.source.y)
          .attr("x2", (d: any) => d.target.x).attr("y2", (d: any) => d.target.y);
      nodeGroup.attr("transform", (d: any) => `translate(${d.x},${d.y})`);
    });

    return () => { simulation.stop(); };
  }, [peers, localStatus]); 

  return (
    <div className="w-full h-full relative">
      <svg ref={svgRef} className="w-full h-full bg-black/10"></svg>
    </div>
  );
};

export default NetworkVisualizer;
