
// CLIENT-SIDE CRYPTO UTILITIES
// Uses Web Crypto API for hashing.

export const cryptoService = {
  // SHA-256 Hashing
  async generateHash(data: string): Promise<string> {
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(data);
    const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  },

  // Node ID Generation (Identity Address)
  // UNIQUE & DETERMINISTIC: Alias + Passphrase = Always the same ID.
  async createNodeId(alias: string, passphrase?: string): Promise<string> {
    const normalizedAlias = alias.trim().toLowerCase();
    const normalizedPass = passphrase || 'default_gate_key';
    // Identifiant racine fixe pour garantir que le même alias + pass = même ID partout
    const rawString = `TRUENODE-IDENTITY-ROOT-V1-${normalizedAlias}-${normalizedPass}`;
    return await this.generateHash(rawString);
  },

  // Block Signature
  async signBlock(payload: string, nodeId: string): Promise<string> {
      return await this.generateHash(`${payload}-SIGN-BY-${nodeId}`);
  }
};
