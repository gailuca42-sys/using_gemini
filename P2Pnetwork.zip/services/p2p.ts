
import { NodeIdentity, DataBlock } from '../types';
// Fix: Use named imports for Peer and DataConnection to ensure correct type resolution
import { Peer, DataConnection } from 'peerjs';
import { storageService } from './storage';

class P2PService {
  private peer: Peer | null = null;
  private connections: Map<string, DataConnection> = new Map();
  private authenticatedPeers: Map<string, NodeIdentity> = new Map();
  
  private onMessageCallback: ((msg: any) => void) | null = null;
  private onLogCallback: ((msg: string, type: 'info'|'success'|'warning'|'error') => void) | null = null;
  private onInboundCallback: (() => void) | null = null;
  
  public myPeerId: string | null = null;
  private currentNode: NodeIdentity | null = null;

  init(node: NodeIdentity, onReady: (id: string) => void) {
    if (this.peer && !this.peer.destroyed) {
      this.peer.destroy();
    }
    
    this.currentNode = node;
    // Utilisation d'un ID court mais unique pour PeerJS
    const rand = Math.random().toString(36).substring(2, 6);
    const shortId = `truenode-${node.id.substring(0, 8)}-${rand}`;

    this.peer = new Peer(shortId, { 
        debug: 1,
        config: { 
          iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
            { urls: 'stun:stun2.l.google.com:19302' },
            { urls: 'stun:stun3.l.google.com:19302' },
            { urls: 'stun:stun4.l.google.com:19302' },
            { urls: 'stun:global.stun.twilio.com:3478' }
          ] 
        }
    });

    // Fix: Setup 'open' event listener on Peer instance
    this.peer.on('open', (id) => {
      this.myPeerId = id;
      this.log(`SWARM_UP: ${id}`, 'success');
      onReady(id);
      
      const previousPeers = storageService.getPeerDirectory();
      previousPeers.forEach(pid => {
          if (pid !== id) setTimeout(() => this.connectToPeer(pid), 2000);
      });
    });

    // Fix: Setup 'connection' event listener on Peer instance
    this.peer.on('connection', (conn) => {
      if (this.onInboundCallback) this.onInboundCallback();
      this.setupConnection(conn);
    });
    
    // Fix: Setup 'disconnected' event listener on Peer instance
    this.peer.on('disconnected', () => {
      this.log('NET_ERR: Déconnexion serveur.', 'error');
      setTimeout(() => {
        if (this.peer && this.peer.disconnected && !this.peer.destroyed) {
          this.peer.reconnect();
        }
      }, 5000);
    });

    // Fix: Setup 'error' event listener on Peer instance
    this.peer.on('error', (err: any) => {
        if (err.type === 'peer-unavailable') {
            this.log(`NODE_OFFLINE`, 'warning');
        } else {
            this.log(`NET_ERR: ${err.type}`, 'error');
        }
    });
  }

  onInbound(callback: () => void) {
    this.onInboundCallback = callback;
  }

  connectToPeer(input: string) {
    if (!this.peer || !input || !this.myPeerId) return;
    
    let targetId = input.trim();
    if (!targetId.startsWith('truenode-')) targetId = `truenode-${targetId}`;
    if (targetId === this.myPeerId || this.connections.has(targetId)) return;

    const conn = this.peer.connect(targetId, { reliable: true });
    // Fix: Setup 'open' event listener on DataConnection instance
    conn.on('open', () => {
        const known = Array.from(this.authenticatedPeers.keys());
        conn.send({ 
          type: 'Handshake/INIT', 
          sender: this.currentNode!,
          knownPeers: known 
        });
        this.setupConnection(conn);
    });
  }

  private setupConnection(conn: DataConnection) {
    this.connections.set(conn.peer, conn);

    // Fix: Setup 'data' event listener on DataConnection instance
    conn.on('data', (data: any) => {
      const msg = data as any;
      
      if (msg.type === 'Handshake/INIT' || msg.type === 'Handshake/ACK') {
          this.authenticatedPeers.set(conn.peer, msg.sender);
          storageService.savePeerToDirectory(conn.peer);
          
          if (msg.type === 'Handshake/INIT') {
            const known = Array.from(this.authenticatedPeers.keys()).filter(p => p !== conn.peer);
            conn.send({ 
              type: 'Handshake/ACK', 
              sender: this.currentNode!,
              knownPeers: known
            });
          }

          if (msg.knownPeers && Array.isArray(msg.knownPeers)) {
            msg.knownPeers.forEach((pid: string) => {
              if (pid !== this.myPeerId && !this.connections.has(pid)) {
                setTimeout(() => this.connectToPeer(pid), 1500);
              }
            });
          }

          this.log(`LINK_OK: ${msg.sender.alias}`, 'success');
          if (this.onMessageCallback) this.onMessageCallback({ type: 'Signal/HELLO', sender: msg.sender });
          
          // Request sync after authentication
          conn.send({ type: 'Sync/REQUEST' });
      }

      if (msg.type === 'Sync/REQUEST') {
          conn.send({ type: 'Sync/RESPONSE', blocks: storageService.getLedger() });
      }

      if (this.onMessageCallback) this.onMessageCallback(msg);
    });

    // Fix: Setup 'close' event listener on DataConnection instance
    conn.on('close', () => {
        this.connections.delete(conn.peer);
        this.authenticatedPeers.delete(conn.peer);
        this.log(`PEER_OFFLINE`, 'warning');
    });
  }

  onMessage(callback: (msg: any) => void) { this.onMessageCallback = callback; }
  onLog(callback: (msg: string, type: 'info'|'success'|'warning'|'error') => void) { this.onLogCallback = callback; }
  public log(msg: string, type: 'info'|'success'|'warning'|'error') { if(this.onLogCallback) this.onLogCallback(msg, type); }

  broadcast(payload: any) {
    this.connections.forEach(conn => {
        if (conn.open && this.authenticatedPeers.has(conn.peer)) {
            conn.send(payload);
        }
    });
  }

  propagateBlock(block: DataBlock) {
    this.broadcast({ type: 'Data/NEW_BLOCK', block });
  }
}

export const p2pService = new P2PService();
