
import { NodeIdentity, DataBlock } from '../types';

const STORAGE_PREFIX = 'truenode_v4_';
const DB_KEY = `${STORAGE_PREFIX}ledger`;
const PEERS_KEY = `${STORAGE_PREFIX}directory`;
const SESSION_KEY = `${STORAGE_PREFIX}session_cursor`;

const getDB = () => {
  try {
    const raw = localStorage.getItem(DB_KEY);
    return raw ? JSON.parse(raw) : { nodes: {} };
  } catch (e) {
    return { nodes: {} };
  }
};

const saveDB = (db: any) => {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
};

export const storageService = {
  setActiveSession: (nodeId: string) => sessionStorage.setItem(SESSION_KEY, nodeId),
  getActiveSessionId: () => sessionStorage.getItem(SESSION_KEY),
  clearSession: () => sessionStorage.removeItem(SESSION_KEY),

  getIdentity: (id: string): NodeIdentity | null => {
    const db = getDB();
    return db.nodes[id]?.identity || null;
  },

  getAllIdentities: (): NodeIdentity[] => Object.values(getDB().nodes).map((n: any) => n.identity),

  saveIdentity: (identity: NodeIdentity) => {
    const db = getDB();
    if (!db.nodes[identity.id]) db.nodes[identity.id] = { identity, ledger: [] };
    else db.nodes[identity.id].identity = identity;
    saveDB(db);
  },

  getLedger: (): DataBlock[] => {
    const activeId = storageService.getActiveSessionId();
    if (!activeId) return [];
    return getDB().nodes[activeId]?.ledger || [];
  },

  appendBlock: (block: DataBlock) => {
    const activeId = storageService.getActiveSessionId();
    if (!activeId) return;
    const db = getDB();
    const node = db.nodes[activeId];
    if (!node) return;
    // Overwrite if exists (for updates)
    node.ledger = [block, ...node.ledger.filter((b: any) => b.id !== block.id)].slice(0, 50);
    saveDB(db);
  },

  removeBlock: (blockId: string) => {
    const activeId = storageService.getActiveSessionId();
    if (!activeId) return;
    const db = getDB();
    const node = db.nodes[activeId];
    if (!node) return;
    node.ledger = node.ledger.filter((b: any) => b.id !== blockId);
    saveDB(db);
  },

  getPeerDirectory: (): string[] => {
    const raw = localStorage.getItem(PEERS_KEY);
    return raw ? JSON.parse(raw) : [];
  },

  savePeerToDirectory: (peerId: string) => {
    const directory = storageService.getPeerDirectory();
    if (!directory.includes(peerId)) {
      localStorage.setItem(PEERS_KEY, JSON.stringify([...directory, peerId].slice(-15)));
    }
  },

  exportIdentity: (id: string) => {
    const node = getDB().nodes[id];
    if (!node) return null;
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(node.identity));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `truenode_backup_${node.identity.alias}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  },

  wipeNode: (id: string) => {
    const db = getDB();
    if (db.nodes[id]) {
      delete db.nodes[id];
      saveDB(db);
    }
    storageService.clearSession();
    localStorage.removeItem(PEERS_KEY);
    window.location.href = window.location.pathname;
  }
};
