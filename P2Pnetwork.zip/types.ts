
export interface NodeIdentity {
  id: string;             
  alias: string;          
  passphraseHash: string;
  status?: string;        
  createdAt: number;
  integrityScore: number; 
  contributionScore: number;
}

export interface SiteFile {
  name: string;
  content: string; 
  type: string;
}

export interface SitePayload {
  id: string;
  title: string;
  files: SiteFile[];
  entry: string; 
  type: 'html' | 'pdf';
  updatedAt: number;
}

export interface DataBlock {
  id: string;          
  nodeId: string;      
  nodeAlias: string;   
  tag: 'CHAT' | 'GAME_ACTION' | 'SITE_ANNOUNCEMENT' | 'REVOKE_SITE'; 
  payload: string; 
  timestamp: number;
  signature: string;
  size: number;
  seeds: number; 
}

export interface PeerNode {
  id: string;
  alias: string;
  status?: string;     
  lastSeen: number;
  contributionScore?: number;
}

export interface SystemLog {
  id: string;
  timestamp: number;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
}
